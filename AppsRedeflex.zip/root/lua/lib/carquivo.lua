---
--Regra de Neg�cios de pagamentos
--@author Arthur Pires
--@release Vers�o inicial 1.0
--@copyright CESAR

S_ARQUIVOS_TRANSACAO = "trans"


S_ARQUIVOS_EXTENSAO = ".dat"
S_TABELAS_EXTENSAO = ".tbl"
