require 'qrcode'


-- Funcao para imprimir o boleto
function imprimirImagem(texto, resolucao, alinhamento, logo)

	--gerando matrix do qrcode
	local qr = QRCodeWriter:New(texto);
	local matrix = qr:GetMatrix()
	
	--calculando o tamanho total da imagem do QRCode, em pixels (tem quer multiplo de 8)
	tamQRCode = math.ceil(matrix:getHeight() * resolucao/8)*8
	
	--se estourar o tamanho maximo para impressao, diminui o tamanho automaticamente
	--384 testado e funciona no ICT (HF2.30A)
	while tamQRCode > 384 and resolucao > 1 do
				
		--diminui resolucao
		resolucao = resolucao - 1
		
		--recalcula tamanho
		tamQRCode = math.ceil(matrix:getHeight() * resolucao/8)*8
		
	end
	

	
	--local nomeImagem = "../shared/qrp" .. resolucao .. ".bmp"
	local nomeImagem = "qrp" .. resolucao .. ".bmp"
	
	--criando imagem de fundo, toda branca (deve ser multiplo de 8)
	--printer.print('tamQRCode=' .. tamQRCode)
	--local img = image.create(296,296)
	local img = image.create(tamQRCode,tamQRCode)
	
	--abrindo o padrao a ser desenhado
	local p = image.load(nomeImagem)
	
	
	local bytes = matrix:getTable()
	local height = matrix:getHeight()
	local width = matrix:getWidth()
	
	x = 1
	
	--loop da linha
	while (x <= height) do
	
		y = 1
		
		--loop da coluna
		while (y <= width) do
			
			--se for 1 (preto) desenha
			if (bytes[x][y] == 1) then
				--printer.print("desenhando...")
				img:drawimage(p,  (y-1)*resolucao ,  (x-1)*resolucao )
				--printer.printimage(img, alinhamento)
				--keyboard.getkeystroke(1000)
			end
			
			y = y + 1
		end
		
		x = x + 1
	
	end
	
	
	--se o logo foi informado, joga no meio do qrcode
	if logo ~= nil then
		local logoImg = image.load(logo)
		img:drawimage(logoImg, img:width()/2-logoImg:width()/2, img:width()/2-logoImg:width()/2)
	end

	if alinhamento == nil then
		alinhamento = "center"
	end
	
	printer.printimage(img, alinhamento)
	
	image.unload(img)
	image.unload(p)
		
end



for i=1	, 8 do
	printer.print('tamanho='..i)
	imprimirImagem('qweljqkwlejqlwekjqlwejqlwekjqlekjqeq weqwekqwlejqlwkejqlwe qwe qw eq weq�wlekq�wlekq�wlekq�lwek', i, 'center', nil)
end

