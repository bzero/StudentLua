-- Constantes das mensagens de texto

-- Lembra de mim - esses nao:
-- Mensagens do vouct.lua
-- T_FINANC_TS_DIG_SEN_ATU		= {'TS: digite a senha atual\nno teclado num�rico:', '', ''},
-- T_FINANC_TS_DIG_SEN_NOVA		= {'TS: digite a nova senha\nno teclado num�rico:', '', ''},
-- T_FINANC_TS_CONF_SEN_NOVA	= {'TS: confirme a nova senha\nno teclado num�rico:', '', ''},

-- Lembra de mim - jogando as contantes em uma tabela para facilitar a traducao
-- Lembra de mim - adicionado ',' depois do '}'


tMsgTexto = {

--[[
	FINANCRN
--]]

-- Mensagens para o Input
tFinancInput = {

-- Mensagens do iniciact.lua
T_FINANC_VALOR				= {'valor:', '', ''},
T_FINANC_DIG_SENHA_LOJ		= {'digite a senha do lojista\n no teclado num�rico:', '', ''},


-- Mensagens do baixact.lua
T_FINANC_NRO_OCOR			= {'n�mero ocorr�ncia:', '', ''},
T_FINANC_NRO_HABIL			= {'n�mero habilita��o:', '', ''},
T_FINANC_NRO_ESTAB			= {'n�m. do estabelecimento:', '', ''},


-- Mensagens do capturct.lua
T_FINANC_COD_AUT			= {'c�digo autoriza��o:', '', ''},
T_FINANC_DATA_DDMMAA		= {'data (ddmmaa):', '', ''},


-- Mensagens do cfgcomct.lua
T_FINANC_APN				= {'apn:', '', ''},
T_FINANC_DOIS_ULT_DIG_TERM	= {'dois �ltimos digitos do terminal:', '', ''},
T_FINANC_POWER_OFF_MIN		= {'power off (minutos):', '', ''},


-- Mensagens do configct.lua
T_FINANC_DIG_SENHA_ATU_LOJ	= {'digite a senha atual do lojista\nno teclado num�rico:', '', ''},
T_FINANC_DIG_NOVA_SENHA		= {'digite a nova senha', '', ''},
T_FINANC_REP_NOVA_SENHA		= {'repita a nova senha', '', ''},


-- Mensagens do credct.lua
T_FINANC_VALIDADE			= {'validade (mm/aa):', '', ''},
T_FINANC_NRO_PARC			= {'n�mero de parcelas:', '', ''},
T_FINANC_NRO_DOC			= {'n�mero documento:', '', ''},


-- Mensagens do pvtct.lua
T_FINANC_COND_PGTO			= {'cond. pagto:', '', ''}, -- esse
T_FINANC_VENC_PUL			= {'vencto. pular:', '', ''},
T_FINANC_ITEM				= {'item:', '', ''},


-- Mensagens do reimprct.lua
T_FINANC_NRO_AUTE			= {'n�mero aute:', '', ''},


-- Mensagens do serct.lua
T_FINANC_CMC7_BLOCO_1		= {'CMC-7 Bloco 1:', '', ''},
T_FINANC_CMC7_BLOCO_2		= {'CMC-7 Bloco 2:', '', ''},
T_FINANC_CMC7_BLOCO_3		= {'CMC-7 Bloco 3:', '', ''},
T_FINANC_DDD				= {'(DDD):', '', ''},
T_FINANC_FONE				= {'FONE:', '', ''},


-- Mensagens do tecnct.lua
T_FINANC_DIG_SENHA_TEC		= {'digite a senha do t�cnico\nno teclado num�rico:', '', ''},


-- Mensagens do tecnict.lua
T_FINANC_DIG_SENHA_INI		= {'digite a senha de inicializa��o\nno teclado num�rico:', '', ''},


-- Mensagens do telautct.lua
T_FINANC_INF_HORA_MIN		= {'informe hora e minuto', '', ''},


-- Mensagens do transct.lua
T_FINANC_COD_SEG			= {'c�digo seguran�a:', '', ''},
T_FINANC_QUAT_ULT_DIG		= {'4 �ltimos d�gitos:', '', ''},

},  -- Input FINANCRN


-- Mensagens para o Dialog
tFinancDialog = {

-- Mensagens do iniciact.lua
T_FINANC_TERM_NAO_CONF		= {'terminal n�o\nconfigurado', '', ''},
T_FINANC_INS_PAS_CART		= {'insira ou passe \no cart�o', '', ''},
T_FINANC_VLR_OU_CART		= {'digite o valor, insira\nou passe o cart�o', '', ''},
T_FINANC_FNC_INAT			= {'fun��o inativa', '', ''},
T_FINANC_DESL_TERM			= {'deseja desligar\no terminal?', '', ''},
T_FINANC_CMD_INAT			= {'comando inativo', '', ''},
T_FINANC_OPER_CANC			= {'opera��o\ncancelada', '', ''},
T_FINANC_DESL				= {'desligando...', '', ''},
T_FINANC_AGUARDE			= {'aguarde', '', ''},
T_FINANC_NAO_DESL_TOMADA	= {'mantenha ligado a tomada \ndurante todo o processo', '', ''},
T_FINANC_SEN_INV			= {'senha invalida!', '', ''},
T_FINANC_SEN_INV_TENT_NOV	= {'senha inv�lida\ntente novamente', '', ''},
T_FINANC_SEN_INV_OPER_CANC	= {'senha inv�lida\nopera��o\ncancelada', '', ''},
T_FINANC_ATU_NAO_REALIZ		= {'atualiza��o \n n�o realizada', '', ''},
T_FINANC_REALIZ_NOVA_ATU	= {'realizar nova \ntentativa \nde atualiza��o?', '', ''},
T_FINANC_EFET_BAIXA_TEC		= {'efetue\nbaixa t�cnica', '', ''},
T_FINANC_LOTE_VAZIO			= {'lote vazio', '', ''},
T_FINANC_FALHA_CONEXAO		= {'falha de conex�o', '', ''},


-- Mensagens do admct.lua
T_FINANC_TERM_ATU_SUC		= {'terminal atualizado\ncom sucesso \n\ndeseja conhecer as novas \nfun��es?', '', ''},
T_FINANC_SEM_NOVID			= {'nao ha novidades a serem exibidas', '', ''},


-- Mensagens do apagact.lua
T_FINANC_IMPRIMINDO			= {'imprimindo', '', ''},
T_FINANC_SEM_MSGS			= {'n�o h� msgs', '', ''},


-- Mensagens do apagarn.lua
T_FINANC_OPERAC_COMPL		= {'opera��o completada', '', ''},
T_FINANC_SEM_DESF			= {'n�o h� desfazimento', '', ''},


-- Mensagens do baixact.lua
T_FINANC_USE_CHIP			= {'use chip para esta transa��o', '', ''},
T_FINANC_TRN_APROV			= {'transa��o aprovada', '', ''},
T_FINANC_FALHA_CON_SERV		= {'falha na conex�o com o servidor', '', ''},


-- Mensagens do cfgcomct.lua
T_FINANC_NRO_SIM_CARD		= {'n�mero do SIM card:\n', '', ''},
T_FINANC_SIM_CARD_AUSENTE	= {'sim card\nausente', '', ''},
T_FINANC_ESCOLHA_OPER		= {'escolha a operadora', '', ''},				-- I_TELA_ID_MENU
T_FINANC_SINAL				= {'sinal:', '', ''},
T_FINANC_CONF_GRAV			= {'configura��o\ngravada', '', ''},


-- Mensagens do conexct.lua
T_FINANC_TST_CONEC			= {'teste de comunica��o\ntransa��o\ncompletada', '', ''},
T_FINANC_FAL_MSG_RET_SERV	= {'Falha na mensagem de retorno do servidor', '', ''},


-- Mensagens do configct.lua
T_FINANC_TRN_ACEITA			= {'transa��o aceita', '', ''},


-- Mensagens do credct.lua
T_FINANC_DESTAQUE_IMPR		= {'destaque a\nimpress�o', '', ''},
T_FINANC_ESCOLHA_OPC		= {'escolha uma op��o:', '', ''},  -- I_TELA_ID_MENU


-- Mensagens do debct.lua
T_FINANC_DATA_INVAL			= {'data inv�lida', '', ''},


-- Mensagens do errrn.lua
T_FINANC_SEM_ERRO			= {'n�o existe erro a \nser exibido', '', ''},


-- Mensagens do estornct.lua
T_FINANC_TRN_NAO_EXISTE		= {'transa��o\nn�o existe', '', ''},


-- Mensagens do finalct.lua
T_FINANC_TERM_FIN			= {'terminal finalizado\ncom sucesso', '', ''},


-- Mensagens do pagct.lua
T_FINANC_DESC_VIA_CLI		= {'deseja descartar\nvia do cliente?', '', ''},


-- Mensagens do quedact.lua
T_FINANC_DEST_PRI_VIA		= {'destaque a via 1\npressione entra', '', ''},
T_FINANC_QUEDA_ENERG_EST	= {'queda de energia\ndeseja estornar �ltima\ntransa��o?\naute: ', '', ''},


-- Mensagens do reimprct.lua
T_FINANC_FALHA_PROC			= {'falha durante o processo.', '', ''},


-- Mensagens do relatct.lua
T_FINANC_NAO_TRN_IMPR		= {'n�o existem\ntransac�es a serem\nimpressas', '', ''},


-- Mensagens do serct.lua
T_FINANC_PROCESSANDO		= {'Processando', '', ''},
T_FINANC_CPF_CNPJ_INV		= {'CPF/CNPJ invalido', '', ''},
T_FINANC_RESP_INCOR			= {'Resposta incorreta', '', ''},


-- Mensagens do telautct.lua
T_FINANC_ATU_TERM_DOWN		= {'existe uma\natualiza��o para\nseu terminal\nrealizar o download:', '', ''},
T_FINANC_CONC_ATU_ANT_DOWN	= {'conclua a atualiza��o \nantes de iniciar \num novo download', '', ''},


-- Mensagens do termct.lua
T_FINANC_QTD_TENT_EXCED		= {'quantidade de tentativas excedidas', '', ''},
T_FINANC_FECH_DIG_SEN		= {'fechado\ndigite a senha', '', ''},


-- Mensagens do transct.lua
T_FINANC_RET_CART			= {'retire o cart�o', '', ''},
T_FINANC_PAS_CART			= {'insira o cart�o', '', ''},
T_FINANC_INS_CART			= {'passe o cart�o', '', ''},
T_FINANC_DIG_CART			= {'digite o cart�o', '', ''},
T_FINANC_INS_PAS_DIG_CART	= {'passe, insira ou\n digite o cart�o', '', ''},
T_FINANC_INS_PAS_APROX_CART	= {'insira, passe \nou aproxime \no cart�o', '', ''},
T_FINANC_APP_NAO_SUP		= {'aplica��o\nn�o suportada', '', ''},
T_FINANC_APP_INV			= {'aplicacao inv�lida', '', ''},
T_FINANC_APP_BLOQ			= {'aplica��o bloqueada!\nligue emissor', '', ''},
T_FINANC_ERRO_LEIT_TENT		= {'erro de leitura\ntente novamente', '', ''},
T_FINANC_ERRO_LEIT			= {'erro de leitura', '', ''},
T_FINANC_CART_INVAL			= {'cart�o inv�lido', '', ''},
T_FINANC_CART_PROBL			= {'cart�o\ncom problema', '', ''},
T_FINANC_TRN_EFET_CONC		= {'transa��o\nefetuada e\nconclu�da', '', ''},
T_FINANC_IMPR_VIA_CLI		= {'imprimir via\ndo cliente?', '', ''},
T_FINANC_VERIF_LOTE			= {'verificando lote\naguarde um momento', '', ''},
T_FINANC_NAO_RET_CART		= {'n�o retire\no cart�o', '', ''},
T_FINANC_TROCAR_BOBINA		= {'favor trocar a\nbobina de papel', '', ''},


-- Mensagens do vouct.lua
T_FINANC_SEN_ATU_SUC		= {'senha atualizada com sucesso', '', ''},

},  -- Dialog FINANCRN


--[[
	RECARGRN
--]]

-- Mensagens para o Input
tRecargInput = {

-- Mensagens do cstrings.lua (initct.lua)
T_RECARG_REC_CEL			= {'recarga celular', '', ''},
T_RECARG_CEL				= {'ddd + n. celular: ', '', ''},
T_RECARG_CONF_CEL			= {'confirme ddd + n. celular: ', '', ''},


}, -- Input Recarg


-- Mensagens para o Dialog
tRecargDialog = {

-- Mensagens do cstrings.lua (initct.lua)
T_RECARG_CEL_INCOR			= {'n. do celular \n incorreto', '', ''},


-- Mensagens do conexct.lua
T_RECARG_PROCESSANDO		= {'processando', '', ''},


-- Mensagens do initct.lua
T_RECARG_SELEC_OPER			= {'selecione a operadora:', '', ''},			-- I_TELA_ID_MENU
T_RECARG_SELEC_VLR			= {'selecione o valor da recarga:', '', ''},	-- I_TELA_ID_MENU
T_RECARG_FORM_PGTO			= {'forma de pagamento:', '', ''},				-- I_TELA_ID_MENU
T_RECARG_AGUARDE			= {'aguarde', '', ''},


-- Mensagens do main.lua
T_RECARG_OPER_CANC			= {'opera��o \ncancelada', '', ''},


-- Mensagens do main.lua
T_RECARG_SERV_INDISP		= {'servi�o\nn�o dispon�vel', '', ''},
T_RECARG_TRN_APROV			= {'transa��o\naprovada', '', ''},
T_RECARG_DESC_VIA_CLI		= {'deseja descartar\nvia do cliente?', '', ''},
T_RECARG_IMPR_VIA_CLI		= {'imprimir via\ndo cliente?', '', ''},
T_RECARG_IMPRIMINDO			= {'imprimindo', '', ''},


}, -- Dialog Recarg


--[[
	RAVRN
--]]


-- Mensagens para o Input
tRavInput = {

-- Mensagens do cinit.lua (automct.lua)
T_RAV_DIG_SENHA_RAV			= {'digite a senha do rav \nno teclado num�rico: ', '', ''},


-- Mensagens do parct.lua
T_RAV_VALOR					= {'valor: ', '', ''},


-- Mensagens do senhact.lua
T_RAV_CPF_PROP				= {'cpf do propriet�rio:', '', ''},
T_RAV_AG_DOMIC				= {'ag�ncia domic�lio: ', '', ''},
T_RAV_CONTA_COR_DOMIC		= {'c. corrente domic�lio: ', '', ''},
T_RAV_CEP					= {'cep: ', '', ''},


}, -- Input Rav


-- Mensagens para o Dialog
tRavDialog = {

-- Mensagens do automct.lua
T_RAV_AGUARDE				= {'aguarde', '', ''},
T_RAV_RAV_AUTO_EFET_SUC		= {'rav autom�tico \nefetuado com\n sucesso', '', ''},
T_RAV_IMPR_COMPR			= {'deseja imprimir\ncomprovante?', '', ''},
T_RAV_IMPRIMINDO			= {'imprimindo', '', ''},


-- Mensagens do conexct.lua
T_RAV_PROCESSANDO			= {'processando', '', ''},
T_RAV_ERRO_CHAVE			= {'erro de chave\nligar rede', '', ''},


-- Mensagens do conexrn.lua
T_RAV_REFACA_COD_G4_3		= {'por favor, refa�a\na transa��o.\nc�digo g4.3', '', ''},
T_RAV_SERV_INDISP			= {'servi�o n�o \ndispon�vel', '', ''},


-- Mensagens do initct.lua
T_RAV_CONSULTA				= {'consulta', '', ''},			-- I_TELA_ID_MENU
T_RAV_RESG_SENHA			= {'resgate de senha', '', ''},	-- I_TELA_ID_MENU
T_RAV_RAV_AVULSO			= {'rav avulso', '', ''},		-- I_TELA_ID_MENU
T_RAV_RAV_AUTO				= {'rav autom�tico', '', ''},	-- I_TELA_ID_MENU
T_RAV_SALDO_DISP			= {'saldo dispon�vel', '', ''},	-- I_TELA_ID_MENU
T_RAV_RAV_TOTAL				= {'rav total', '', ''},		-- I_TELA_ID_MENU
T_RAV_RAV_PARC				= {'rav parcial', '', ''},		-- I_TELA_ID_MENU
T_RAV_MSG_RAV_AUTO			= {'com o rav autom�tico voc� \nreceber� vendas a cr�dito(� \nvista e parcelado) sempre no \npr�ximo dia �til ap�s a venda', '', ''},


-- Mensagens do main.lua
T_RAV_OPER_CANC				= {'opera��o\ncancelada', '', ''},


-- Mensagens do parct.lua
T_RAV_MSG_TARIF_DESC		= {'esta transa��o incide tarifa de \nprocessamento a ser \ndescontada em seus \nvencimentos futuros', '', ''},
T_RAV_RAV_PARC_EFET			= {'rav parcial efetuado \ncom sucesso', '', ''},
T_RAV_MSG_RAV_PARC			= {'o valor dispon�vel pode ser \nsuperior ao valor solicitado,\npois a composi��o do rav varia de \nacordo com as vendas do \nper�odo', '', ''},


-- Mensagens do senhact.lua
T_RAV_CPF_INVAL				= {'cpf inv�lido\n tente novamente', '', ''},
T_RAV_SEN_RESG_SUC			= {'senha resgatada\n com sucesso\n', '', ''},


-- Mensagens do totalct.lua
T_RAV_RAV_TOT_EFET_SUC		= {'rav total efetuado\n com sucesso', '', ''},


-- Mensagens do transct.lua
T_RAV_REFACA_COD_G4_1		= {'por favor, refa�a\na transa��o.\nc�digo g4.1', '', ''},
T_RAV_FALHA_CONEX			= {'falha de conex�o', '', ''},

}, -- Dialog Rav


--[[
	SERASARN
--]]

-- Menasgens de Input
tSerasaInput = {

-- Mensagens do serct.lua
T_SERASA_CMC7_BLOCO_1		= {'CMC-7 Bloco 1:', '', ''},
T_SERASA_NRO_BANCO			= {'n�mero do banco:', '', ''},
T_SERASA_CMC7_BLOCO_2		= {'CMC-7 Bloco 2:', '', ''},
T_SERASA_CMC7_BLOCO_3		= {'CMC-7 Bloco 3:', '', ''},
T_SERASA_DDD				= {'(DDD):', '', ''},
T_SERASA_FONE				= {'FONE:', '', ''},
T_SERASA_NRO_AGENCIA		= {'n�mero da ag�ncia:', '', ''},
T_SERASA_CONTA_COR			= {'C/C:', '', ''},
T_SERASA_NRO_CHEQUE			= {'n�mero cheque:', '', ''},
T_SERASA_DATA_DDMMAA		= {'data (ddmmaa):', '', ''},
T_SERASA_VALOR				= {'valor:', '', ''},
T_SERASA_CPF_CNPJ			= {'CPF/CNPJ:', '', ''},


}, -- Input Serasa


-- Menasgens de Dialog
tSerasaDialog = {

-- Mensagens do conexct.lua
T_SERASA_PROCESSANDO		= {'processando', '', ''},
T_SERASA_ERRO_CHV			= {'erro de chave\nligar rede', '', ''},


-- Mensagens do conexrn.lua
T_SERASA_REFACA_COD_G4_3	= {'por favor, refa�a\na transa��o.\nc�digo g4.3', '', ''},
T_SERASA_SERV_INDISP		= {'servi�o n�o \ndispon�vel', '', ''},


-- Mensagens do main.lua
T_SERASA_OPER_CANC			= {'opera��o \ncancelada', '', ''},


-- Mensagens do serct.lua
T_SERASA_DATA_INV			= {'data inv�lida', '', ''},
T_SERASA_DADO_INV			= {'dado inv�lido', '', ''},
T_SERASA_LIG_COD_A6_010		= {'por favor, ligue para\nrede e informe\nc�digo a.6-010', '', ''},
T_SERASA_REFACA_COD_G4_1	= {'por favor, refa�a\na transa��o.\nc�digo g4.1', '', ''},
T_SERASA_DEST_IMPR			= {'destaque a\nimpress�o', '', ''},


-- Mensagens do transct.lua
T_SERASA_FALHA_CONEX			= {'falha de conex�o', '', ''},

}, -- Dialog Serasa


--[[
	LOGISTIC
--]]

-- Mensagens para Dialog
tLogisticDialog = {

-- Mensagens do gui.lua
T_LOGISTIC_ERRO_ITERAC		= {'erro na itera��o com a RN', '', ''},
T_LOGISTIC_INI_APP			= {'iniciando\naplica��o', '', ''},


-- Mensagens do main.lua
T_LOGISTIC_OPER_CANC		= {'opera��o\ncancelada', '', ''},

}, -- Dialog Logistic


--[[
	CONFIG
--]]

-- Mensagens para Dialog
tConfigDialog = {

-- Mensagens do gui.lua
T_CONFIG_ERRO_ITERAC		= {'erro na itera��o com a RN', '', ''},

}, -- Dialog Config

} -- tMsgTexto fim
