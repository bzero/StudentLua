-- Copia da shortenMessages da graph250

local tableShorten = {}
	tableShorten["digite a senha atual do lojista\nno teclado numérico%:"]			
														= "senha lojista%:"
	tableShorten["parcelado estabelec"]					= "parc. estabel"
	tableShorten["parcelado emissor"]					= "parc. emissor"
	tableShorten["pré%-\nautorização"]					= "pré-autoriz"
	tableShorten["chave posicão 02"]					= "chave pos 02"
	tableShorten["chave posicão 08"]					= "chave pos 08"
	tableShorten["recarga de celular"]					= "recarga celular"
	tableShorten["digite a senha do lojista\n"]			= "senha lojista"
	tableShorten[" no teclado numérico"]				= ""
	tableShorten[" no teclado numerico"]				= ""
	tableShorten["no teclado numérico:"]				= ""
	tableShorten["no teclado numerico:"]				= ""
	tableShorten["digite a senha atual:"]        		= "digite a senha\natual:"
	tableShorten["digite a senha do técnico"]			= "senha técnico:"
	tableShorten["estabelec "]							= "estabelecimento"
	tableShorten["digite a senha de inicialização"]		= "senha inicialização:"
	tableShorten["digite a senha de inicialização \nno teclado numérico:"]
														= "senha inicialização:"
	tableShorten["digite a senha atual"]				= "digite a senha atual:"
	tableShorten["digite a nova senha\n"]				= "digite nova senha:"
	tableShorten["confirme a nova senha"]				= "confirme a nova\nsenha:"
	tableShorten["cartão\ncom problema"]				= "cartão com problema"
	tableShorten["por favor, refaça\na transação%.\ncódigo g4%.1"]
														= "tente de novo-to"
	tableShorten["por favor, refaça\na transação%.\ncod%. g4%.3"]
														= "tente de novo-id"
	tableShorten["por favor, refaça\na transação%.\ncódigo g4%.3"]
														= "tente de novo-id"
	tableShorten["por favor, ligue para\nrede e informe\ncódigo a%.6%-010"] 
														= "tente de novo–na"
	tableShorten["digite NUM DOZE DIGITOS"]				= "NUM DOZE DIGITOS"                            
	tableShorten["cartao invalido"]						= "cartão inválido"
	tableShorten["operação\ncancelada"]					= "operação cancelada"
	tableShorten["queda de energia\ndeseja estornar última\ntransação%?\n"]
														= "estornar "
	tableShorten["aute: "]								= "AUTE: "
	tableShorten["\nconfirmar estorno%?"]        = ""
	tableShorten["transação\nnão realizada\nidêntica a anterior"]     
                            							= "transação não realizada\nidêntica a anterior"
	tableShorten["valor%-"]                = "valor: "

--mensagens rav
tableShorten["com o rav automático você \nreceberá vendas a crédito%(à \nvista e parcelado%) sempre no \npróximo dia útil após a venda"] = 
				"~L016~F08com o rav automático\r"   ..
				"~L016~F08você receberá vendas a\r" ..
				"~L016~F08crédito (à vista e\r"     ..
				"~L016~F08parcelado)\r"             ..
				"~L016~F08sempre no próximo dia\r"  ..
				"~L016~F08útil após a venda\r\r"    ..
				"~L016~F08contratar?"

tableShorten["o valor disponível pode ser \nsuperior ao valor solicitado,\npois a composição do rav varia de \nacordo com as vendas do \nperíodo"]
			= "~L016~F08O valor disponível\r"            ..
             "~L016~F08pode ser superior ao\r"          .. 
             "~L016~F08valor solicitado,pois\r"         .. 
             "~L016~F08a composição de\r"               .. 
             "~L016~F08valores do rav varia\r"          .. 
             "~L016~F08de acordo com as\r"              .. 
             "~L016~F08vendas do período\r"             
             

shrg250 = {}

---
--Encurta mensagens
--@author Daniel Agra
--@param str String
--@return String encurtada
function shrg250.shortenMessages(str)
  if str ~= "" and str ~= nil then
    for iIndex ,tParams in pairs(tableShorten) do
    if (iIndex ~= tParams) then
      str = string.gsub(str, iIndex, tParams)
    end
    end
  else
    str = ""
  end

  return str
end
