require('hutil')
require('cgrafico')
require('logdebug')

-- adicionado para a traducao
require ('cmsgaux')
require ('shrmono')
require ('shrg250')

I_ALINHADO_ESQUERDA = 0
I_ALINHADO_CENTRO 	= 1
I_ALINHADO_DIREITA 	= 2

-- ========================================= TRATAMENTO DEVICE ========================================= 
--capacidades da tela
local dados, err = nil
if (device and device.screen_get_capabilities) then
    dados, err = device.screen_get_capabilities()
end

--colorido touch (iwl280 e vx680)
if dados and dados[1].mode == 3 and dados[1].orientation == 1 then
	PLATF_DISPL_TOUCH = 1
	require ('gui')
--colorido, paisagem sem touch (ict250)
elseif dados and dados[1].mode == 3 and dados[1].orientation == 2 then
	PLATF_DISPL_GRAFICO = 1
	require ('gui')
-- monocromatico
elseif dados and dados[1].mode == 2 then
	require ('guimono')
--suportando legado POO (entregas 1 e 2 da plataforma), colorido touch
else
	PLATF_DISPL_TOUCH = 1
	require ('gui')
end

-- ==================================== Outras funcoes ====================================
CriaTxt3Form = function (sTexto)
	-- Retorno do texto nos 3 formatos
	tRet3Form = {'', '', ''}
	
	-- O primeiro formato eh o original
	tRet3Form[1] = sTexto
	
					-- Traduz a string para os 2 formatos
					sFmtG250 = shrg250.shortenMessages (sOrigem)
					sFmtMono = shrmono.shortenMessages (sOrigem)
					
					-- Para monocromatico, tambem remove os acentos
					sFmtMono = shrmono.stripAccents (sFmtMono)
					
	-- Formata para o segundo formato
	tRet3Form[2] = shrg250.shortenMessages (sTexto)
	
	-- Formata para o segundo formato
	tRet3Form[3] = shrmono.stripAccents (shrmono.shortenMessages (sTexto))
	
	-- Retorna o resultado
	return tRet3Form
end

-- ==================================== Outras funcoes ====================================
OutrasFncs = function (tTela)

	-- Funcoes
	-- "Copia dig",
	-- "Aguarda 3 seg",
	-- "Calc soma",
	-- "Sair via bot�o"
	-- "Traduz Strings"
	-- "Traduz Var"
	I_FUNC_COPIA_DIG		= 0
	I_FUNC_AGUARDA_3_SEG	= 1
	I_FUNC_CALC_SOMA		= 2
	I_FUNC_SAIR_VIA_BOTAO	= 3
	I_FUNC_TRADUZ_STR		= 4
	I_FUNC_TRADUZ_VAR		= 5

	-- Verifica funcao selecionada
	local iFunc = tTela.params[1]
	if (iFunc == I_FUNC_COPIA_DIG) then

		-- Acertando os parametros para receber um valor
		tTela.params = {sTitulo = "Copia digitado",
						sTexto = "Digite algo a copiar", 
						iTamanhoMin = 1, -- minimo de caracteres
						iTamanhoMax = 4, -- maximo de caracteres
						fLerCartao = false, -- aceitar cart�o, chip e tarja
						fCampoSenha = true, -- Input de senha (para nao mostrar o que digitou)
						fEValor = false} -- passagem de valor R$

		-- Recupera o que for digitado
		tTela = tGUI.Input (tTela)

		-- Verifica pelo primeiro parametro retornado, se retornou Ok
		if (tTela.params[1] == RET_OK or tTela.params[1] == HF_BUTTON_KEYBOARD_ACCEPT_BUTTON) then

			-- Mostra o digitado
			tTela.params = {sTitulo = "",
							sTexto = "Voc� digitou> "..tTela.params[2],
							fLerCartao = false,
							iTempo = 10,
							fTrataTempo = true,
							tBotoesRodape = {	"Acertei?", 
												"Errei?"}
							}

			tTela = tGUI.Dialog(tTela)

		end

	elseif (iFunc == I_FUNC_AGUARDA_3_SEG) then

		-- Dialogo
		tTela.params = {sTitulo = "Aguarda 3 segundos",
						sTexto = "Aguardando ...",
						fLerCartao = false,
						iTempo = 3,
						fTrataTempo = true
						}

		-- Mostra e pronto, continua depois de 3 segundos
		tTela = tGUI.Dialog(tTela)

	elseif (iFunc == I_FUNC_CALC_SOMA) then

		-- Acertando os parametros para receber um valor
		tTela.params = {sTitulo = "Soma de valores",
						sTexto = "Digite o primeiro valor", 
						iTempo = 10, -- aguarda de 10 segundos
						fTrataTempo = true,
						fLerCartao = false, -- aceitar cart�o, chip e tarja
						fCampoSenha = false, -- Input de senha
						fEValor = true} -- passagem de valor R$

		-- Recupera o primeiro valor
		tTela = tGUI.Input (tTela)

		-- Caso tenha retornado Ok
		if tTela.params[1] == RET_OK or tTela.params[1] == HF_BUTTON_KEYBOARD_ACCEPT_BUTTON then

			-- Salva o valor convertendo-o
			local iValUm = tonumber (tTela.params[2])
			
			-- Ajusta parametros pro segundo parametro
			
			-- Acertando os parametros para receber um valor
			tTela.params = {sTitulo = "Soma de valores",
							sTexto = "Digite o segundo valor", 
							iTempo = 10, -- aguarda de 10 segundos
							fTrataTempo = true,
							fLerCartao = false, -- aceitar cart�o, chip e tarja
							fCampoSenha = false, -- Input de senha
							fEValor = true} -- passagem de valor R$

			-- Recupera o segundo valor
			tTela = tGUI.Input (tTela)
			
			-- Caso tenha retornado Ok de novo
			if tTela.params[1] == RET_OK or tTela.params[1] == HF_BUTTON_KEYBOARD_ACCEPT_BUTTON then
			
				-- Salva o segundo valor convertendo-o tambem
				local iValDois = tonumber (tTela.params[2])
				
				-- Soma e mostra o resultado
				tTela.params = {sTitulo = "Soma de valores",
								sTexto = "Resultado> "..tostring (iValUm + iValDois),
								fLerCartao = false,
								iTempo = 10,
								fTrataTempo = true,
								tBotoesRodape = { "Acertei?", "Errei?" }
								}

				tTela = tGUI.Dialog(tTela)

			end

		end

	elseif (iFunc == I_FUNC_SAIR_VIA_BOTAO) then

		-- Dialogo
		tTela.params = {sTitulo = "Op��o Sair",
						sTexto = "Saindo ...",
						fLerCartao = false,
						iTempo = 3,
						fTrataTempo = true
						}

		-- Mostra e sai depois de 3 segundos
		tTela = tGUI.Dialog(tTela)
		
		-- Retorna falso pra sair
		return false

	elseif (iFunc == I_FUNC_TRADUZ_STR) then

		-- Traduz toda a tabela de mensagens de texto (tMsgTexto)
		
		-- Print informativo
		printer.print ('Iniciando traducao...')
		
		-- Tabela com a lista de tabelas para traduzir
		tTabTrad = {'tMsgTexto.tFinancInput   ', 'tMsgTexto.tFinancDialog',
					'tMsgTexto.tRecargInput   ', 'tMsgTexto.tRecargDialog',
					'tMsgTexto.tRavInput      ', 'tMsgTexto.tRavDialog   ',
					'tMsgTexto.tSerasaInput   ', 'tMsgTexto.tSerasaDialog',
					'tMsgTexto.tLogisticDialog', 'tMsgTexto.tConfigDialog'}
		
		-- caso o arquivo ja exista, remove para depois abrir novamente (emula uma abertura com w+)
		os.remove ('cmsgtxt.lua')
		
		-- Abre um arquivo para gravar as informacoes da traducao
		arqSaida, sMsgErroAbert = io.open ('cmsgtxt.lua', 'rw')
		
		-- Verifica erro na abertura do arquivo
		if arqSaida == nil then
			printer.print ('Erro abrindo arquivo: ' .. sMsgErroAbert)
			return false
		end
		
		-- Escreve o comentario inicial
		arqSaida:write ('-- Constantes das mensagens de texto\n')
		
		-- Loop de cada uma das tabelas
		for iIndAtu, sTabAtu in ipairs (tTabTrad) do
		
			-- Escreve um comentario para separar as tabelas
			arqSaida:write ('\n\n--[[\n' ..
							'	'.. sTabAtu .. '\n' ..
							'--]]\n\n')
			
			-- loadstring carrega um trecho de codigo em formato de string desse modo, ...
			-- ... executa ela e retorna a table que esta em formato de string
			tTabRetLoad = loadstring ('return ' .. sTabAtu) ()
			
			-- Pega o primeiro indice da tabela atual
			sIndice, tStrMens = next (tTabRetLoad)
			
			-- Loop de processamento de cada indice da tabela
			while sIndice do
			
				-- Para tratar o "continue"
				repeat
	
					-- Copia a string original
					sOrigem = tStrMens[1]
					
					-- Verifica conteudo da string
					if not sOrigem then
						-- Indica string vazia na impressora
						printer.print ('Indice [' .. sIndice .. '] com a string vazia')
						break	-- 'until true' me "tranforma" isso num continue
					end
					
					-- Traduz a string para os 2 formatos
					sFmtG250 = shrg250.shortenMessages (sOrigem)
					sFmtMono = shrmono.shortenMessages (sOrigem)
					
					-- Para monocromatico, tambem remove os acentos
					sFmtMono = shrmono.stripAccents (sFmtMono)
					
					-- Substitui todas as barras invertidas por barras duplas invertidas
					sOrigem = string.gsub (sOrigem, '\n', '\\n')
					sFmtG250 = string.gsub (sFmtG250, '\n', '\\n')
					sFmtMono = string.gsub (sFmtMono, '\n', '\\n')
					sOrigem = string.gsub (sOrigem, '\r', '\\r')
					sFmtG250 = string.gsub (sFmtG250, '\r', '\\r')
					sFmtMono = string.gsub (sFmtMono, '\r', '\\r')

					-- Escreve no arquivo de saida a linha formatando os valores
					arqSaida:write (sIndice .. ' = {\n' ..
									'	\'' .. sOrigem .. '\',\n' ..
									'	\'' .. sFmtG250 .. '\',\n' ..
									'	\'' .. sFmtMono .. '\'\n' ..
									'}\n\n')

				-- para simulacao do continue
				until true		-- repeat

				-- Avanca pro proximo indice
				sIndice, tStrMens = next (tTabRetLoad, sIndice)

			end		-- while

		end		-- for

		-- Indica o arquivo foi gerado
		printer.print ('Arquivo de saida gerado [cmsgtxt.lua]')
		
		-- Fecha entao o arquivo utilizado
		-- (antes do coletor, que leva uma quantidade indeterminada de tempo)
		arqSaida:close ()
	
		-- Dialogo
		tTela.params = {sTitulo = "Traduz String",
						sTexto = "Traducao concluida (vide destino na impressora)",
						fLerCartao = false,
						iTempo = 3,
						fTrataTempo = true
						}

		-- Mostra a mensagem de sucesso e sai depois de 3 segundos
		tTela = tGUI.Dialog(tTela)
		
	elseif (iFunc == I_FUNC_TRADUZ_VAR) then

		-- Acertando os parametros para receber um valor
		tTela.params = {sTitulo = "Traduz Variavel",
						sTexto = "Digite valor a concatenar", 
						iTamanhoMin = 1, -- minimo de caracteres
						iTamanhoMax = 4, -- maximo de caracteres
						fLerCartao = false, -- aceitar cart�o, chip e tarja
						fCampoSenha = false, -- Input de senha (para mostrar o que digitou)
						fEValor = false} -- passagem de valor R$

		-- Recupera o que for digitado
		tTela = tGUI.Input (tTela)

		-- Verifica pelo primeiro parametro retornado, se retornou Ok
		if (tTela.params[1] == RET_OK or tTela.params[1] == HF_BUTTON_KEYBOARD_ACCEPT_BUTTON) then

			-- Concatena em um texto qualquer traduzindo para os 3 formatos de display
			tTraduzido = CriaTxt3Form ('valor-' .. tTela.params[2] .. '\nconfirmar estorno?')
			
			-- Imprime o resultado de cada um
			printer.print ('Original:\n' .. tTraduzido[1] .. '\n')
			printer.print ('Tradu��o gui250:\n' .. tTraduzido[2] .. '\n')
			printer.print ('Tradu��o quimono:\n' .. tTraduzido[3] .. '\n')
			
			-- Mostra o digitado
			tTela.params = {sTitulo = "",
							sTexto = "Ver impress�o dos resultados",
							fLerCartao = false,
							iTempo = 3,
							fTrataTempo = true
							}

			tTela = tGUI.Dialog(tTela)

		end

	else

		-- Sai sem "falar" nada
		return false

	end

	-- Retorna e continua no menu superior
	return true
end     -- Fim das outras funcoes (OutrasFncs)

-- ========================================= MAIN ========================================= 
function main(params, identity)
	
	-- Iniciando as configura��es da GUI
	local iRet = tGUI.Init()
	if iRet ~= 0 then
		return
	end
	
	while true do
		local tTela = {}
		tTela.params = { sTitulo = "APP Teste", 
						 iTempo = 30, 
						 fTrataTempo = true,
						 tItens = { "Dialog", 
									"Menu",
									"Input",
									-- "Input" -- Inserindo novos itens
									-- Inserindo novos itens
									"Outros"
						} }
		
		tGUI.Menu(tTela)
		local iTecla = tTela.params[1]
		--printer.print("iTecla "..tostring(iTecla))
		if (iTecla == 0) then
			--DIALOG
			tTela.params = {sTitulo = "", 
							sTexto = "Dialog Exemplo", 
							fLerCartao = false, 
							iTempo = 10,
							fTrataTempo = true,
							tBotoesRodape = {	"botao 1", 
												"botao 2"}
							}
			tTela = tGUI.Dialog(tTela)
		elseif (iTecla == 1) then
			--MENU
			tTela.params = { sTitulo = "Menu Exemplo", 
							 iTempo = 10, -- timeout
							 fTrataTempo = true,
							 tItens = { "Item 1", 
										"Item 2"
							 } }
			
			tGUI.Menu(tTela)
		elseif (iTecla == 2) then
			--INPUT
			tTela.params = {sTitulo = "", sTexto = "n�mero ocorr�ncia:", iTamanhoMax = 4, iTamanhoMin = 4, bIsCampoSenha = false, iTempo = 10}
			--tTela.params = {sTitulo = "Input Exemplo", 
			--				sTexto = "Informa��o adicional", 
			--				--iTipo = 2, 
			--				iTamanhoMin = 1, -- minimo de caracteres
			--				iTamanhoMax = 4, -- maximo de caracteres
			--				fLerCartao = false, -- aceitar cart�o, chip e tarja
			--				--fCampoSenha = false, -- Input de senha
			--				fEValor = false} -- passagem de valor R$
			
			tGUI.Input(tTela)

		elseif (iTecla == 3) then
			--OUTROS
			tTela.params = { sTitulo = "Outras Op��es",
							 iTempo = 10, -- timeout
							 fTrataTempo = true,
							 tItens = { "Copia dig",
										"Aguarda 3 seg",
										"Calc soma",
										"Sair via bot�o",
										"Traduz Strings",
										"Traduz Variavel"}
							}

			-- Cria tela com novo menu
			tGUI.Menu(tTela)

			-- Chama a funcao para tratamento das funcoes desse menu
			if not OutrasFncs (tTela) then
			
				-- Falso, significa que eh pra sair
				return true

			end

		elseif (iTecla == 1001) then
			--SAIR
			return true
		end

	end
end
-- ========================================= FIM MAIN ========================================= 
