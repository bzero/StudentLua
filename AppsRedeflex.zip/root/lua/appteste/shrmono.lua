-- Copia da shortenMessages da guimono

local tableAccents = {}
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "c"
    tableAccents["�"] = "e"
    tableAccents["�"] = "e"
    tableAccents["�"] = "e"
    tableAccents["�"] = "e"
    tableAccents["�"] = "i"
    tableAccents["�"] = "i"
    tableAccents["�"] = "i"
    tableAccents["�"] = "i"
    tableAccents["�"] = "n"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "u"
    tableAccents["�"] = "u"
    tableAccents["�"] = "u"
    tableAccents["�"] = "u"
    tableAccents["�"] = "y"
    tableAccents["�"] = "y"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "C"
    tableAccents["�"] = "E"
    tableAccents["�"] = "E"
    tableAccents["�"] = "E"
    tableAccents["�"] = "E"
    tableAccents["�"] = "I"
    tableAccents["�"] = "I"
    tableAccents["�"] = "I"
    tableAccents["�"] = "I"
    tableAccents["�"] = "N"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "U"
    tableAccents["�"] = "U"
    tableAccents["�"] = "U"
    tableAccents["�"] = "U"
    tableAccents["�"] = "Y"

-- Estrutura das funcoes
shrmono = {}
 
---
--Strip accents from a string
--@author Marcelo Tosihiko Sigueoka
--@param str String
--@return String sem acentos

function shrmono.stripAccents( str )
        
    local normalizedString = ""
	
	if str then
 
		--for strChar in string.gfind(str, "([%z\1-\127\194-\244][\128-\191]*)") do
		-- LYF: o � n�o estava sendo encontrado. corresponde ao 250.
		for strChar in string.gfind(str, "([%z\1-\127\194-\250][\128-\191]*)") do
			if tableAccents[strChar] ~= nil then
				normalizedString = normalizedString..tableAccents[strChar]
			else
				normalizedString = normalizedString..strChar
			end
		end
	end
        
  return normalizedString
 
end

S_MENU_PARCELADO_ESTABELECIMENTO 						= "parcelado estabelec"
S_MENU_PARCELADO_EMISSOR 								= "parcelado emissor"
S_MENU_PRE_AUTORIZACAO 									= "pr�%-\nautoriza��o"
S_MENU_CAPTURA_CREDITO 									= "captura cr�dito"
S_MENU_OPCAO_SENHA 										= "resgate de senha"
S_MENU_SALDO 											= "saldo dispon�vel"
S_MENSAGEM_DIGITE_SENHA_RAV 							= "digite a senha do rav \nno teclado num�rico: "
S_DESEJA_REALIZAR_RAV_AVULSO							= "deseja realizar\nrav avulso%?"
S_CPF_RAV												= "cpf do propriet�rio:"
S_CONTRATAR_RAV_AUT										= "\ndeseja contratar rav\nautom�tico%?"
S_DESEJA_IMPRIMIR_COMPROVANTE							= "deseja imprimir\ncomprovante%?"

-- Lembra de mim - Adicionados por mim
-- S_TERM_ATU_COM_SUC										= "terminal atualizado\ncom sucesso \n\ndeseja conhecer as novas \nfun��es?"

local tableShorten = {}
    tableShorten["codigo"] 								= "cod."
	tableShorten["c�digo"] 								= "cod."
	tableShorten["numero"] 								= "no"
	tableShorten["nmero"] 								= "no"
	tableShorten["nm "] 								= "no "
	tableShorten["4 �ltimos d�gitos:"]					= "digite 4 ultimos \ndigitos:"	
	tableShorten["4 ultimos d�gitos:"]					= "digite 4 ultimos \ndigitos:"	
	tableShorten[" ltimos"] 							= " ultimos"
	tableShorten[S_MENU_PARCELADO_ESTABELECIMENTO]		= "parc. estabel"
	tableShorten[S_MENU_PARCELADO_EMISSOR] 				= "parc. emissor"
	tableShorten[S_MENU_PRE_AUTORIZACAO]				= "pre-autoriz"
	tableShorten["deseja descartar\nvia do cliente%?"]	= "deseja descartar\nvia do cliente?\n1.sim\n2.nao"
	tableShorten["imprimir via do cliente%?"] 			= "imprimir via do\ncliente?\n1.sim\n2.nao"
	tableShorten["imprimir via\n do cliente%?"] 		= "imprimir via do\ncliente?\n1.sim\n2.nao"
	tableShorten["imprimir via\ndo cliente%?"] 			= "imprimir via do\ncliente?\n1.sim\n2.nao"
	tableShorten[S_MENU_CAPTURA_CREDITO] 				= "capt credito"
	tableShorten["recarga celular"] 					= "recarga cel"
	tableShorten["recarga de celular"] 					= "recarga cel"
	tableShorten["c�digo seguran�a"] 					= "cod. seguran�a"
	tableShorten["private\nlabel"] 						= "private label"
	tableShorten["recarga cel"] 						= "recarga celular"
	tableShorten["deseja estornar �ltima transa��o"] 	= "deseja estornar �ltima\ntransa��o"
	tableShorten["consulta\n� cheque"] 					= "consulta cheque"
	tableShorten["consulta � cheque"] 					= "consulta cheque"
	tableShorten["digite a senha do lojista\r"] 		= "senha lojista"
	tableShorten[S_MENU_OPCAO_SENHA]					= "resgate senha"
	tableShorten[S_MENU_SALDO]							= "saldo disp."
	tableShorten[S_MENSAGEM_DIGITE_SENHA_RAV]			= "digite a senha do rav: "
	tableShorten[S_DESEJA_REALIZAR_RAV_AVULSO]			= "deseja realizar\nrav avulso?\n1.sim\n2.nao"
	tableShorten[S_CPF_RAV]								= "digite o cpf do\nproprietario:"	
	tableShorten[S_DESEJA_IMPRIMIR_COMPROVANTE]			= "deseja imprimir\ncomprovante?\n1.sim\n2.nao"
	tableShorten[S_CONTRATAR_RAV_AUT]					= "\ndeseja contratar\nrav autom�tico?\n1.sim\n2.nao"
	tableShorten["\nno teclado num�rico:"]				= ""
	tableShorten["\nno teclado numerico:"]				= ""
	tableShorten["n�mero de parcelas:"]					= "no parcelas:"
	tableShorten["\nno teclado num�rico:"]				= ""	
	-- tableShorten["confirmar estorno%?"]					= "confirmar?\n1.sim\n2.nao"
	tableShorten["ddd %+ n%. celular:"]					= "ddd+n.celular:"	
	tableShorten["por favor, refa�a\na transa��o.\nc�digo g4.1"]
														= "tente de novo-to"
	tableShorten["por favor, refa�a\na transa��o%.\ncod%. g4%.3"]
														= "tente de novo-id"
	-- akt: n�o remover (in�cio)
	tableShorten["por favor, refa�a\na transa��o%.\nc�digo g4%.3"]
	                         						 	= "tente de novo-id"
	-- akt: n�o remover (fim)

	tableShorten["por favor, ligue para\nrede e informe\nc�digo a%.6%-010"] 
														= "tente de novo�na"
	tableShorten["\n no teclado numerico%:"]			= ""
	tableShorten["\n no teclado num�rico%:"]			= ""
	tableShorten["\nno teclado num�rico%:"]				= ""
	tableShorten["opera��o completada"]					= "opera��o\ncompletada"
	tableShorten["apaga desfazimento"]					= "apaga desfzto"
	tableShorten["apagar desfazimento"]					= "apagar desfzto"
	tableShorten["selecione a operadora"]				= "operadora"
	tableShorten["selecione o valor"]					= "valor recarga"
	tableShorten["realizar o download?"]				= "realizar o\ndownload?"
	tableShorten["existe uma atualiza��o para o seu terminal"]	
														= "existe uma\natualiza��o para o\nseu terminal"
	tableShorten["com o rav autom�tico voc� \nreceber� vendas a cr�dito%(� \nvista e parcelado%) sempre no \npr�ximo dia �til ap�s a venda"]
														= "com o rav autom�tico\nvoc� receber� vendas\na cr�dito (� vista e\nparcelado) sempre no\npr�ximo dia util\nap�s a venda"
	tableShorten["o valor dispon�vel pode ser \nsuperior ao valor solicitado,\npois a composi��o do rav varia de \nacordo com as vendas do \nper�odo"]
														= "o valor dispon�vel\npode ser superior ao\nsolicitado, pois a\ncomposi��o de\nvalores do rav\nvariam de acordo com\nas vendas do per�odo"
	tableShorten["teste de comunica��o\ntransa��o\ncompletada"] = " teste comunic.\ntrans.completada"
    tableShorten["codigo"] 								= "cod."
	tableShorten["c�digo"] 								= "cod."
	tableShorten["pesquisa documento"]					= "pesq. documento"
	tableShorten["digite a senha do lojista"]			= "senha lojista"
	tableShorten["N�mero do terminal%:"]				= "no. terminal"
	tableShorten["n�mero do terminal%:"]				= "no. terminal"
	tableShorten["Numero do terminal%:"]				= "no. terminal"
	tableShorten["numero do terminal%:"]				= "no. terminal"
	
	tableShorten["digite a senha de inicializa��o"]		= "senha inic."
	tableShorten["queda de energia\ndeseja estornar �ltima\ntransa��o"]			
														= "queda de energia\ndeseja estornar\n�ltima transa��o"
	tableShorten["transa��o\nn�o realizada\nid�ntica a anterior"]			
														= "transa��o\nn�o realizada\nid�ntica\na anterior"
	tableShorten["informe hora e minuto"]				= "digite a hora%: hh%:mm"
	tableShorten["conclua a atualiza%�%�o \nantes de iniciar \num novo download"]	
														= "atualizacao \npendente.conclua \nantes de iniciar \num novo download"
	tableShorten["atualiza%�%�o pendente"]				= ""
	tableShorten["n�o existem\ntransac�es a serem\nimpressas"] = "n�o existem\ntransac�es a\nserem impressas"
	tableShorten["digite a senha do t�cnico"]			= "senha tecnico"

	-- Lembra de mim - adicionados por mim
	-- tableShorten[S_TERM_ATU_COM_SUC] = "terminal\natualizado com\nsucesso\ndeseja\nconhecer\nas novas\nfuncoes?"
	tableShorten["confirmar estorno%?"]					= "CONFIRMA?"
	tableShorten["valor%-"]								= "VLR: "
	tableShorten["deseja desligar\no terminal?"]		= "funcao inativa"
	tableShorten["aguarde, seu terminal ser� \natualizado"]	= "aguarde, seu\nterminal sera\natualizado"  -- Lembra de mim - concatenar t�tulo com texto
	tableShorten["mantenha ligado a tomada \ndurante todo o processo"]	= "mantenha ligado\natomada durante\ntodo o processo"

---
--Encurta mensagens
--@author Marcelo Tosihiko Sigueoka
--@param str String
--@return String encurtada
function shrmono.shortenMessages( str )
-- [[
	if str ~= "" and str ~= nil then
		for iIndex ,tParams in pairs(tableShorten) do
			if (iIndex ~= tParams) then
				str = string.gsub(str, iIndex, tParams)
				--printer.print("str "..tostring(str))			
			end
		end		
	else 
		str = ""
	end
	--]]
	--printer.print("str "..str)
	--printer.print(hutil.hextostr(str))
	return str

end
