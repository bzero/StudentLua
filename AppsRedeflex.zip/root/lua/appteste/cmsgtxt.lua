-- Constantes das mensagens de texto


--[[
	tMsgTexto.tFinancInput   
--]]

T_FINANC_DDD = {
	'(DDD):',
	'(DDD):',
	'(DDD):'
}

T_FINANC_QUAT_ULT_DIG = {
	'4 �ltimos d�gitos:',
	'4 �ltimos d�gitos:',
	'digite 4 ultimos \ndigitos:'
}

T_FINANC_DOIS_ULT_DIG_TERM = {
	'dois �ltimos digitos do terminal:',
	'dois �ltimos digitos do terminal:',
	'dois ultimos digitos do terminal:'
}

T_FINANC_FONE = {
	'FONE:',
	'FONE:',
	'FONE:'
}

T_FINANC_NRO_AUTE = {
	'n�mero aute:',
	'n�mero aute:',
	'numero aute:'
}

T_FINANC_CMC7_BLOCO_2 = {
	'CMC-7 Bloco 2:',
	'CMC-7 Bloco 2:',
	'CMC-7 Bloco 2:'
}

T_FINANC_VENC_PUL = {
	'vencto. pular:',
	'vencto. pular:',
	'vencto. pular:'
}

T_FINANC_VALIDADE = {
	'validade (mm/aa):',
	'validade (mm/aa):',
	'validade (mm/aa):'
}

T_FINANC_ITEM = {
	'item:',
	'item:',
	'item:'
}

T_FINANC_DIG_SENHA_ATU_LOJ = {
	'digite a senha atual do lojista\nno teclado num�rico:',
	'digite a senha atual: do lojista\nno teclado num�rico:',
	'digite a senha atual do lojista'
}

T_FINANC_NRO_DOC = {
	'n�mero documento:',
	'n�mero documento:',
	'numero documento:'
}

T_FINANC_APN = {
	'apn:',
	'apn:',
	'apn:'
}

T_FINANC_DIG_SENHA_TEC = {
	'digite a senha do t�cnico\nno teclado num�rico:',
	'digite a senha do t�cnico\nno teclado num�rico:',
	'senha tecnico'
}

T_FINANC_VALOR = {
	'valor:',
	'valor:',
	'valor:'
}

T_FINANC_INF_HORA_MIN = {
	'informe hora e minuto',
	'informe hora e minuto',
	'digite a hora: hh:mm'
}

T_FINANC_DIG_SENHA_INI = {
	'digite a senha de inicializa��o\nno teclado num�rico:',
	'digite a senha de inicializa��o\nno teclado num�rico:',
	'senha inic.'
}

T_FINANC_COD_AUT = {
	'c�digo autoriza��o:',
	'c�digo autoriza��o:',
	'cod. autorizacao:'
}

T_FINANC_CMC7_BLOCO_1 = {
	'CMC-7 Bloco 1:',
	'CMC-7 Bloco 1:',
	'CMC-7 Bloco 1:'
}

T_FINANC_DIG_NOVA_SENHA = {
	'digite a nova senha',
	'digite a nova senha',
	'digite a nova senha'
}

T_FINANC_NRO_HABIL = {
	'n�mero habilita��o:',
	'n�mero habilita��o:',
	'numero habilitacao:'
}

T_FINANC_COD_SEG = {
	'c�digo seguran�a:',
	'c�digo seguran�a:',
	'cod. seguranca:'
}

T_FINANC_COND_PGTO = {
	'cond. pagto:',
	'cond. pagto:',
	'cond. pagto:'
}

T_FINANC_NRO_PARC = {
	'n�mero de parcelas:',
	'n�mero de parcelas:',
	'no parcelas:'
}

T_FINANC_DATA_DDMMAA = {
	'data (ddmmaa):',
	'data (ddmmaa):',
	'data (ddmmaa):'
}

T_FINANC_CMC7_BLOCO_3 = {
	'CMC-7 Bloco 3:',
	'CMC-7 Bloco 3:',
	'CMC-7 Bloco 3:'
}

T_FINANC_NRO_OCOR = {
	'n�mero ocorr�ncia:',
	'n�mero ocorr�ncia:',
	'numero ocorrencia:'
}

T_FINANC_DIG_SENHA_LOJ = {
	'digite a senha do lojista\n no teclado num�rico:',
	'senha lojista no teclado num�rico:',
	'senha lojista'
}

T_FINANC_REP_NOVA_SENHA = {
	'repita a nova senha',
	'repita a nova senha',
	'repita a nova senha'
}

T_FINANC_POWER_OFF_MIN = {
	'power off (minutos):',
	'power off (minutos):',
	'power off (minutos):'
}

T_FINANC_NRO_ESTAB = {
	'n�m. do estabelecimento:',
	'n�m. do estabelecimento:',
	'num. do estabelecimento:'
}



--[[
	tMsgTexto.tFinancDialog
--]]

T_FINANC_NAO_RET_CART = {
	'n�o retire\no cart�o',
	'n�o retire\no cart�o',
	'nao retire\no cartao'
}

T_FINANC_CART_INVAL = {
	'cart�o inv�lido',
	'cart�o inv�lido',
	'cartao invalido'
}

T_FINANC_FAL_MSG_RET_SERV = {
	'Falha na mensagem de retorno do servidor',
	'Falha na mensagem de retorno do servidor',
	'Falha na mensagem de retorno do servidor'
}

T_FINANC_SEN_INV_TENT_NOV = {
	'senha inv�lida\ntente novamente',
	'senha inv�lida\ntente novamente',
	'senha invalida\ntente novamente'
}

T_FINANC_OPERAC_COMPL = {
	'opera��o completada',
	'opera��o completada',
	'operacao\ncompletada'
}

T_FINANC_DESC_VIA_CLI = {
	'deseja descartar\nvia do cliente?',
	'deseja descartar\nvia do cliente?',
	'deseja descartar\nvia do cliente?\n1.sim\n2.nao'
}

T_FINANC_TERM_ATU_SUC = {
	'terminal atualizado\ncom sucesso \n\ndeseja conhecer as novas \nfun��es?',
	'terminal atualizado\ncom sucesso \n\ndeseja conhecer as novas \nfun��es?',
	'terminal atualizado\ncom sucesso \n\ndeseja conhecer as novas \nfuncoes?'
}

T_FINANC_ESCOLHA_OPER = {
	'escolha a operadora',
	'escolha a operadora',
	'escolha a operadora'
}

T_FINANC_RESP_INCOR = {
	'Resposta incorreta',
	'Resposta incorreta',
	'Resposta incorreta'
}

T_FINANC_CMD_INAT = {
	'comando inativo',
	'comando inativo',
	'comando inativo'
}

T_FINANC_IMPR_VIA_CLI = {
	'imprimir via\ndo cliente?',
	'imprimir via\ndo cliente?',
	'imprimir via do\ncliente?\n1.sim\n2.nao'
}

T_FINANC_VLR_OU_CART = {
	'digite o valor, insira\nou passe o cart�o',
	'digite o valor, insira\nou passe o cart�o',
	'digite o valor, insira\nou passe o cartao'
}

T_FINANC_EFET_BAIXA_TEC = {
	'efetue\nbaixa t�cnica',
	'efetue\nbaixa t�cnica',
	'efetue\nbaixa tecnica'
}

T_FINANC_OPER_CANC = {
	'opera��o\ncancelada',
	'opera��o\ncancelada',
	'operacao\ncancelada'
}

T_FINANC_CPF_CNPJ_INV = {
	'CPF/CNPJ invalido',
	'CPF/CNPJ invalido',
	'CPF/CNPJ invalido'
}

T_FINANC_SEM_DESF = {
	'n�o h� desfazimento',
	'n�o h� desfazimento',
	'nao ha desfazimento'
}

T_FINANC_SEN_INV = {
	'senha invalida!',
	'senha invalida!',
	'senha invalida!'
}

T_FINANC_REALIZ_NOVA_ATU = {
	'realizar nova \ntentativa \nde atualiza��o?',
	'realizar nova \ntentativa \nde atualiza��o?',
	'realizar nova \ntentativa \nde atualizacao?'
}

T_FINANC_QUEDA_ENERG_EST = {
	'queda de energia\ndeseja estornar �ltima\ntransa��o?\naute: ',
	'queda de energia\ndeseja estornar �ltima\ntransa��o?\nAUTE: ',
	'queda de energia\ndeseja estornar\nultima transacao?\naute: '
}

T_FINANC_APP_BLOQ = {
	'aplica��o bloqueada!\nligue emissor',
	'aplica��o bloqueada!\nligue emissor',
	'aplicacao bloqueada!\nligue emissor'
}

T_FINANC_QTD_TENT_EXCED = {
	'quantidade de tentativas excedidas',
	'quantidade de tentativas excedidas',
	'quantidade de tentativas excedidas'
}

T_FINANC_SEM_MSGS = {
	'n�o h� msgs',
	'n�o h� msgs',
	'nao ha msgs'
}

T_FINANC_ESCOLHA_OPC = {
	'escolha uma op��o:',
	'escolha uma op��o:',
	'escolha uma opcao:'
}

T_FINANC_TRN_NAO_EXISTE = {
	'transa��o\nn�o existe',
	'transa��o\nn�o existe',
	'transacao\nnao existe'
}

T_FINANC_DESL_TERM = {
	'deseja desligar\no terminal?',
	'deseja desligar\no terminal?',
	'funcao inativa?'
}

T_FINANC_PROCESSANDO = {
	'Processando',
	'Processando',
	'Processando'
}

T_FINANC_ERRO_LEIT = {
	'erro de leitura',
	'erro de leitura',
	'erro de leitura'
}

T_FINANC_TST_CONEC = {
	'teste de comunica��o\ntransa��o\ncompletada',
	'teste de comunica��o\ntransa��o\ncompletada',
	' teste comunic.\ntrans.completada'
}

T_FINANC_FALHA_PROC = {
	'falha durante o processo.',
	'falha durante o processo.',
	'falha durante o processo.'
}

T_FINANC_APP_INV = {
	'aplicacao inv�lida',
	'aplicacao inv�lida',
	'aplicacao invalida'
}

T_FINANC_FNC_INAT = {
	'fun��o inativa',
	'fun��o inativa',
	'funcao inativa'
}

T_FINANC_NAO_DESL_TOMADA = {
	'mantenha ligado a tomada \ndurante todo o processo',
	'mantenha ligado a tomada \ndurante todo o processo',
	'mantenha ligado\natomada durante\ntodo o processo'
}

T_FINANC_DESTAQUE_IMPR = {
	'destaque a\nimpress�o',
	'destaque a\nimpress�o',
	'destaque a\nimpressao'
}

T_FINANC_FALHA_CONEXAO = {
	'falha de conex�o',
	'falha de conex�o',
	'falha de conexao'
}

T_FINANC_NAO_TRN_IMPR = {
	'n�o existem\ntransac�es a serem\nimpressas',
	'n�o existem\ntransac�es a serem\nimpressas',
	'nao existem\ntransacoes a\nserem impressas'
}

T_FINANC_TRN_ACEITA = {
	'transa��o aceita',
	'transa��o aceita',
	'transacao aceita'
}

T_FINANC_CONC_ATU_ANT_DOWN = {
	'conclua a atualiza��o \nantes de iniciar \num novo download',
	'conclua a atualiza��o \nantes de iniciar \num novo download',
	'atualizacao \npendente.conclua \nantes de iniciar \num novo download'
}

T_FINANC_LOTE_VAZIO = {
	'lote vazio',
	'lote vazio',
	'lote vazio'
}

T_FINANC_SEM_ERRO = {
	'n�o existe erro a \nser exibido',
	'n�o existe erro a \nser exibido',
	'nao existe erro a \nser exibido'
}

T_FINANC_SIM_CARD_AUSENTE = {
	'sim card\nausente',
	'sim card\nausente',
	'sim card\nausente'
}

T_FINANC_FECH_DIG_SEN = {
	'fechado\ndigite a senha',
	'fechado\ndigite a senha',
	'fechado\ndigite a senha'
}

T_FINANC_ATU_TERM_DOWN = {
	'existe uma\natualiza��o para\nseu terminal\nrealizar o download:',
	'existe uma\natualiza��o para\nseu terminal\nrealizar o download:',
	'existe uma\natualizacao para\nseu terminal\nrealizar o\ndownload?:'
}

T_FINANC_CART_PROBL = {
	'cart�o\ncom problema',
	'cart�o\ncom problema',
	'cartao\ncom problema'
}

T_FINANC_APP_NAO_SUP = {
	'aplica��o\nn�o suportada',
	'aplica��o\nn�o suportada',
	'aplicacao\nnao suportada'
}

T_FINANC_DEST_PRI_VIA = {
	'destaque a via 1\npressione entra',
	'destaque a via 1\npressione entra',
	'destaque a via 1\npressione entra'
}

T_FINANC_SEN_ATU_SUC = {
	'senha atualizada com sucesso',
	'senha atualizada com sucesso',
	'senha atualizada com sucesso'
}

T_FINANC_TROCAR_BOBINA = {
	'favor trocar a\nbobina de papel',
	'favor trocar a\nbobina de papel',
	'favor trocar a\nbobina de papel'
}

T_FINANC_USE_CHIP = {
	'use chip para esta transa��o',
	'use chip para esta transa��o',
	'use chip para esta transacao'
}

T_FINANC_NRO_SIM_CARD = {
	'n�mero do SIM card:\n',
	'n�mero do SIM card:\n',
	'numero do SIM card:\n'
}

T_FINANC_DESL = {
	'desligando...',
	'desligando...',
	'desligando...'
}

T_FINANC_VERIF_LOTE = {
	'verificando lote\naguarde um momento',
	'verificando lote\naguarde um momento',
	'verificando lote\naguarde um momento'
}

T_FINANC_INS_PAS_CART = {
	'insira ou passe \no cart�o',
	'insira ou passe \no cart�o',
	'insira ou passe \no cartao'
}

T_FINANC_SEN_INV_OPER_CANC = {
	'senha inv�lida\nopera��o\ncancelada',
	'senha inv�lida\nopera��o\ncancelada',
	'senha invalida\noperacao\ncancelada'
}

T_FINANC_TRN_EFET_CONC = {
	'transa��o\nefetuada e\nconclu�da',
	'transa��o\nefetuada e\nconclu�da',
	'transacao\nefetuada e\nconcluida'
}

T_FINANC_INS_PAS_APROX_CART = {
	'insira, passe \nou aproxime \no cart�o',
	'insira, passe \nou aproxime \no cart�o',
	'insira, passe \nou aproxime \no cartao'
}

T_FINANC_ERRO_LEIT_TENT = {
	'erro de leitura\ntente novamente',
	'erro de leitura\ntente novamente',
	'erro de leitura\ntente novamente'
}

T_FINANC_ATU_NAO_REALIZ = {
	'atualiza��o \n n�o realizada',
	'atualiza��o \n n�o realizada',
	'atualizacao \n nao realizada'
}

T_FINANC_IMPRIMINDO = {
	'imprimindo',
	'imprimindo',
	'imprimindo'
}

T_FINANC_TERM_NAO_CONF = {
	'terminal n�o\nconfigurado',
	'terminal n�o\nconfigurado',
	'terminal nao\nconfigurado'
}

T_FINANC_DATA_INVAL = {
	'data inv�lida',
	'data inv�lida',
	'data invalida'
}

T_FINANC_DIG_CART = {
	'digite o cart�o',
	'digite o cart�o',
	'digite o cartao'
}

T_FINANC_SINAL = {
	'sinal:',
	'sinal:',
	'sinal:'
}

T_FINANC_SEM_NOVID = {
	'nao ha novidades a serem exibidas',
	'nao ha novidades a serem exibidas',
	'nao ha novidades a serem exibidas'
}

T_FINANC_INS_CART = {
	'passe o cart�o',
	'passe o cart�o',
	'passe o cartao'
}

T_FINANC_PAS_CART = {
	'insira o cart�o',
	'insira o cart�o',
	'insira o cartao'
}

T_FINANC_RET_CART = {
	'retire o cart�o',
	'retire o cart�o',
	'retire o cartao'
}

T_FINANC_TERM_FIN = {
	'terminal finalizado\ncom sucesso',
	'terminal finalizado\ncom sucesso',
	'terminal finalizado\ncom sucesso'
}

T_FINANC_FALHA_CON_SERV = {
	'falha na conex�o com o servidor',
	'falha na conex�o com o servidor',
	'falha na conexao com o servidor'
}

T_FINANC_CONF_GRAV = {
	'configura��o\ngravada',
	'configura��o\ngravada',
	'configuracao\ngravada'
}

T_FINANC_TRN_APROV = {
	'transa��o aprovada',
	'transa��o aprovada',
	'transacao aprovada'
}

T_FINANC_INS_PAS_DIG_CART = {
	'passe, insira ou\n digite o cart�o',
	'passe, insira ou\n digite o cart�o',
	'passe, insira ou\n digite o cartao'
}

T_FINANC_AGUARDE = {
	'aguarde',
	'aguarde',
	'aguarde'
}



--[[
	tMsgTexto.tRecargInput   
--]]

T_RECARG_CONF_CEL = {
	'confirme ddd + n. celular: ',
	'confirme ddd + n. celular: ',
	'confirme ddd+n.celular: '
}

T_RECARG_REC_CEL = {
	'recarga celular',
	'recarga celular',
	'recarga celular'
}

T_RECARG_CEL = {
	'ddd + n. celular: ',
	'ddd + n. celular: ',
	'ddd+n.celular: '
}



--[[
	tMsgTexto.tRecargDialog
--]]

T_RECARG_AGUARDE = {
	'aguarde',
	'aguarde',
	'aguarde'
}

T_RECARG_FORM_PGTO = {
	'forma de pagamento:',
	'forma de pagamento:',
	'forma de pagamento:'
}

T_RECARG_DESC_VIA_CLI = {
	'deseja descartar\nvia do cliente?',
	'deseja descartar\nvia do cliente?',
	'deseja descartar\nvia do cliente?\n1.sim\n2.nao'
}

T_RECARG_OPER_CANC = {
	'opera��o \ncancelada',
	'opera��o \ncancelada',
	'operacao \ncancelada'
}

T_RECARG_PROCESSANDO = {
	'processando',
	'processando',
	'processando'
}

T_RECARG_SELEC_OPER = {
	'selecione a operadora:',
	'selecione a operadora:',
	'operadora:'
}

T_RECARG_CEL_INCOR = {
	'n. do celular \n incorreto',
	'n. do celular \n incorreto',
	'n. do celular \n incorreto'
}

T_RECARG_SELEC_VLR = {
	'selecione o valor da recarga:',
	'selecione o valor da recarga:',
	'valor recarga da recarga:'
}

T_RECARG_IMPR_VIA_CLI = {
	'imprimir via\ndo cliente?',
	'imprimir via\ndo cliente?',
	'imprimir via do\ncliente?\n1.sim\n2.nao'
}

T_RECARG_TRN_APROV = {
	'transa��o\naprovada',
	'transa��o\naprovada',
	'transacao\naprovada'
}

T_RECARG_SERV_INDISP = {
	'servi�o\nn�o dispon�vel',
	'servi�o\nn�o dispon�vel',
	'servico\nnao disponivel'
}

T_RECARG_IMPRIMINDO = {
	'imprimindo',
	'imprimindo',
	'imprimindo'
}



--[[
	tMsgTexto.tRavInput      
--]]

T_RAV_AG_DOMIC = {
	'ag�ncia domic�lio: ',
	'ag�ncia domic�lio: ',
	'agencia domicilio: '
}

T_RAV_DIG_SENHA_RAV = {
	'digite a senha do rav \nno teclado num�rico: ',
	'digite a senha do rav \nno teclado num�rico: ',
	'digite a senha do rav: '
}

T_RAV_VALOR = {
	'valor: ',
	'valor: ',
	'valor: '
}

T_RAV_CPF_PROP = {
	'cpf do propriet�rio:',
	'cpf do propriet�rio:',
	'digite o cpf do\nproprietario:'
}

T_RAV_CONTA_COR_DOMIC = {
	'c. corrente domic�lio: ',
	'c. corrente domic�lio: ',
	'c. corrente domicilio: '
}

T_RAV_CEP = {
	'cep: ',
	'cep: ',
	'cep: '
}



--[[
	tMsgTexto.tRavDialog   
--]]

T_RAV_REFACA_COD_G4_1 = {
	'por favor, refa�a\na transa��o.\nc�digo g4.1',
	'por favor, refa�a\na transa��o.\nc�digo g4.1',
	'por favor, refaca\na transacao.\ncod. g4.1'
}

T_RAV_PROCESSANDO = {
	'processando',
	'processando',
	'processando'
}

T_RAV_REFACA_COD_G4_3 = {
	'por favor, refa�a\na transa��o.\nc�digo g4.3',
	'por favor, refa�a\na transa��o.\nc�digo g4.3',
	'tente de novo-id'
}

T_RAV_RAV_PARC_EFET = {
	'rav parcial efetuado \ncom sucesso',
	'rav parcial efetuado \ncom sucesso',
	'rav parcial efetuado \ncom sucesso'
}

T_RAV_FALHA_CONEX = {
	'falha de conex�o',
	'falha de conex�o',
	'falha de conexao'
}

T_RAV_RAV_TOT_EFET_SUC = {
	'rav total efetuado\n com sucesso',
	'rav total efetuado\n com sucesso',
	'rav total efetuado\n com sucesso'
}

T_RAV_MSG_RAV_AUTO = {
	'com o rav autom�tico voc� \nreceber� vendas a cr�dito(� \nvista e parcelado) sempre no \npr�ximo dia �til ap�s a venda',
	'com o rav autom�tico voc� \nreceber� vendas a cr�dito(� \nvista e parcelado) sempre no \npr�ximo dia �til ap�s a venda',
	'com o rav automatico\nvoce recebera vendas\na credito (a vista e\nparcelado) sempre no\nproximo dia util\napos a venda'
}

T_RAV_MSG_RAV_PARC = {
	'o valor dispon�vel pode ser \nsuperior ao valor solicitado,\npois a composi��o do rav varia de \nacordo com as vendas do \nper�odo',
	'o valor dispon�vel pode ser \nsuperior ao valor solicitado,\npois a composi��o do rav varia de \nacordo com as vendas do \nper�odo',
	'o valor disponivel\npode ser superior ao\nsolicitado, pois a\ncomposicao de\nvalores do rav\nvariam de acordo com\nas vendas do periodo'
}

T_RAV_CONSULTA = {
	'consulta',
	'consulta',
	'consulta'
}

T_RAV_CPF_INVAL = {
	'cpf inv�lido\n tente novamente',
	'cpf inv�lido\n tente novamente',
	'cpf invalido\n tente novamente'
}

T_RAV_IMPR_COMPR = {
	'deseja imprimir\ncomprovante?',
	'deseja imprimir\ncomprovante?',
	'deseja imprimir\ncomprovante?\n1.sim\n2.nao'
}

T_RAV_ERRO_CHAVE = {
	'erro de chave\nligar rede',
	'erro de chave\nligar rede',
	'erro de chave\nligar rede'
}

T_RAV_MSG_TARIF_DESC = {
	'esta transa��o incide tarifa de \nprocessamento a ser \ndescontada em seus \nvencimentos futuros',
	'esta transa��o incide tarifa de \nprocessamento a ser \ndescontada em seus \nvencimentos futuros',
	'esta transacao incide tarifa de \nprocessamento a ser \ndescontada em seus \nvencimentos futuros'
}

T_RAV_SEN_RESG_SUC = {
	'senha resgatada\n com sucesso\n',
	'senha resgatada\n com sucesso\n',
	'senha resgatada\n com sucesso\n'
}

T_RAV_RAV_TOTAL = {
	'rav total',
	'rav total',
	'rav total'
}

T_RAV_RAV_AVULSO = {
	'rav avulso',
	'rav avulso',
	'rav avulso'
}

T_RAV_OPER_CANC = {
	'opera��o\ncancelada',
	'opera��o\ncancelada',
	'operacao\ncancelada'
}

T_RAV_IMPRIMINDO = {
	'imprimindo',
	'imprimindo',
	'imprimindo'
}

T_RAV_AGUARDE = {
	'aguarde',
	'aguarde',
	'aguarde'
}

T_RAV_RAV_PARC = {
	'rav parcial',
	'rav parcial',
	'rav parcial'
}

T_RAV_SERV_INDISP = {
	'servi�o n�o \ndispon�vel',
	'servi�o n�o \ndispon�vel',
	'servico nao \ndisponivel'
}

T_RAV_RAV_AUTO_EFET_SUC = {
	'rav autom�tico \nefetuado com\n sucesso',
	'rav autom�tico \nefetuado com\n sucesso',
	'rav automatico \nefetuado com\n sucesso'
}

T_RAV_RAV_AUTO = {
	'rav autom�tico',
	'rav autom�tico',
	'rav automatico'
}

T_RAV_RESG_SENHA = {
	'resgate de senha',
	'resgate de senha',
	'resgate senha'
}

T_RAV_SALDO_DISP = {
	'saldo dispon�vel',
	'saldo dispon�vel',
	'saldo disp.'
}



--[[
	tMsgTexto.tSerasaInput   
--]]

T_SERASA_VALOR = {
	'valor:',
	'valor:',
	'valor:'
}

T_SERASA_CMC7_BLOCO_2 = {
	'CMC-7 Bloco 2:',
	'CMC-7 Bloco 2:',
	'CMC-7 Bloco 2:'
}

T_SERASA_CMC7_BLOCO_3 = {
	'CMC-7 Bloco 3:',
	'CMC-7 Bloco 3:',
	'CMC-7 Bloco 3:'
}

T_SERASA_CPF_CNPJ = {
	'CPF/CNPJ:',
	'CPF/CNPJ:',
	'CPF/CNPJ:'
}

T_SERASA_DDD = {
	'(DDD):',
	'(DDD):',
	'(DDD):'
}

T_SERASA_DATA_DDMMAA = {
	'data (ddmmaa):',
	'data (ddmmaa):',
	'data (ddmmaa):'
}

T_SERASA_FONE = {
	'FONE:',
	'FONE:',
	'FONE:'
}

T_SERASA_CMC7_BLOCO_1 = {
	'CMC-7 Bloco 1:',
	'CMC-7 Bloco 1:',
	'CMC-7 Bloco 1:'
}

T_SERASA_NRO_BANCO = {
	'n�mero do banco:',
	'n�mero do banco:',
	'numero do banco:'
}

T_SERASA_NRO_CHEQUE = {
	'n�mero cheque:',
	'n�mero cheque:',
	'numero cheque:'
}

T_SERASA_CONTA_COR = {
	'C/C:',
	'C/C:',
	'C/C:'
}

T_SERASA_NRO_AGENCIA = {
	'n�mero da ag�ncia:',
	'n�mero da ag�ncia:',
	'numero da agencia:'
}



--[[
	tMsgTexto.tSerasaDialog
--]]

T_SERASA_ERRO_CHV = {
	'erro de chave\nligar rede',
	'erro de chave\nligar rede',
	'erro de chave\nligar rede'
}

T_SERASA_LIG_COD_A6_010 = {
	'por favor, ligue para\nrede e informe\nc�digo a.6-010',
	'por favor, ligue para\nrede e informe\nc�digo a.6-010',
	'por favor, ligue para\nrede e informe\ncod. a.6-010'
}

T_SERASA_OPER_CANC = {
	'opera��o \ncancelada',
	'opera��o \ncancelada',
	'operacao \ncancelada'
}

T_SERASA_SERV_INDISP = {
	'servi�o n�o \ndispon�vel',
	'servi�o n�o \ndispon�vel',
	'servico nao \ndisponivel'
}

T_SERASA_DATA_INV = {
	'data inv�lida',
	'data inv�lida',
	'data invalida'
}

T_SERASA_DEST_IMPR = {
	'destaque a\nimpress�o',
	'destaque a\nimpress�o',
	'destaque a\nimpressao'
}

T_SERASA_DADO_INV = {
	'dado inv�lido',
	'dado inv�lido',
	'dado invalido'
}

T_SERASA_REFACA_COD_G4_3 = {
	'por favor, refa�a\na transa��o.\nc�digo g4.3',
	'por favor, refa�a\na transa��o.\nc�digo g4.3',
	'tente de novo-id'
}

T_SERASA_FALHA_CONEX = {
	'falha de conex�o',
	'falha de conex�o',
	'falha de conexao'
}

T_SERASA_PROCESSANDO = {
	'processando',
	'processando',
	'processando'
}

T_SERASA_REFACA_COD_G4_1 = {
	'por favor, refa�a\na transa��o.\nc�digo g4.1',
	'por favor, refa�a\na transa��o.\nc�digo g4.1',
	'por favor, refaca\na transacao.\ncod. g4.1'
}



--[[
	tMsgTexto.tLogisticDialog
--]]

T_LOGISTIC_OPER_CANC = {
	'opera��o\ncancelada',
	'opera��o\ncancelada',
	'operacao\ncancelada'
}

T_LOGISTIC_INI_APP = {
	'iniciando\naplica��o',
	'iniciando\naplica��o',
	'iniciando\naplicacao'
}

T_LOGISTIC_ERRO_ITERAC = {
	'erro na itera��o com a RN',
	'erro na itera��o com a RN',
	'erro na iteracao com a RN'
}



--[[
	tMsgTexto.tConfigDialog
--]]

T_CONFIG_ERRO_ITERAC = {
	'erro na itera��o com a RN',
	'erro na itera��o com a RN',
	'erro na iteracao com a RN'
}

