
for a in string.gmatch("1,2,3,4", "([^,]+),?") do
    printer.print (a)
end