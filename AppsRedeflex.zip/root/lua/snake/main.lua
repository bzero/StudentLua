-----------------------------------------------------------------------------------------------
-- Nome do arquivo:                 main.lua                                                 --
-- Descricao:                       Snakes                                                   --
-----------------------------------------------------------------------------------------------
--                                  Historico                                                --
-- Nome               Login        Data          Descricao                                   --
-----------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------
--                                          Require                                          --
-----------------------------------------------------------------------------------------------



-----------------------------------------------------------------------------------------------
--                                      Variaveis globais                                    --
-----------------------------------------------------------------------------------------------

snakeHead = {}
food = {x=20,y=30}
xSpeed = 1
ySpeed = 0
points = 0

largura, altura = 120,130
display.autoflush(false)


-----------------------------------------------------------------------------------------------
--                                          Funcoes                                          --
-----------------------------------------------------------------------------------------------
function completarTexto(str,caract,len,esquerda)
  str = tostring(str)

  if(str:len() > len) then
    return str
  end

  while(str:len() < len) do
    if esquerda then
      str = caract .. str
    else
      str = str .. caract
    end
  end

  --se o tamanho do param caract � maior que um, � poss�vel que o texto tenha ficado maior que len
  --se isso aconteceu, � necess�rio cortar o "excesso"
  if str:len() > len then
    if esquerda then
      str = str:sub((str:len() - len) + 1, str:len())
    else
      str = str:sub(1,len)
    end
  end
  
  return str
end


function initial_state()
 local last = nil
 for i=0,10 do
   local actual = {}
   actual.x = i
   actual.y = 10
   actual.next = last
   last = actual
 end
 snakeHead = last
 return printAll_state
end

function printAll_state()
 --display.clear()
 
 local sTela = ''
 
 --comida
 sTela = '~L' .. completarTexto(food.x*4,'0',3,true) .. '~U' .. completarTexto(food.y*4,'0',3,true) .. '~#000000004004'
  
 local pos = snakeHead
 while pos ~= nil do
  sTela = sTela .. '~L' .. completarTexto(pos.x*4,'0',3,true) .. '~U' .. completarTexto(pos.y*4,'0',3,true) .. '~#000000004004'
  --display.drawline(pos.x*2,pos.y*2,pos.x*2+1,pos.y*2)
  --display.drawline(pos.x*2,pos.y*2+1,pos.x*2+1,pos.y*2+1)
  pos = pos.next
 end
 
 --printer.print(sTela)
 
 ui.graphical(sTela)
 
 return walk_state
end


function walk_state()
 management.sleep(30)
 local key = keyboard.getkeystroke(0)
 --printer.print(tostring(key))
if((key == KEY_EIGHT or key == KEY_DOWN) and ySpeed ~=-1) then
--if(key == KEY_TWO and ySpeed ~=-1) then
  xSpeed = 0
  ySpeed = 1
 elseif((key == KEY_FOUR or key == 37) and xSpeed ~=1) then
  xSpeed = -1
  ySpeed = 0
 elseif((key == KEY_TWO or key == KEY_UP) and ySpeed ~=1) then
-- elseif(key == KEY_EIGHT and ySpeed ~=1) then
  xSpeed = 0
  ySpeed = -1
 elseif((key == KEY_SIX or key == 39) and xSpeed ~=-1) then
  xSpeed = 1
  ySpeed = 0
 elseif(key == KEY_CANCEL) then
  return nil
 end
 increaseHead()
 
 local pos = snakeHead
 while pos.next.next ~= nil do
  pos = pos.next
 end
 pos.next = nil
 return checkColision_state
end

function increaseHead()
 local nextHead = {}
 nextHead.x = snakeHead.x + xSpeed
 nextHead.y = snakeHead.y + ySpeed
 nextHead.next = snakeHead
 local absoluteX, absoluteY = nextHead.x*2+1,nextHead.y*2+1
 if(absoluteX > largura) then
  nextHead.x = 0
 elseif(absoluteX == 1) then
  nextHead.x = math.floor(largura/2)-1
 elseif(absoluteY > altura) then
  nextHead.y = 0
 elseif(absoluteY == 1) then
  nextHead.y = math.floor(altura/2)-1
 end
 snakeHead = nextHead
end

function checkColision_state()
 if(snakeHead.x == food.x and snakeHead.y == food.y) then
  increaseHead()
  keyboard.buzzer(BEEP_CLICK, BEEP_MIDTONE)
  
  points = points +1
  food.x = math.floor(math.random(2,largura-2)/2)
  food.y = math.floor(math.random(2,altura-2)/2)
 end
 return printAll_state
end

-----------------------------------------------------------------------------------------------
--                                          Main                                             --
-----------------------------------------------------------------------------------------------
--math.randomseed(os.time())

ui.graphical_init('igcfg.dat')

--Roda a maquina de estados
state = initial_state

while(state ~= nil) do
  state = state()
end

