
function testeScreen()
	
  printer.print("  ")
  printer.print("#########################")
  printer.print("capacidades da tela")
  printer.print("#########################")
  printer.print("  ")

  if (device.screen_get_capabilities == nil) then
    printer.print("device.screen_get_capabilities nil")
	return
  end
  
  local dados, err = device.screen_get_capabilities()
  
  if (dados == nil) then
	printer.print("device.screen_get_capabilities error " .. tostring(err) )
	return
  end
  
  printer.print("dados # " .. tostring(#dados) )
  
  
  for i,reg in ipairs(dados) do 
	
	 printer.print("registro {" .. tostring(i) .. "}" )
	 
	 for k,field in pairs(reg) do 
		printer.print(k .. " = " .. tostring(field) )
	 end
	
  end
  
  
  local curr, err , msg = device.screen_get_current_settings()
  
  if (curr == nil) then
	printer.print("device.screen_get_current_settings error " .. tostring(err) .. ":" .. tostring(msg) )
	return
  end
  
  printer.print("#########################")
  printer.print("screen_get_current_settings" )
  printer.print("#########################")
  
  for k,field in pairs(curr) do 
	printer.print(k .. " = " .. tostring(field) )
  end
	
  
  curr, err , msg = device.screen_set_current_settings(curr)
  
  if (curr == nil) then
	printer.print("device.screen_set_current_settings error " .. tostring(err) .. ":" .. tostring(msg) )
	return
  end
  
end

function testePrinter()

  printer.print("  ")
  printer.print("#########################")
  printer.print("capacidades da impressora")
  printer.print("#########################")
  printer.print("  ")

  if (device.printer_get_capabilities == nil) then
    printer.print("device.printer_get_capabilities nil")
	return
  end
  
  local dados, err = device.printer_get_capabilities()
  
  if (dados == nil) then
	printer.print("device.printer_get_capabilities error " .. tostring(err) )
	return
  end
  
  printer.print("dados # " .. tostring(#dados) )
  
  
  
  for i,reg in ipairs(dados) do 
	
	 printer.print("registro {" .. tostring(i) .. "}" )
	 
	 for k,field in pairs(reg) do 
	 	printer.print(k .. " = " .. tostring(field) )
	 end
	 
  end
  
   local curr, err , msg = device.printer_get_current_settings()
  
  if (curr == nil) then
	printer.print("device.printer_get_current_settings error " .. tostring(err) .. ":" .. tostring(msg) )
	return
  end
  
  printer.print("#########################")
  printer.print("printer_get_current_settings" )
  printer.print("#########################")
  
  for k,field in pairs(curr) do 
	printer.print(k .. " = " .. tostring(field) )
  end
	
  
  curr, err , msg = device.printer_set_current_settings(curr)
  
  if (curr == nil) then
	printer.print("device.printer_set_current_settings error " .. tostring(err) .. ":" .. tostring(msg) )
	return
  end

end


function testeInput()

  printer.print("  ")
  printer.print("#########################")
  printer.print("capacidades de input")
  printer.print("#########################")
  printer.print("  ")

  if (device.input_get_capabilities == nil) then
    printer.print("device.input_get_capabilities nil")
	return
  end
  
  local dados, err = device.input_get_capabilities()
  
  if (dados == nil) then
	printer.print("device.input_get_capabilities error " .. tostring(err) )
	return
  end
  
  printer.print("dados # " .. tostring(#dados) )
  
  
  
  for i,reg in ipairs(dados) do 
	
	 printer.print(i .. " = " .. tostring(reg) )
	
  end

end

function testeComm()

  printer.print("  ")
  printer.print("#########################")
  printer.print("capacidades de comm ")
  printer.print("#########################")
  printer.print("  ")

  if (device.comm_get_capabilities == nil) then
    printer.print("device.comm_get_capabilities nil")
	return
  end
  
  local dados, err = device.comm_get_capabilities()
  
  if (dados == nil) then
	printer.print("device.comm_get_capabilities error " .. tostring(err) )
	return
  end
  
  printer.print("dados # " .. tostring(#dados) )
  
  
  
  for i,reg in ipairs(dados) do 
	
	 printer.print(i .. " = " .. tostring(reg) )
	
  end

end

function teste()

  if (device == nil) then
    printer.print("device nil")
	return
  end
  
  testeScreen()
  
  testePrinter()
  
  testeInput()
  
  testeComm()
   
  
  printer.print("fim")

end

teste()