while true do
	key = keyboard.usb_getkeystroke(1)
	if key then
		printer.print('tecla:' .. string.char(key))
		printer.print('num:' .. key)
		
	end
	
	if key == KEY_CANCEL then
		break
	end
	
end