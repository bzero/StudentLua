function imprimeArquivo (caminho)

	local xArquivo = io.open(caminho, "r")

	sTexto = nil
	if(xArquivo ~= nil) then						
		sTexto = xArquivo:read("*a")
		xArquivo:close()
		log.logburst(sTexto,6)
		--printer.print(sTexto)
	else
		log.logburst('erro abrindo arquivo :' .. caminho,6)
		--printer.print('erro abrindo arquivo :' .. caminho)
	end
	
	
	
end


local arquivos = {"erro.dbt", "trans.dbt", "ctrllote.dbt", "lote.dbt", "globcfg.dbt",
							"operad.dbt", "seggac.dbt", "isr.dbt", "advice.dbt", "desfaz.dbt",
							"inicia.dbt", "ultfinal.dbt"}

	local retorno
	for i = 1, #arquivos do
		imprimeArquivo('../anewgui/' .. arquivos[i])
		i = i + 1
	end


