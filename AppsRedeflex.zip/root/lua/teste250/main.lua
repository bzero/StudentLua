require "graph250"

ret = graph.init("igcfg.dat")
printer.print('init=' .. ret)
	
params = { sTitulo = "tipo de comunicacao?", tItens = { "primeiro" , "segundo", "terceiro","quarto" , "quinto", "sexto","setimo" , "oitavo", "nono","decimo",'decimo primeiro' }}
ret, valor = graph.Menu(params)
printer.print('ret=' .. ret)
if ret == 0 then
	printer.print('valor=' .. valor)
end


params = {}
params.sTexto = 'Aplica��o Demo da \nnova API gr�fica\n do Redeflex!\n Tecle entra\n para continuar'
params.sTitulo = '' 
graph.Mensagem(params)
--keyboard.getkeystrokenb(5)
ui.graphical_getkeystroke(5)


params = {}
params.sTexto = 'digite a senha'
params.sTitulo = 'titulo' 
retorno = graph.Input(params)
printer.print('ret=' .. retorno[1])
if retorno[1] == 0 then
	printer.print('valor=' .. retorno[2])
end











