-- Arquivos de constantes
require("graph")
--require("graph250")
require('cstrings')


function main (params, identity)	
	graph.init("igcfg.dat")
	--local aux = graph.init("igcfg250.dat")
	
	local tTela = {
		params = {
			tHeader = {
				tLinha = {
					-- 1� Linha do HEADER, sendo a posi��o 1, textos para terminais 320x240, posicao 2 terminais 240x320 e pos 3 monocromaticos.
					{tTexto 		= T_TEXTO_HEADER_01, 	sAlinhamento = T_ALINHAMENTO.CENTER, sFonte = T_FONTES.F06},	
					-- 2� Linha do HEADER, sendo a posi��o 1 textos para terminais 320x240, pos 2 terminais 240x320 e pos 3 monocromaticos.
					{tTexto 		= T_TEXTO_HEADER_02, 	sAlinhamento = T_ALINHAMENTO.LEFT, 		sFonte = T_FONTES.F00},				
				}
			},				
			tBody = {
				tLinha = {					
					{tTexto 		= T_TEXTO_BODY_01, 	sAlinhamento = T_ALINHAMENTO.CENTER,	sFonte = T_FONTES.F00},					
					{tTexto 		= T_TEXTO_BODY_02,	sAlinhamento = T_ALINHAMENTO.RIGHT,		sFonte = T_FONTES.F00},				
				}
			},		
			tRodape = {
				tLinha = {					
					{tTexto 		= T_TEXTO_RODAPE_01,	sAlinhamento = T_ALINHAMENTO.CENTER,	sFonte = T_FONTES.F06},								
				}
			},		
			tBotoesRodape = {'confirma', 'cancela'},
			iTempo = 10,
			fTrataTempo = true,
			--fAnimacao = true,
			fLogo = true
		}		
	}
		
	local tTela2 = {
		params = {
			tBody = {
				tLinha = {					
					{tTexto 		= T_TEXTO_BODY_03, 	sAlinhamento = T_ALINHAMENTO.LEFT,	sFonte = T_FONTES.F00},
				}
			},			
			iTempo = 10,
			tBotoesRodape = {'n�o', 'sim'},
			-- A posi��o da anima��o � fixa, se ficar em cima dos bot�es do rodap� causa erro na cria��o da tela.
			--fAnimacao = true,
			fLogo = true
		}
	}	
		
	local tTela3 = {
		params = {
			tHeader = {
				tLinha = {
					{tTexto 		= T_TEXTO_HEADER_01, 	sAlinhamento = T_ALINHAMENTO.CENTER, sFonte = T_FONTES.F00},
					{tTexto 		= T_TEXTO_PULAR_LINHA_02, 	sAlinhamento = T_ALINHAMENTO.CENTER, sFonte = T_FONTES.F00},
				}
			},		
			tBody = {
				tLinha = {
					{tTexto 		= T_TEXTO_BODY_01, 	sAlinhamento = T_ALINHAMENTO.LEFT,	sFonte = T_FONTES.F00},				
					-- pulando 1 linha, pode ser passado como uma string vazia ou com '\n'
					{tTexto 		= T_TEXTO_PULAR_LINHA_01, 	sAlinhamento = T_ALINHAMENTO.LEFT,	sFonte = T_FONTES.F00},				
					{tTexto 		= T_TEXTO_BODY_01, 	sAlinhamento = T_ALINHAMENTO.LEFT,	sFonte = T_FONTES.F00},
				}
			},
			--fLogo = true,
			fAnimacao = true,
			iTempo = 10,
			tBotoesRodape = {'cancela'}
		}
	}	
	
	local aux1, aux2, aux3 = graph.Dialog(tTela.params)
	local aux1, aux2, aux3 = graph.Dialog(tTela2.params)
	local aux1, aux2, aux3 = graph.Dialog(tTela3.params)
	--local aux1, aux2, aux3 = graph.Dialog(tTela4)
	--printer.print("aux1, aux2, aux3: " .. tostring(aux1) .. " " .. tostring(aux2) .. " " .. tostring(aux3))
	tTela.params = {}
	tTela.acoes = {{acao = 15}}
	
	return tTela
end
