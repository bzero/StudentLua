
function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end

for iSqm = 0, 31 do
	iNovoSinal = round(iSqm*100/31)
	printer.print(string.format("%d -> %02d", iSqm, iNovoSinal))
end
