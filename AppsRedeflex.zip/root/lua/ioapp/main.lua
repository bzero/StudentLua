require("graph")
--require("iolib")

LerMensagem = function(sCaminhoArquivo)
	local xArquivo = io.open(sCaminhoArquivo, "r")

	local sTexto = nil
	if(xArquivo ~= nil) then						
		sTexto = xArquivo:read("*all")
		xArquivo:close()
	end

	return sTexto
end

function main ()
	-- Fun��o respons�vel por iniciar a lib gr�fica. Neste par�metro constam os mapeamentos dos assets para serem utilizados pela lib.
	local iRet = graph.init("igcfg.dat")
	if iRet ~= 0 then
		Debug('erro iniciando lib grafica: ' .. iRet)
		return
	end
	
	local iRet = graph.Mensagem({sTexto = "Criando txt para escrita", iTempo = 1, fTrataTempo = true})	
	
	os.remove("teste.txt")
	local xArquivo = io.open("teste.txt", "rw")
	if (xArquivo) then
		xArquivo:write("This is my first I/O operation!")
		xArquivo:seek("end")
		xArquivo:write("\nAlways close before ending!")
		xArquivo:close()
		
		iRet = graph.Mensagem({sTexto = "Arquivo criado, cheque o teste.txt", iTempo = 1, fTrataTempo = true})
		
		printer.print("Lendo o teste.txt > ")
		printer.print(LerMensagem("teste.txt"))
	else
		iRet = graph.Mensagem({sTexto = "Erro na cria��o do arquivo", iTempo = 1, fTrataTempo = true})
	end	
	
end
