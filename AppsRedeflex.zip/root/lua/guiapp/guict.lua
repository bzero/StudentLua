

guiCT = {
	ControlarNavegacao = function (tTela)
		-- usando multiservice (ms)
		tTela, sStackTrace = xRN:call({tTela = tTela})

		--Teste do StackTrace Multi servi�o
		if (sStackTrace) then
			printer.print("Erro RN: " .. sStackTrace)
			return
		end
		
		------------------------------------------------------------------------------------------------------------
		-- INPUT
		------------------------------------------------------------------------------------------------------------
		if (tTela.telaID == I_TELA_ID_INPUT) then			
			if tTela.params.sTexto == nil or tTela.params.sTexto == '' then
				if tTela.params.sTitulo ~= nil then
					tTela.params.sTexto = tTela.params.sTitulo
				else
					tTela.params.sTexto = ""
				end
			end
			
			if (tTela.params.fCampoSenha) then -- iTamanhoMax   iTamanhoMin
				if tTela.params.iTamanhoMin == nil then
					tTela.params.iTamanhoMin = 4
				end
				tTela.params = graph.InputSenhaAberta(tTela.params)-- 4 --tTela.params.iQtdeDigSenha
			else
				tTela.params = graph.Input(tTela.params)
			end
		------------------------------------------------------------------------------------------------------------
		-- MENU
		------------------------------------------------------------------------------------------------------------
		elseif (tTela.telaID == I_TELA_ID_MENU) then 				
				iRet, iValor = graph.Menu(tTela.params)
				if iRet == RET_OK then
					tTela.params = {iValor-1}
				elseif iRet == RET_CANCELADO then
					tTela.params = {HF_BUTTON_KEYBOARD_REJECT_BUTTON}
				elseif iRet == RET_MENU_VOLTAR then
					tTela.params = {HF_BUTTON_FIRST_BUTTON}
				elseif iRet == RET_MENU_INICIAL then
					tTela.params = {HF_BUTTON_SECOND_BUTTON}
				--timeout
				elseif iRet == -1 then
					tTela.params = {HF_BUTTON_KEYBOARD_REJECT_BUTTON}

				else
					tTela.params = {iRet}
				end

		------------------------------------------------------------------------------------------------------------
		-- DIALOG
		------------------------------------------------------------------------------------------------------------
		elseif (tTela.telaID == I_TELA_ID_DIALOG) then 
			if tTela.iTempo ~= nil then
				tTela.params.iTempo = tTela.iTempo
				tTela.iTempo = nil
			end
			
			local iTecla, track1, track2, track3 = graph.Mensagem(tTela.params)
			tTela.params.sResp = nil
			tTela.params[1] = iTecla	
			tTela.params.sTrilha1 = track1 
			tTela.params.sTrilha2 = track2
 		end
		
		------------------------------------------------------------------------------------------------------------
		-- A��ES
		------------------------------------------------------------------------------------------------------------
 		if tTela.acoes ~= nil then
			for i, tAcao in ipairs(tTela.acoes) do
 				-----------------------------------------------------
 				-- ACOES DE CONECTIVIDADE
 				-----------------------------------------------------

 				if tAcao.acao == I_ACAO_ENVIAR_MSG then

 					local data, erro, codErro
 					-- Para cada configura��o de comunicacao, tenta enviar a msg
 					for iIndex ,tParams in pairs(tAcao.tComunicacao) do
 						if(conexLib.fVerificaTipoConexao(tParams)) then

 							-- se for ETHERNET, desliga todos os tipos de conex�o via modem
 							if conexLib.fETHERNET() then 
								conexLib.fDesligarTudo()
 							end

 							local iTentativasConex = 1
 							repeat 							 								
 								-- cria o buffer da msg de acordo com os parametros de comunicacao
 								local buffer = isoLib.criaBuffer(tAcao.msg, tParams)

 								-- Tenta enviar a mensagem
 								data, erro, codErro = conexLib.fEnviarMensagem(tParams, buffer)

 								-- incrementa as tentativas
 								iTentativasConex = iTentativasConex + 1

 							-- repete o envio enquanto estiver com dificuldade de conex�o e n�mero de tentativas permitir
 							until codErro ~= I_ERRO_SOCKET_CONNECT or iTentativasConex > tParams.iNumTentativas

 							-- se algum dado foi recebido ou o erro n�o foi de conex�o, pare a itera��o 
 							if(data or codErro ~= I_ERRO_SOCKET_CONNECT) then
								break
							end
 						end
 					end

 					tTela.params = {data, erro, codErro}

 				elseif tAcao.acao == I_ACAO_LIGAR_MODEM then
 					
					-- tenta ligar o modem com o parametro solicitado
					if(conexLib.fVerificaTipoConexao(tAcao.tParamsComunicacao)) then
						conexLib.fLigarModem(tAcao.tParamsComunicacao)
					end
 					
 				-----------------------------------------------------
 				-- ACOES DE IMPRESSAO E FLUXO EXTERNO
 				-----------------------------------------------------	

 				elseif tAcao.acao == I_ACAO_IMPRIMIR then
 					if (tAcao.fImprimeLogo) then
 						tImpressao.fImprimirImagemRede()
 					end 					
 					tImpressao.fImprimir(tAcao.tLinhas)

 				elseif tAcao.acao == I_ACAO_REINICIA_FLUXO then
 					LogDebug("GUI ReiniciaFluxo", 1, I_LOGDEBUG_TIPO_UI)
 					return false, nil
 				elseif tAcao.acao == I_ACAO_FINALIZA_FLUXO then
 					local retorno = xRN:call({FinalizaFluxo = 1})
 					return false, nil
 				
 				elseif tAcao.acao == I_ACAO_SAIR then
 					return false, nil
 				-----------------------------------------------------
 				-- ACOES BC
 				-----------------------------------------------------
 				elseif tAcao.acao == I_ACAO_CAPTURAR_CARTAO then
 					tTela.params.sErro, tTela.params.iCodErro, tTela.params.sResp = tBc.fCapturarCartao(tAcao.sModoCaptura)

 				elseif tAcao.acao == I_ACAO_REMOVER_CARTAO then
 					tTela.params.sErro = tBc.fRemoverCartao(tAcao.fAbortar)

 				elseif tAcao.acao == I_ACAO_FINALIZAR_CARTAO_CHIP then
 					tTela.params.sErro, tTela.params.sResp = tBc.fFinalizarCartaoChip(tAcao.tDadosTransacao)

 				elseif tAcao.acao == I_ACAO_PROCESSAR_CARTAO_CHIP then
 					tTela.params.sErro, tTela.params.iCodErro, tTela.params.sResp = tBc.fProcessarCartaoChip(tAcao.tInput, tAcao.tTags, tAcao.tTagsOpt, guiCT.fCallbackFab(tAcao.sTextoPinpad))

 				elseif tAcao.acao == I_ACAO_COLETAR_SENHA_CARTAO then
 					tTela.params.sErro, tTela.params.sResp = tBc.fColetarSenhaCartao(tAcao.tDadosTransacao, guiCT.fCallbackFab(tAcao.sTextoPinpad))

 				elseif tAcao.acao == I_ACAO_CARREGAR_TABELAS_BC then
 					tTela.params.sErro = tBc.fCarregarTabelas(tAcao.sInic, tAcao.tAID, tAcao.tCAPK)
 					
 				elseif tAcao.acao == I_ACAO_CRIPTOGRAFAR then
 					tTela.params.tDadosCrypto = {}
 					for i=1,#tAcao.tBuffers do
 						tTela.params.tDadosCrypto[i] = tBc.fCriptografar(tAcao.tBuffers[i])
 					end

 					if tAcao.sDUKPT ~= "" then
 						tTela.params.sKSN = tBc.fObterKSN(tAcao.sDUKPT)
 					end
 				end
  			end
 		end
 		return true, tTela
	end
	
}