require("graph")

-- Carregando constantes
require("cui")
require("cacoes")
require("cgrafico")

-- Fun��o respons�vel por iniciar a lib gr�fica. Neste par�metro constam os mapeamentos dos assets para serem utilizados pela lib.
local iRet = graph.init("igcfg.dat")
if iRet ~= 0 then
	Debug('erro iniciando lib grafica: ' .. iRet)
	return
end

--Usando multiservice (ms.open)
xRN, sStackTrace = ms.open("rnapp")

function main ()
	require("guict")
	local iRet = graph.Mensagem({sTexto = "Inicializando", iTempo = 1, fTrataTempo = true})

	--Teste do StackTrace Multi servi�o
	if (sStackTrace) then
		printer.print("error: " .. sStackTrace)
		return
	end
	
	local navegacao = true
	local tTela = { telaID = "", params = {}}
	while navegacao do
		navegacao, tTela = guiCT.ControlarNavegacao(tTela)
	end

	xRN:close()
		
end