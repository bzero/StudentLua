I_TELA_ID_MENU = 1
I_TELA_ID_DIALOG = 2
I_TELA_ID_INPUT = 3

--Op��es extras para componentes gr�ficos
I_OPTEXT_DET_ESTORNO = 1 -- Detalhamento do estorno