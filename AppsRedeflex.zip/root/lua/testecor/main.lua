require "graph"

ret = graph.init("igcfg.dat")
printer.print('init=' .. ret)

ui.graphical('~D000~I041~U140~L055~F02VALOR:      5,55\ndigite a senha no\nteclado num�rico:~D065~C~I043{~D009~F08~$3}')
ui.graphical_getkeystroke(100)

ui.graphical('~U034~L015~I007{~L004~F01~$0~W1.opcaoA~K031}~U090~L015~I007{~L004~F01~$0~W2.opcaoB~K032}~U146~L015~I007{~L004~F01~$0~W3.opcaoC~K033}~U202~L015~I007{~L004~F01~$0~W0.opcaoD~K034}~D009~L015~I004{~F04~$4cancela~K00c}')
ui.graphical_getkeystroke(100)

params = {}
params.sTexto = 'Ol�! A fun��o o parcelado emissor agora � credi�rio. Deseja continuar?'
params.sTitulo = '' 
params.tBotoesRodape = {'sim'}

graph.Mensagem(params)
--keyboard.getkeystrokenb(5)
ui.graphical_getkeystroke(5)

--iRet, iEscolha = graph.MensagemSimNao('Gostaria de uma\ndemonstra��o?',10)
--printer.print(iRet .. ' ' .. tostring(iEscolha))
--if iRet == 0 and iEscolha then	

	--captura senha aberta
	ret, valor = graph.InputSenhaAberta('senha','digite',4)

	--captura alpha
	ret, valor = graph.RecebeString("","digite alpha", 1, "@.@@@.@@@.@@*,**", 0, 1, 1, nil, nil, nil, nil, nil, nil, nil, nil, false)
	printer.print('ret=' .. ret)
	if ret == 0 then
		printer.print('valor=' .. valor)
	end
	
	
	params = { sTitulo = "tipo de comunicacao?", tItens = { "GPRS" , "ETHERNET", "WIFI" }}
	ret, valor = graph.Menu(params)
	printer.print('ret=' .. ret)
	if ret == 0 then
		printer.print('valor=' .. valor)
	end


	--captura numerico
	ret, valor = graph.RecebeString("","digite valor", 1, "@.@@@.@@@.@@*,**", 0, 0, 1, nil, nil, nil, nil, nil, nil, nil, nil, false)
	printer.print('ret=' .. ret)
	if ret == 0 then
		printer.print('valor=' .. valor)
	end
	
--end








