	function soma (n1, n2)
	r = n1+n2
	op = "soma"
	ui.transient("Resultado",r,12054,m)
	hist(r, op)
	end

	function mult(n1, n2)
	r = n1*n2
	op = "multiplicacao"
	ui.transient("Resultado",r,12054,m)
	hist(r, op)
	end

	function hist(r, op)
		texto = io.open("hist.txt", "rw")
		texto:seek("end")
		texto:write(r, " ", op .. "\n")
		io.close()
	end

	menu = ui.menu("escolha", {"soma", "multiplicacao", "historico"})
	menu:show()

	opcao = menu:accepted()
	display.clear()

	if opcao == 3 then
	 file = io.open("hist.txt", "r")
	 printer.print(file:read("*a"))
	 io.close()
	else
	
	texto = ui.textfield("","digite um numero")
	texto:show()
	n1 = texto:text()
	display.clear()

	texto = ui.textfield("","digite outro numero")
	texto:show()
	n2 = texto:text()
	
	funcao = {soma, mult}
	funcao[opcao](n1,n2)
	
	end 
	
	




