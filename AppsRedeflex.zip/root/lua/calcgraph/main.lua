require("graph")

local function Somar(n1, n2)
	return n1+n2
end

local function Subtrair(n1, n2)
	return n1-n2
end

local function Dividir(n1, n2)
	return n1/n2
end

local function Multiplicar(n1, n2)
	return n1*n2
end

local tFuncoes = {Somar, Subtrair, Dividir, Multiplicar}

function main ()
	-- Fun��o respons�vel por iniciar a lib gr�fica. Neste par�metro constam os mapeamentos dos assets para serem utilizados pela lib.
	local iRet = graph.init("igcfg.dat")
	if iRet ~= 0 then
		Debug('erro iniciando lib grafica: ' .. iRet)
		return
	end
	
	while (true) do
	local iRet, iValor = graph.Menu({ sTitulo = "Menu", tItens = {"Somar", "Subtrair", "Dividir", "Multiplicar"}})	
	if (iRet ~= 0 or iRet == 2) then
		return 
	end
	
	iRet = graph.Input({sTexto = "Digite o primeiro valor:", iTamanhoMin = 1})
	if (iRet[1] ~= 0 or iRet[1] == 2) then
		return
	end
	
	local num1 = iRet[2]
	
	iRet = graph.Input({sTexto = "Digite o segundo valor:", iTamanhoMin = 1})
	if (iRet[1] ~= 0 or iRet[1] == 2) then
		return
	end
	
	local num2 = iRet[2]
	
	iRet = graph.Mensagem({sTexto = "O resultado �: " .. tostring(tFuncoes[iValor](num1,num2)), iTempo = 3, fTrataTempo = true})
	end

end