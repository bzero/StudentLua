-- Estados do controlador inicial.
I_ESTADO_INICIAL				= 1
I_ESTADO_INICIAL_FINALIZA_APP	= 2
