-- Constantes com os m�dulos
I_MOD_INICIAL = 1
