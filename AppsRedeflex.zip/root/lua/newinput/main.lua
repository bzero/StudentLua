require('graph')
graph.init('igcfg.dat')

main = function ()	
	local sTela = ""
	local sDadoLido, sDadoLido2, iTamMax = '', '', 8
	local iErro = 0	
	repeat
		-- criando um textfield com a imagem I043, e dentro das dimens�es da imagem, inserindo os textos como se estivessem em textfields {}
		-- O mesmo acontece para os bot�es, por�m, bot�es aceitam eventos de touch
		-- '~!' este comando signica que ele deve manter a tela antiga e montar a nova mesclando as duas
		-- '$1' diz a cor do texto e 'F08' fonte a ser utilizada
		sTela = 			
			"~D063~I041~U027~F03" .. 'titulo' .. 								-- Background + titulo			
			"~C~U060~I043{~D009~F08~$3" .. sDadoLido .. "}" .. 					-- Primeira caixa de texto
			"~!~D160~I043{~D009~F08~$3" .. sDadoLido2 .. "}" ..					-- Primeira caixa de texto
			"~D009" .. "~L015" .. "~I004{~F04~$0" .. 'cancela' .. "~K012}" .. 	-- Bot�o esquerdo rodap�
			"~D009" .. "~R015" .. "~I013{~F04~$1" .. 'confirma' .. "~K011}" ..	-- Bot�o direto rodap�
			"~D070" .. "~C" .. "~I008{~F04~$1" .. 'limpar campos' .. "~K013}"	-- Bot�o do centro
			
		iErro = ui.graphical(sTela)
		
		-- Erro na cria��o da TELA
		if (iErro ~= 0) then
			return {0, iErro}
		end
		
		-- Fun��o respons�vel por aguardar evento de tecla ou touch xEvt == 4 evento TOUCH xEvt == 8 evento KEYBOARD
		xEvt,xKey = ui.graphical_wait_events(10, 0x000C)
		
		-- TRATANDO OS RETORNOS DO EVENTO
		
		--timeout
		if (xKey == nil) then
			return {0, nil}
		end
		
		-- bot�o cancelar n�o retorna dado lido
		if (xKey == 12 or xKey == 18) then
			return {0, nil}
		
		-- bot�o enter retornando o dado lido
		-- Verifica��es podem ser feitas neste momento, por exemplo se o tamanho do dado atingiu o tamanho minimo.
		elseif (xKey == 11 or xKey == 17) then		
			return {0, sDadoLido .. sDadoLido2}
		
		-- Evento retornou um valor de 0 a 9		
		elseif ((xKey >= 0) and (xKey <= 10)) then
			-- Corrigindo o valor de KEY que vem da plataforma com n�mero a mais
			xKey = xKey - 1
			
			-- Checando se n�o passou do tamanho m�ximo do campo
			if (#sDadoLido < iTamMax) then
				sDadoLido = sDadoLido .. tostring(xKey) -- Atualiza o dado lido
			
			-- Passou pelo tamanho m�ximo do campo 1, indo para o segundo campo
			elseif (#sDadoLido2 < iTamMax) then
				sDadoLido2 = sDadoLido2 .. tostring(xKey) -- Atualiza o dado lido
			else
				-- se passou, n�o deixa inserir mais e emite beep
				keyboard.buzzer (BEEP_SHORT,BEEP_MIDTONE)
			end
		
		-- Tecla para apagar dado
		elseif (xKey == 14) then
			-- Removendo �ltimo digito
			if (#sDadoLido > 0 and #sDadoLido2 == 0) then				
				sDadoLido = string.sub(sDadoLido, 1, #sDadoLido -1)				
			
			elseif (#sDadoLido2 > 0) then
				sDadoLido2 = string.sub(sDadoLido2, 1, #sDadoLido2 -1)	
			else   
				-- n�o possui dado para apagar
				keyboard.buzzer (BEEP_SHORT,BEEP_MIDTONE)
			end
		
		-- Bot�o limpar campos
		elseif (xKey == 19) then
			sDadoLido = ''
			sDadoLido2 = ''
		else
			 -- Tecla n�o permitida
			keyboard.buzzer (BEEP_SHORT,BEEP_MIDTONE)
		end
				
	until nil
	
	
	printer.print('fim: ' .. tostring(ret))
	
end