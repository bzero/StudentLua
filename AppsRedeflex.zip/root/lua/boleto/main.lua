require "boleto"
-- abcdefghijklmnopqrstuvwxyz
-- linhaDigitavel="40995.21231 58400.010110 29509.825096 1 000000000000000"
ui.message("MSG", "Imprimindo boleto")
bol = boleto:new{linhaDigitavel="40995.10564 30100.00071 71558.950425 4 41180032703965",
                 vencimento = "31/02/2009",
                 cedente="HIPERCARD BANCO MULTIPLO S/A",
                 agencia = "3128",
                 dataDocumento = "31/02/2009",
                 numeroDocumento = "010112950982509",
                 especieDocumento = "DUPL.MERCANTIL",
                 aceite = "N",
                 dataProcessamento = "31/02/09",
                 nossoNumero = "010112950982509",
                 cnpjCedente = "33.166.158/0001-95",
                 carteira = "20",
                 especieMoeda = "REAL",
                 quantidadeMoeda = "1000,00",
                 valorMoeda = "1,00",
                 valorDocumento = "327.039,65",
                 instrucoes1="Instrucoes contidas na linha 1",
                 instrucoes2="Instrucoes contidas na linha 2",
                 instrucoes3="Instrucoes contidas na linha 3",
                 desconto = "2.000,00",
                 multa = "23.327.039,65",
                 valorCobrado = "325.039,65",
                 sacado1 = "Hipercard",
                 sacado2 = "R. Ernesto de Paula Santos, 187 loja 1",
                 sacado3 = "51021-330 - Boa Viagem - Recife - PE",
								 codigoBarras = "4099510564301000007171558950425441180032703965"}
bol:print()