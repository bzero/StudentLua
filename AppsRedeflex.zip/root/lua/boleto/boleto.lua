-----------------------------------------------------------------------------------------------
-- Nome do arquivo:                 boleto.lua                                               --
-- Descricao:                       API geracao de boletos bancarios                         --
-----------------------------------------------------------------------------------------------
--                                  Historico                                                --
-- Nome               Login        Data          Descricao                                   --
-----------------------------------------------------------------------------------------------
-- Renato Ferreira    rvf          19/01/2009    Versao inicial                              --
-- Kresller Silva     kss          10/02/2009    M�todo para alinhar os valores a esquerda   --
-----------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------
--                                        Pacote                                             --
-----------------------------------------------------------------------------------------------

-- configuracoes e limites do boleto e da fonte
boletocl = { sX = "",
             sY = "",
             eX = "",
             eY = "",
             startFontX = "",
             startFontY = "",
             fontWidth = "",
             fontHeight = "",
             flagreload = true}

-- Tabela do boleto contendo todos os dados necess�rios
boleto = {fontName="",
          prty="",
          chars="",
          linhaDigitavel="",
          vencimento = "",
          cedente="",
          agencia = "",
          dataDocumento = "",
          numeroDocumento = "",
          especieDocumento = "",
          aceite = "",
          dataProcessamento = "",
          nossoNumero = "",
          cnpjCedente = "",
          carteira = "",
          especieMoeda = "",
          quantidadeMoeda = "",
          valorMoeda = "",
          valorDocumento = "",
          instrucoes1 = "",
          instrucoes2 = "",
          instrucoes3 = "",
          desconto = "",
          multa = "",
          valorCobrado = "",
          sacado1 = "",
          sacado2 = "",
          sacado3 = "",
					codigoBarras = ""}

-----------------------------------------------------------------------------------------------
--                                    Vari�veis globais                                      --
-----------------------------------------------------------------------------------------------



-----------------------------------------------------------------------------------------------
--                                        Require                                            --
-----------------------------------------------------------------------------------------------


-----------------------------------------------------------------------------------------------
--                                          Funcoes                                          --
-----------------------------------------------------------------------------------------------
-- Inicializa��o de um novo boleto
function boleto:new (o)
    o = o or {}   -- create object if user does not provide one
    setmetatable(o, self)
    self.__index = self
    return o
end

-- Carrega configuracoes basicas da fonte
function boleto:loadconfig()
    if(self.chars == "") then
        self.chars = self.prty:getstring("chars")
    end
    -- so precisa carregar essas variaveis quando mudar de fonte
    boletocl.startFontX = self.prty:getnumber(self.fontName .. "startx")
    boletocl.startFontY = self.prty:getnumber(self.fontName .. "starty")
    boletocl.fontWidth = self.prty:getnumber(self.fontName .. "width")
    boletocl.fontHeight = self.prty:getnumber(self.fontName .. "height")
end

-- Encontrar a posicao do char no arquivo de fonte
function boleto:findChar(txtChar)
    local charsLen = string.len(self.chars)
    for i=0,charsLen-1,1 do
        if txtChar == (string.sub(self.chars, i+1, i+1)) then
            boletocl.sX = boletocl.startFontX
            boletocl.sY = boletocl.startFontY + (i * boletocl.fontHeight)
            boletocl.eX = boletocl.sX + boletocl.fontWidth
            boletocl.eY = boletocl.sY + boletocl.fontHeight
        end
    end
end

-- Funcao para escrever texto na vertical respeitando os limites de startX, startY, n�o passando de endX e endY
function boleto:writeVerticalText(template, font, txt, startX, startY, endX, endY)
    local txtLen = string.len(txt)
    local offsetX = 0
    local offsetY = 0
    if boletocl.flagreload then
       self:loadconfig()
       boletocl.flagreload = false
    end
    local charwidth = boletocl.fontWidth
    local charheight= boletocl.fontHeight
    for i=0,txtLen-1,1 do
        self:findChar(string.sub(txt, i+1, i+1))
        -- printer.print(boletocl.sX .. " " .. boletocl.sY .. " " .. boletocl.eX .. " " ..  boletocl.eY)
        if (startY + offsetY + charheight) > endY  then
            if (startX + offsetX - charwidth) > endX then
               break
            else
                offsetY = 0
                offsetX = offsetX - charwidth
            end
        end
        template:drawimage(font, startX + offsetX, startY + offsetY, boletocl.sX, boletocl.sY, boletocl.eX, boletocl.eY)
        offsetY = offsetY + charheight
    end
end

-- Funcao que imprime na vertical, porem carregando os limites da string conf
function boleto:writeVerticalTextString(template, font, txt, conf)
    local pIndex = string.find(conf, ",")
    local stX = tonumber(string.sub(conf, 0, pIndex-1))
    local cIndex = string.find(conf, ",", pIndex+1)
    local stY = tonumber(string.sub(conf, pIndex+1, cIndex-1))
    pIndex = cIndex
    cIndex = string.find(conf, ",", pIndex+1)
    local enX = tonumber(string.sub(conf, pIndex+1, cIndex-1))
    pIndex = cIndex
    cIndex = string.find(conf, ",", pIndex+1)
    local enY = tonumber(string.sub(conf, pIndex+1))
    self:writeVerticalText(template, font, txt, stX, stY, enX, enY)
end

-- Funcao que retorna a posi��o, alinhando o valor a direita.
function boleto:getPosition(value, confValue)
	local conf = self.prty:getstring(confValue)
    local pIndex = string.find(conf, ",")
    local cIndex = string.find(conf, ",", pIndex+1)
    local stY = tonumber(string.sub(conf, pIndex+1, cIndex-1))
    local v = string.sub(conf,0,pIndex)
    local sub = string.len(value) * 16
    v = v .. (stY-sub) .. string.sub(conf,cIndex)
    return v
end

-- Funcao que elimina caracteres especiais de um string retornando apenas os caracteres numericos
function boleto:getNumbers(txt)
    local txtNumbers = ""
    local txtLen = string.len(txt)
    local min = string.byte("0")
    local max = string.byte("9")
    for i=1,txtLen,1 do
        if string.byte(txt, i) >= min and string.byte(txt, i) <= max then
            txtNumbers = txtNumbers .. string.sub(txt, i, i)
        end
    end
    return txtNumbers
end

-- Funcao para imprimir o c�digo de barras, basicamente copiada da internet e portada para lua
-- http://www.codigofonte.com.br/codigo/php/diversos/gerar-codigo-de-barras-para-boletos-bancarios-em-php
function boleto:printBarCode(template)
    local barcodes = {}
    barcodes[0] = "00110"
    barcodes[1] = "10001"
    barcodes[2] = "01001"
    barcodes[3] = "11000"
    barcodes[4] = "00101"
    barcodes[5] = "10100"
    barcodes[6] = "01100"
    barcodes[7] = "00011"
    barcodes[8] = "10010"
    barcodes[9] = "01010"
		
		--barras  pretas
    local p1 = image.load("p1.bmp")
    local p3 = image.load("p3.bmp")
		
		--barras brancas
		local b1 = image.load("b1.bmp")
    local b3 = image.load("b3.bmp")
		
    local sX = self.prty:getnumber("barcodex")
    local sY = self.prty:getnumber("barcodey")
    local offsetY = 0
    -- Guarda inicial
    template:drawimage(p1, sX, sY + offsetY)
    offsetY = offsetY + 2 
		template:drawimage(b1, sX, sY + offsetY)
    offsetY = offsetY + 2 
		template:drawimage(p1, sX, sY + offsetY)
    offsetY = offsetY + 2 
    template:drawimage(b1, sX, sY + offsetY)
    offsetY = offsetY + 2
    
    local valor = self:getNumbers(self.codigoBarras)
    -- texto
    while string.len(valor) > 0 do
        
				primeiroNumero = barcodes[tonumber(string.sub(valor,1,1))]
				segundoNumero  = barcodes[tonumber(string.sub(valor,2,2))]
        
				valor = string.sub(valor,3)
        
				for i=1,5,1 do
            --imprimido uma barra fina
						if (string.sub(primeiroNumero,i,i) == "0") then
                template:drawimage(p1, sX, sY + offsetY)
                offsetY = offsetY + 2
						--imprimindo uma barra grossa
            else
                template:drawimage(p3, sX, sY + offsetY)
                offsetY = offsetY + 4
            end
						
						--imprimido uma barra fina
						if (string.sub(segundoNumero,i,i) == "0") then
                template:drawimage(b1, sX, sY + offsetY)
								offsetY = offsetY + 2
						--imprimindo uma barra grossa
            else
								template:drawimage(b3, sX, sY + offsetY)
                offsetY = offsetY + 4
            end
        end
    end
    -- Guarda final
    template:drawimage(p3, sX, sY + offsetY)
    offsetY = offsetY + 4 
		template:drawimage(b1, sX, sY + offsetY)
		offsetY = offsetY + 2
    template:drawimage(p1, sX, sY + offsetY)
end

-- Funcao para imprimir o boleto
function boleto:print()
    local font = image.load("fontg.bmp")
    local img = image.load("boleto.bmp")
    self.fontName = "fontg"
    self.prty = property.open("bolconf.txt")
    -- Usando a fonte grande
    self:writeVerticalTextString(img, font, self.linhaDigitavel, self.prty:getstring("linhaDigitavel"))
    self:writeVerticalTextString(img, font, self.vencimento, self.prty:getstring("vencimento"))
    self:writeVerticalTextString(img, font, self.valorDocumento, self:getPosition(self.valorDocumento,"valorDocumento") )
    self:writeVerticalTextString(img, font, self.desconto, self:getPosition(self.desconto,"desconto"))
    self:writeVerticalTextString(img, font, self.multa, self:getPosition(self.multa,"multa"))
    self:writeVerticalTextString(img, font, self.valorCobrado, self:getPosition(self.valorCobrado,"valorCobrado"))
    -- mundando a fonte
    image.unload(font)
    font = image.load("fontm.bmp")
    self.fontName = "fontm"
    -- setando o flag para recarregar os paramentros da nova fonte
    boletocl.flagreload = true
    self:writeVerticalTextString(img, font, self.cedente, self.prty:getstring("cedente"))
    self:writeVerticalTextString(img, font, self.agencia, self.prty:getstring("agencia"))
    self:writeVerticalTextString(img, font, self.dataDocumento, self.prty:getstring("dataDocumento"))
    self:writeVerticalTextString(img, font, self.aceite, self.prty:getstring("aceite"))
    self:writeVerticalTextString(img, font, self.dataProcessamento, self.prty:getstring("dataProcessamento"))
    self:writeVerticalTextString(img, font, self.nossoNumero, self.prty:getstring("nossoNumero"))
    self:writeVerticalTextString(img, font, self.carteira, self.prty:getstring("carteira"))
    self:writeVerticalTextString(img, font, self.especieMoeda, self.prty:getstring("especieMoeda"))
    self:writeVerticalTextString(img, font, self.quantidadeMoeda, self.prty:getstring("quantidadeMoeda"))
    self:writeVerticalTextString(img, font, self.valorMoeda, self.prty:getstring("valorMoeda"))
    -- mundando a fonte
    image.unload(font)
    font = image.load("fontp.bmp")
    self.fontName = "fontp"
    boletocl.flagreload = true
    self:writeVerticalTextString(img, font, self.instrucoes1, self.prty:getstring("instrucoes1"))
    self:writeVerticalTextString(img, font, self.instrucoes2, self.prty:getstring("instrucoes2"))
    self:writeVerticalTextString(img, font, self.instrucoes3, self.prty:getstring("instrucoes3"))
    self:writeVerticalTextString(img, font, self.sacado1, self.prty:getstring("sacado1"))
    self:writeVerticalTextString(img, font, self.sacado2, self.prty:getstring("sacado2"))
    self:writeVerticalTextString(img, font, self.sacado3, self.prty:getstring("sacado3"))
    self:writeVerticalTextString(img, font, self.numeroDocumento, self.prty:getstring("numeroDocumento"))
    self:writeVerticalTextString(img, font, self.cnpjCedente, self.prty:getstring("cnpjCedente"))
    self:writeVerticalTextString(img, font, self.especieDocumento, self.prty:getstring("especieDocumento"))
    image.unload(font)

    self:printBarCode(img)
    printer.printimage(img, "center")
    -- property.close(prty)
end