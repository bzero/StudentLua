local S_MENU_OPCAO_MENU_PRINCIPAL = "menu inicial"
local S_MENU_OPCAO_FUNCAO = "fun��o"
local S_MENU_OPCAO_LIMPA = "limpa"
local S_MENU_OPCOES_PAG = "pagamentos"
local S_MENU_OPCOES_ADMIN = "administra"
local S_MENU_OPCOES_ATUALIZAR = "atualizar"
local S_MENU_OPCOES_CANCELA = "cancela"

tIniciaCT = {
	tPassos = {
		---------------------------------------------------------------------------------------------
		--Mostra tela inicial (espera cart�o e mostra os bot�es de Menu e Fun��o)
		[I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA 		] = function(tTela) 
				tME.fProximoEstado(I_MOD_INICIAL, I_ESTADO_INICIAL_OPCAO_ESCOLHIDA)
				--tEstado.modulo = I_MOD_INICIAL
				--tEstado.passo = I_ESTADO_INICIAL_OPCAO_ESCOLHIDA

				tTela.telaID = I_TELA_ID_DIALOG
				tTela.params = { sTitulo = "", 
								 sTexto = "insira ou passe \n o cart�o", 
								 fImagemAnimada = true,
								 tBotoesRodape = {S_MENU_OPCAO_MENU_PRINCIPAL, S_MENU_OPCAO_FUNCAO}, 
								 fLerCartao = true, 
								 iTempo = 5, 
								 fTrataTempo = true, 
								 fAceitaAtalho = true}
			
			return true, tTela 
		end, 

		---------------------------------------------------------------------------------------------
		--Trata os poss�veis retornos da tela inicial
		[I_ESTADO_INICIAL_OPCAO_ESCOLHIDA 			] = function(tTela) 

			local fPassaPelaTela = false

			tEstado.modulo = I_MOD_INICIAL
			tEstado.passo = I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA

			if(tTela.params ~= nil) then
				if(tTela.params[1] == HF_TIMEOUT_EVENT or tTela.params[1] == HF_TIMEOUT_MENU_EVENT) then
					tME.fProximoEstado(I_MOD_INICIAL, I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA)
					return false, tTela
							
				--S_MENU_OPCAO_MENU_PRINCIPAL
				elseif (tTela.params[1] == HF_BUTTON_FIRST_BUTTON) then
					tEstado.modulo = I_MOD_INICIAL
					tEstado.passo = I_ESTADO_INICIAL_MOSTRAR_OPCOES_MENU
					fPassaPelaTela = false

				--S_MENU_OPCAO_FUNCAO				
				elseif (tTela.params[1] == HF_BUTTON_SECOND_BUTTON or tTela.params[1] == HF_BUTTON_KEYBOARD_ACCEPT_BUTTON or tTela.params[1] == HF_BUTTON_KEYBOARD_F_BUTTON or tTela.params[1] == HF_BUTTON_KEYBOARD_ENTER) then 
					tEstado.modulo = I_MOD_INICIAL
					tEstado.passo = I_ESTADO_INICIAL_DIGITE_A_FUNCAO
					fPassaPelaTela = false

				-- outros n�meros = fun��o inativa
				elseif(tonumber(tTela.params[1]) ~= nil and tonumber(tTela.params[1]) >= 1 and tonumber(tTela.params[1]) <= 9) then
					tEstado.modulo = I_MOD_INICIAL
					tEstado.passo = I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA
					tTela.telaID = I_TELA_ID_DIALOG
					tTela.params = {sTitulo = "", sTexto = "fun��o inativa", iTempo = 1 }
					return true, tTela

				elseif (tTela.params[1] == HF_CHIP_EVENT) then
					tEstado.modulo = I_MOD_INICIAL
					tEstado.passo = I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA
					tTela.telaID = I_TELA_ID_DIALOG
					tTela.params = {sTitulo = "", sTexto = "Ocorreu um evento de chip!", iTempo = 1 }
					return true, tTela

				elseif(tTela.params[1] == HF_MAGNETIC_EVENT) then
					tEstado.modulo = I_MOD_INICIAL
					tEstado.passo = I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA
					tTela.telaID = I_TELA_ID_DIALOG
					tTela.params = {sTitulo = "", sTexto = "Ocorreu um evento de cart�o magn�tico!", iTempo = 1 }
					return true, tTela
				
				else
					tEstado.modulo = I_MOD_INICIAL
					tEstado.passo = I_ESTADO_INICIAL_OPERACAO_CANCELADA
					fPassaPelaTela = false
				end
			end
			return fPassaPelaTela, tTela 
		end,			
		---------------------------------------------------------------------------------------------
		--Mosta a tela que pede a digita��o da fun��o desejada
		[I_ESTADO_INICIAL_DIGITE_A_FUNCAO			] = function(tTela) 
			tEstado.modulo = I_MOD_INICIAL
			tEstado.passo = I_ESTADO_INICIAL_EXECUTAR_FUNCAO_ESCOLHIDA
			tTela.telaID = I_TELA_ID_INPUT
			tTela.params = {sTitulo = "fun��o:", sTexto = "", iTamanhoMin = 1 ,iTamanhoMax = 2, iTipo = I_INPUT_TIPO_NUMERICO}
			return true, tTela 
		end,

		---------------------------------------------------------------------------------------------
		--Executa a fun��o escolhida
		[I_ESTADO_INICIAL_EXECUTAR_FUNCAO_ESCOLHIDA ] = function(tTela) 

			local funcaoEscolhida = tonumber(tTela.params[2])
			
			-- tecla cancela
			if (tTela.params[1] == 1001) then
				tEstado.modulo = I_MOD_INICIAL
				tEstado.passo = I_ESTADO_INICIAL_OPERACAO_CANCELADA
				return false, tTela
			elseif(funcaoEscolhida == 99) then
				tEstado.modulo = I_MOD_INICIAL
				tEstado.passo = I_ESTADO_INICIAL_SAIR
				return false, tTela
			else
				tEstado.modulo = I_MOD_INICIAL
				tEstado.passo = I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA
				tTela.telaID = I_TELA_ID_DIALOG
				tTela.params = {sTitulo = "", sTexto = "fun��o inativa", iTempo = 1 }
				return true, tTela
				 
			end			
		end, 	

		---------------------------------------------------------------------------------------------
		--Mostra as op��es do menu inicial
		[I_ESTADO_INICIAL_MOSTRAR_OPCOES_MENU 		] = function(tTela) 

			tEstado.modulo = I_MOD_INICIAL
			tEstado.passo = I_ESTADO_INICIAL_MENU_ESCOLHIDO
			tTela.telaID = I_TELA_ID_MENU 
			tTela.params = { sTitulo = "", tItens = {S_MENU_OPCOES_PAG, S_MENU_OPCOES_ADMIN}}

			return true, tTela 
		end, 	

		---------------------------------------------------------------------------------------------
		--Pega a op��o do menu escolhida e envia para o m�dulo que o gerencia
		[I_ESTADO_INICIAL_MENU_ESCOLHIDO 			] = function(tTela) 

			if(tTela.params[1] == 0) then --S_MENU_OPCOES_PAG
				tTela.telaID = I_TELA_ID_DIALOG
				tTela.params = {sTitulo = "", sTexto = "Menu de pagamentos escolhido!", fImagemRede = true, iTempo=1}
				tME.fProximoEstado(I_MOD_INICIAL, I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA)			
				return true, tTela 
			elseif(tTela.params[1] == 1) then --S_MENU_OPCOES_ADMIN
				tTela.telaID = I_TELA_ID_DIALOG
				tTela.params = {sTitulo = "", sTexto = "Menu de administra��o escolhido!", fImagemRede = true, iTempo=1}
				tME.fProximoEstado(I_MOD_INICIAL, I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA)			
				return true, tTela
			else
				tEstado.modulo = I_MOD_INICIAL
				tEstado.passo = I_ESTADO_INICIAL_OPERACAO_CANCELADA
				return false, tTela
			end

		end,	

		---------------------------------------------------------------------------------------------
		-- Mostra dialog de opera��o cancelada chamada ao apertar o bot�o cancelar
		[I_ESTADO_INICIAL_OPERACAO_CANCELADA		] = function(tTela) 
			tTela.telaID = I_TELA_ID_DIALOG
			tTela.params = {sTitulo = "", sTexto = "opera��o\ncancelada", fImagemRede = true, iTempo=1, fBipErro = true}
			tME.fProximoEstado(I_MOD_INICIAL, I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA)			
			return true, tTela 
		end, 	

		---------------------------------------------------------------------------------------------
		-- Sair do sistema
		[I_ESTADO_INICIAL_SAIR 						] = function(tTela) 

			tTela.telaID = I_TELA_ID_DIALOG
			tTela.params = {sTexto =  "saindo...", iTempo = 1}
			tTela.acoes = {{acao = I_ACAO_SAIR}}
			return true, tTela 
		end 	

	},
	ControlarNavegacao = function (tTela)
		return tIniciaCT.tPassos[tME.fPassoAtual()](tTela)
	end
}
-- se quiser atribuit ao tControladores logo no require
return tIniciaCT