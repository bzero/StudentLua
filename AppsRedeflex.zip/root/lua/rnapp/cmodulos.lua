---
-- Arquivo de constantes do m�dulos da m�quina de estados.
-- @author Aleff Henrique
-- @release Vers�o inicial 1.0
-- @copyright CESAR

I_MOD_INICIAL     			= 1
I_MOD_PAG         			= 4
I_MOD_CREDITO     			= 5
I_MOD_ADMIN       			= 6
I_MOD_FUNC        			= 7
I_MOD_DEBITO      			= 8
I_MOD_RELAT       			= 9
I_MOD_TECNI       			= 10
I_MOD_BAIXA       			= 11
I_MOD_ESTORNO     			= 12
I_MOD_CONEXAO     			= 13
I_MOD_FINALIZACAO 			= 14
I_MOD_RESUMO      			= 15
I_MOD_TELE_AUTO   			= 16
I_MOD_TRANS       			= 17
I_MOD_CONFIG      			= 18
I_MOD_VOUCHER     			= 19
I_MOD_LOJISTA     			= 20
I_MOD_FUNCOES_APAGA         = 21
I_MOD_CONFIG_COMUNICACAO    = 22
I_MOD_TERMINAL 				= 23
I_MOD_REIMPRESSAO 			= 24
I_MOD_TECN_LOGIN 			= 25
I_MOD_QUEDA_ENERGIA 		= 26

-- para efeitos de DEBUG
tNomeModulos = {
	[1 ]	= "I_MOD_INICIAL 			",
	[4 ]	= "I_MOD_PAG 				",
	[5 ]	= "I_MOD_CREDITO 			",
	[6 ]	= "I_MOD_ADMIN 				",
	[7 ]	= "I_MOD_FUNC 				",
	[8 ]	= "I_MOD_DEBITO 			",
	[9 ]	= "I_MOD_RELAT 				",
	[10] 	= "I_MOD_TECNI 				",
	[11] 	= "I_MOD_BAIXA 				",
	[12] 	= "I_MOD_ESTORNO 			",
	[13] 	= "I_MOD_CONEXAO 			",
	[14] 	= "I_MOD_FINALIZACAO 		",
	[15] 	= "I_MOD_RESUMO 			",
	[16] 	= "I_MOD_TELE_AUTO 			",
	[17] 	= "I_MOD_TRANS 				",
	[18] 	= "I_MOD_CONFIG 			",
	[19] 	= "I_MOD_VOUCHER 			",
	[20] 	= "I_MOD_LOJISTA  			",
	[21] 	= "I_MOD_FUNCOES_APAGA 		",
	[22] 	= "I_MOD_CONFIG_COMUNICACAO ",
	[23] 	= "I_MOD_TERMINAL 			",
	[24] 	= "I_MOD_REIMPRESSAO 		",
	[25] 	= "I_MOD_TECN_LOGIN 		",
	[26]	= "I_MOD_QUEDA_ENERGIA 		"
}