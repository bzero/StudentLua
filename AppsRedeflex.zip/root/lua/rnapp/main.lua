S_GUI_MODE_WIN = "MICROSOFT"
S_GUI_MODE_POS = "INGENICO"
S_GUI_MODE_IOS = "IOS"
S_GUI_MODE_ANDROID = "ANDROID"
iGuiMode = os.getenv(SYS_PLATFORMNAME)

-- Carregando constantes
require("cestados")
require("cacoes")
require("cmodulos")
require("cui")
require("cgrafico")

tEstado = {
	modulo = I_MOD_INICIAL,
	passo = I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA
}

-- m�quina de estados
tME = {
	fDEBUG = false,
	tEstadoAnterior = {},
	fCriaPassoBasico = function(modulo, passo, fPassaPelaGUI)
		return function(tTela)
			tME.fProximoEstado(modulo, passo)
			return fPassaPelaGUI, tTela
		end
	end,
	
	fMostraEstadoAtual = function( )
		printer.print(tostring(tNomeModulos[tME.fModuloAtual()]) .. "/" .. tostring(tME.fPassoAtual()))
		--printer.print("------------------------")
	end,
	fPassoAtual = function ( )
		return tEstado.passo
	end,
	fModuloAtual = function( )
		return tEstado.modulo
	end,
	fProximoEstado = function( modulo, passo )
		tME.tEstadoAnterior.modulo, tME.tEstadoAnterior.passo = tEstado.modulo, tEstado.passo
		tEstado.modulo, tEstado.passo = modulo, passo
	end
}
local fPassaPelaGUI = false

--Carregar controlador
require("iniciact")


tControladores = {
	[I_MOD_INICIAL	 			]= tIniciaCT
}

fTrataOciosidade = false


mainRN = {	
	main = function(tTela)

		if(tME.fDEBUG) then
			tME.fMostraEstadoAtual()
		end
		---------------------------------------------------------------------------------------------		
		-- Executa o pr�ximo m�dulo/estado
		if(tControladores[tME.fModuloAtual()]) then						

			fPassaPelaGUI = false
			fPassaPelaGUI, tTela = tControladores[tME.fModuloAtual()].ControlarNavegacao(tTela)

			if(tME.fDEBUG) then
				printer.print("fPassaPelaGUI: " .. tostring(fPassaPelaGUI))

				-- printar tudo que est� na tela
				printer.print("tTela: ")
				hutil.fPrintTable(tTela)
			end

			if(fPassaPelaGUI) then
				return tTela
			else
				return mainRN.main(tTela)
			end
		else
			-- se houve algum erro na escolha do m�dulo, volta para tela inicial 
			if(tME.fDEBUG) then
				printer.print("m�dulo n�o existe: " .. tostring(tME.fModuloAtual()))
			end
			tME.fLimparCallback()
			tME.fProximoEstado(I_MOD_INICIAL,I_ESTADO_INICIAL_MOSTRA_PRIMEIRA_TELA)
			return mainRN.main(tTela)
		end
	end
}

function main (params, identity)
	if (params.tTela == nil) then
		local tTela = { telaID = "", params = {}}			
		return mainRN.main(tTela)
	else
		return mainRN.main(params.tTela)
	end
end
