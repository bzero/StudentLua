require('hutil')
require('cgrafico')
require('logdebug')

I_ALINHADO_ESQUERDA = 0
I_ALINHADO_CENTRO 	= 1
I_ALINHADO_DIREITA 	= 2

-- ========================================= TRATAMENTO DEVICE ========================================= 
--capacidades da tela
local dados, err = nil
if (device and device.screen_get_capabilities) then
    dados, err = device.screen_get_capabilities()
end

--colorido touch (iwl280 e vx680)
if dados and dados[1].mode == 3 and dados[1].orientation == 1 then
	PLATF_DISPL_TOUCH = 1
	require ('gui')
--colorido, paisagem sem touch (ict250)
elseif dados and dados[1].mode == 3 and dados[1].orientation == 2 then
	PLATF_DISPL_GRAFICO = 1
	require ('gui')
-- monocromatico
elseif dados and dados[1].mode == 2 then
	require ('guimono')
--suportando legado POO (entregas 1 e 2 da plataforma), colorido touch
else
	PLATF_DISPL_TOUCH = 1
	require ('gui')
end


-- ========================================= MAIN ========================================= 
function main(params, identity)
	
	-- Iniciando as configura��es da GUI
	local iRet = tGUI.Init()
	if iRet ~= 0 then
		return
	end
	
	while true do
		local tTela = {}
		tTela.params = { sTitulo = "APP Basico", 
						 iTempo = 30, 
						 fTrataTempo = true,
						 tItens = { "Dialog", 
									"Menu",
									"Input"
						} }
		
		tGUI.Menu(tTela)
		local iTecla = tTela.params[1]
		--printer.print("iTecla "..tostring(iTecla))
		if (iTecla == 0) then
			--DIALOG
			tTela.params = {sTitulo = "", 
							sTexto = "Dialog Exemplo", 
							fLerCartao = false, 
							iTempo = 10,
							fTrataTempo = true,
							tBotoesRodape = {	"botao 1", 
												"botao 2"}
							}
			tTela = tGUI.Dialog(tTela)
		elseif (iTecla == 1) then
			--MENU
			tTela.params = { sTitulo = "Menu Exemplo", 
							 iTempo = 10, -- timeout
							 fTrataTempo = true,
							 tItens = { "Item 1", 
										"Item 2"
							 } }
			
			tGUI.Menu(tTela)
		elseif (iTecla == 2) then
			--INPUT
			tTela.params = {sTitulo = "", sTexto = "n�mero ocorr�ncia:", iTamanhoMax = 4, iTamanhoMin = 4, bIsCampoSenha = false, iTempo = 10}
			--tTela.params = {sTitulo = "Input Exemplo", 
			--				sTexto = "Informa��o adicional", 
			--				--iTipo = 2, 
			--				iTamanhoMin = 1, -- minimo de caracteres
			--				iTamanhoMax = 4, -- maximo de caracteres
			--				fLerCartao = false, -- aceitar cart�o, chip e tarja
			--				--fCampoSenha = false, -- Input de senha
			--				fEValor = false} -- passagem de valor R$
			
			tGUI.Input(tTela)
		elseif (iTecla == 1001) then
			--SAIR
			return true
		end

	end
end
-- ========================================= FIM MAIN ========================================= 
