-----------------------------------------------------------------------------------------------
-- Nome do arquivo:                 tnovidad.lua                                             --
-- Descricao:                       Tabela para ajustar a mensagem para impressão            --
-----------------------------------------------------------------------------------------------
--                                 Historico                                                 --
-- Nome                            Data          Descricao                                   --
-----------------------------------------------------------------------------------------------
-- Danilo de Souza Pinto           29/01/2015    Versao inicial                              --
-----------------------------------------------------------------------------------------------

tNovidadesImp = {

	---
	-- Quebra a mensagem em linhas (acabam em "\r") e retorna elas em uma tabela
	--@author Marcelo Tosihiko Sigueoka
	--@param sMsg Buffer contendo as linhas (acabam em "\r")
	--@param tLinhasMsg Tabela contendo as linhas. Cada posição da tabela representa uma linha
	--@return iNumLinhas Número de linhas
	QuebraLinhasMsg =  function(sMsg)
	   local iNumLinhas = 0
	   local tLinhasMsg = {}
	   
	   -- Coloca um "\r" no final para que o gmatch possa achar todas as linhas
		if (string.sub(sMsg, sMsg:len()) ~= "\r") then sMsg = sMsg .. "\r" end
		
		local tLinhaBranco = {sTexto = "  ", fFonteGrande = false, iAlinhamento = I_ALINHADO_ESQUERDA}
		
		table.insert(tLinhasMsg,{sTexto = "NOVAS FUNCOES", fFonteGrande = true, iAlinhamento = I_ALINHADO_CENTRO}	)
		table.insert(tLinhasMsg, tLinhaBranco)
		
		for sLinha in string.gmatch(sMsg, "(.-)(\r)") do 
			iNumLinhas = iNumLinhas + 1 
			
			iTabulacao = string.find(sLinha, "~t")
			if (iTabulacao ~= nil) then
				table.insert(tLinhasMsg, tLinhaBranco)
				table.insert(tLinhasMsg, tLinhaBranco)
				table.insert(tLinhasMsg, tLinhaBranco)
			else
				sLinha = string.gsub(sLinha, "~r","")
				sLinha = string.gsub(sLinha, "~d","")
				sLinha = string.gsub(sLinha, "~t","")
				sLinha = string.gsub(sLinha, "\n","")
				table.insert(tLinhasMsg,{sTexto = string.upper(sLinha), fFonteGrande = false, iAlinhamento = I_ALINHADO_ESQUERDA}	)
			end

		end
		
		table.insert(tLinhasMsg, tLinhaBranco)
		
		if (iNumLinhas == 0) then 
			iNumLinhas = 1 -- Não achou nenhum "\r"         
			tLinhasMsg[iNumLinhas] = sMsg
		end
		
		return tLinhasMsg, iNumLinhas
	end
}