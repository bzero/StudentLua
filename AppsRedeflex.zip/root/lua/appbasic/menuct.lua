local xMenuCT = {}
	--local xMenuUI = require("menuui")
	local tOpcoes = {}
	local menuH = nil
	local aceitou = nil

	function xMenuCT.criarMenuFuncUI(tOpcoesMenu, bTemNumeracao, iTempo)
		menuH = ui.menu('',tOpcoesMenu)
		aceitou = menuH:show( iTempo )
		
		if aceitou then
			return menuH:accepted()
		else
			return -1
		end
	end

return xMenuCT