---
-- Componente gen�rico de texto. 
-- @author Aleff Henrique
-- @release Vers�o inicial 1.0
-- @copyright CESAR
local fSaindoTecla = false
local iTecla = -1
local imgTelaInicial = nil
local bImagemAnim = false

local imagemTelaInicial = nil


tDialogUI = {
	
	---
	-- Mostra a mensagem desejada e caso a tela apresente alguma funcionalidade 
	-- a mais espera o usu�rio entrar 1 ou 2 no teclado.
	-- @author Aleff Henrique 
	-- @param tParams: tabela com sTitulo, sTexto, iTempo
	-- @return KEY_ONE caso o bot�o 1 seja clicado ou KEY_TWO para o bot�o 2.
	Mostrar = function(tParams)
		iTecla = -1	

		local fTipoTela = false
		local iTempo = tParams.iTempo
		
		if tParams.sTitulo == nil or tParams.sTitulo == '' then
			stitulo = ' ' --garantindo que o texto nao fica na primeira linha
		else
			stitulo = tParams.sTitulo
		end
		
		if tParams.sTexto == nil or tParams.sTexto == '' then
			stexto = ' '
		else
			stexto = tParams.sTexto
		end
		
		
		-- Tela Principal da Financeira
		if tParams.fImagemAnimada then
			display.clear()
			
			if imagemTelaInicial == nil then
				imagemTelaInicial = os.loadimage( '../shared/dsp_logo.bmp' )
			end
					
			local fonteCorrente = display.font()
			display.font("small")

			iDia = os.date("%d")
			sMes = hutil.converteMes(tonumber(os.date("%m")))
			iAno = os.date("%Y")
			
			display.print(iDia.." "..sMes.." "..iAno, 0, "center")
			display.printimage( imagemTelaInicial, 0, 8 )
			display.print("insira ou passe", 4, "center")
			display.print("o cartao", 5, "center")
			display.font(fonteCorrente)
		
		--Formata��o para mensagem com pergunta 1=sim/2=nao
		elseif (tParams.tBotoesRodape ~= nil) then
			ui.message(stitulo, stexto, nil, "center", "left", nil)
			fTipoTela = true
		--Tratamento especifico para tela de relat�rio
		elseif (tParams.dialogRelatorio) then
			fTipoTela = true
		--mensagem padrao
		else
			--display.clear()
			ui.message(stitulo, stexto, nil, "center", "center", nil)

		end
		
		local eventos
		if tParams.fLerCartao then
			LogDebug('fLerCartao TRUE', 1, I_LOGDEBUG_TIPO_UI)
			eventos = 0x000B
		else
			eventos = 0x0008
		end
		
		iTecla = -1
		local iTempo = tParams.iTempo

		if ((tParams.fTrataTempo or iTempo) and iTempo > 0) then
			LogDebug('Dialog. Tempo=' .. iTempo,1,I_LOGDEBUG_TIPO_UI)
			
			-- POS MONOCROM�TICO N�O EXIBE RELAT�RIO NA TELA.
			--- Ajuste para simular tecla SIM e RN imprimir relat�rio.
			if (not tParams.dialogRelatorio) then
				evt, track1, track2, track3 = ui.graphical_wait_events(iTempo, eventos)
				
			   --LogDebug('graphical_wait_events:evt:' .. tostring(evt), 1, I_LOGDEBUG_TIPO_UI)
			   
			   -->> RF 20-01-15
				if evt == IWAIT_EVT_TIMEOUT or evt == nil then
					iTecla = HF_TIMEOUT_EVENT
					--LogDebug('graphical_wait_events:TIMEOUT:', 1, I_LOGDEBUG_TIPO_UI)
				
				elseif evt == IWAIT_EVT_SWIPE then
					iTecla = HF_MAGNETIC_EVENT
					track1, track2, track3 = hutil.ajustaTrilhas(track1, track2, track3)
					--printer.print('graphical_wait_events:MAGNETICO:')
				
				elseif evt == IWAIT_EVT_KEYBOARD then
					iTecla = tonumber(track1)
					--printer.print('graphical_wait_events:KEYBOARD:' .. tostring(iTecla))
				
				elseif evt == IWAIT_EVT_TOUCH then
					iTecla = tonumber(track1) 
					--printer.print('graphical_wait_events:TOUCH:' .. tostring(track1))
				
					if (iTecla >= 0x30) and (iTecla <= 0x39) then
						iTecla = iTecla - 0x30 + 1
					end
					
					--printer.print('graphical_wait_events:TOUCH:' .. tostring(iTecla))
				
				elseif evt == IWAIT_EVT_CHIP then
					iTecla = HF_CHIP_EVENT
					--printer.print('graphical_wait_events:CHIP:')
				end
			else
				iTecla = HF_BUTTON_FIRST_BUTTON
			end
			--mapeamento de teclas
			--REMAPEAMENTO TIMEOUT
			
			if not iTecla then
				iTecla = HF_TIMEOUT_EVENT
			--REMAPEAMENTO DAS TECLAS DE MENU INICIAL
			elseif iTecla == KEY_F4 then
				--Mapeamento da tecla "avan�a papel"
				iTecla = KEY_F4
			elseif iTecla == PLATF_TECLA_MENU then -- or tParams.dialogRelatorio then -- AQUI
				iTecla = HF_BUTTON_FIRST_BUTTON
			elseif iTecla == PLATF_TECLA_FUNC or iTecla == KEY_MENU then
				iTecla = HF_BUTTON_SECOND_BUTTON
			--REMAPEAMENTO DAS TECLAS DE SIM E N�O
			elseif iTecla == RCKEY_ENTER or (fTipoTela and iTecla == 2) then
				iTecla = HF_BUTTON_SECOND_BUTTON
			elseif iTecla == RCKEY_CANCEL or (fTipoTela and iTecla == 3) then
				iTecla = HF_BUTTON_FIRST_BUTTON
			--0 a 9
			--elseif iTecla >= KEY_ZERO and iTecla <= KEY_NINE then
			--	iTecla = iTecla - 1
			-- Merge 14/01 F2_17- DP
			elseif iTecla >= KEY_ZERO and iTecla <= KEY_NINE then
				iTecla = iTecla - 1
			--	--LogDebug(key), 1	
			end
			
			if (iTecla ~= HF_TIMEOUT_EVENT) then
				--BeepClick()
			end

			
			LogDebug('iTecla Traduzida:' .. iTecla, 1, I_LOGDEBUG_TIPO_UI)
			LogDebug('tipo:' .. type(iTecla), 1, I_LOGDEBUG_TIPO_UI)
			
			--return ret, iTecla
			return iTecla, track1, track2, track3
		
		
		else
			return HF_TIMEOUT_EVENT
		end

	end


}


