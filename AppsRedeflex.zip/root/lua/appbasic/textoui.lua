local telaTexto = {}

	function telaTexto.showTela (tArgumentos)
		sMensagem = ui.transient(tArgumentos.titulo, tArgumentos.texto, 5000)
	end

return telaTexto