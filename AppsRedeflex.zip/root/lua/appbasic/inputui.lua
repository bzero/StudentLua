
local xInputUI = {}
	local iInputValor = -1
	local iTecla = -1
	local iInputTimeout = 30

	function xInputUI.show(tTabela)

		if(tTabela ~= nil and tTabela.iTamanhoMax == nil) then
			tTabela.iTamanhoMax = 10
		end

		if (tTabela.fCampoSenha) then
			--log.logburst('tTabela.iTamanhoMin ' .. tTabela.iTamanhoMin)
			if tTabela.iTamanhoMin == nil then
				tTabela.iTamanhoMin = 4
			end
		end

		if (tTabela.fEValor) then
			tTabela.iTamanhoMax = "#.###.###.###,##"
		elseif (tTabela.fData) then
			tTabela.iTamanhoMax = "##/##"
		end
		
		local sTipoDoTamanhoMax, sPatternAux
		sTipoDoTamanhoMax = type(tTabela.iTamanhoMax)
		
		if (sTipoDoTamanhoMax ~= "number") then
			local iTamanhoMaximo, itamanhoString, sAux
			sPatternAux = tTabela.iTamanhoMax
			sPatternAux = string.gsub(sPatternAux, "#", "@")
			iTamanhoMaximo = 0
			itamanhoString = tostring(tTabela.iTamanhoMax:len())
			itamanhoString = tonumber(itamanhoString)
			
			local i, sAux
			i = 1
			while (i <= itamanhoString) do
				sAux = sPatternAux:sub(i,i)
				if (sAux == "@") then
					iTamanhoMaximo = iTamanhoMaximo + 1
				end
				i = i + 1
			end
			tTabela.iTamanhoMax = iTamanhoMaximo
		end

		local xTextField = ui.textfield(tTabela.sTitulo, tTabela.sTexto, tTabela.iTamanhoMax, tTabela.iTamanhoMin, tTabela.fCampoSenha)
		
		if (sTipoDoTamanhoMax ~="number") then
			xTextField:pattern(sPatternAux, "@")
		end
		
		--- Input com formata��o padr�o
		if tTabela.iAlinhaEsq then
			xTextField:aligntext("left")
		else
			xTextField:aligntext("right")
		end
		
		xTextField:align("right")
		xTextField:aligntitle("center") -- titulo
		xTextField:alignlabel("left")   -- texto
		
		if (tTabela.sTitulo == "fun��o:" or tTabela.sTitulo == "funcao:") then
			xTextField:aligntitle("left") -- titulo
		end
			
		if (tTabela.sTextoInput) then
			xTextField:text(tTabela.sTextoInput)
		end		

		fShow = xTextField:show(iInputTimeout)
		
		if(fShow == true) then
			iInputValor = xTextField:text()
			iTecla = HF_BUTTON_KEYBOARD_ACCEPT_BUTTON
		else
			iTecla = HF_BUTTON_KEYBOARD_REJECT_BUTTON
		end
		--printer.print("iTecla "..iTecla)
		return iTecla, iInputValor
	end

return xInputUI
