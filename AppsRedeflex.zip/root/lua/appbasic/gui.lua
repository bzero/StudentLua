
--MODELO_ICT_250 = 'WINDOWS'

if PLATF_DISPL_GRAFICO then
	require("graph250")
else
	require("graph")
end

local S_BATERIA_TELECARGA, S_CARREGAR_BATERIA, S_BATERIA_ACABANDO = 1,2,3
local fTelaCarregarBateria = true
tGUI = {

ChecaTitulo = function (sMsg)
	
	local tListaMsgs = {
      ["relat�rio resumido"]      = true,
      ["relat�rio detalhado"]     = true,
      ["relat�rio de estorno"] 	  = true,

   }
   
   if (tListaMsgs[string.lower(hutil.trim(sMsg))]) then
      return true
   end
   
   return false
end,

Input = function(tTela)
	if tTela.params.sTexto == nil or tTela.params.sTexto == '' then
		if tTela.params.sTitulo ~= nil then
			tTela.params.sTexto = tTela.params.sTitulo
		else
			tTela.params.sTexto = ""
		end
	end
			
	if (tTela.params.fCampoSenha) then -- iTamanhoMax   iTamanhoMin
		--log.logburst('tTela.params.iTamanhoMin ' .. tTela.params.iTamanhoMin)
		if tTela.params.iTamanhoMin == nil then
			tTela.params.iTamanhoMin = 4
		end
		tTela.params = graph.InputSenhaAberta(tTela.params)-- 4 --tTela.params.iQtdeDigSenha
	else
		tTela.params = graph.Input(tTela.params)
	end
			
	return tTela
end,

Dialog = function(tTela)
	--log.logburst('DIALOG ' )  -- DSP - DEBUG
	if tTela.iTempo ~= nil then
		tTela.params.iTempo = tTela.iTempo
		tTela.iTempo = nil
	end
	
	if graph.MsgComAnimacao(tTela.params.sTexto) then
		tTela.params.fAnimacao = true
	else
		tTela.params.fAnimacao = false
	end
	
	if	(tTela.params.dialogRelatorio) or tGUI.ChecaTitulo(tTela.params.sTitulo) then
			tBotoesInferiores = {}
			tBotoesInferiores.fBotaoNao = true
			tBotoesInferiores.fBotaoSim = true
			iTimeout = 3000
			tTeclaRetorno = {}
			tTeclaRetorno.iBotaoEsquerda = HF_BUTTON_FIRST_BUTTON -- HF_BUTTON_FIRST_BUTTON -- RCKEY_ENTER
			tTeclaRetorno.iBotaoDireita = HF_BUTTON_SECOND_BUTTON -- HF_BUTTON_SECOND_BUTTON --RCKEY_CANCEL 
			
			--ExibeRelatorioTela(sTitRelatorio, sRelatorio, tTeclaRetorno, tBotoesInferiores, iTimeout)
			-- <T> indica que � titulo e deve ser formatado em fonte maior na impress�o
			str = string.gsub(tostring(tTela.params.sTexto), "<T>", "") -- retirar <T> quando relat�rio exibido no display
			str = string.gsub(str, "RELATORIO DETALHADO", "")
			str = string.gsub(str, "RELATORIO RESUMIDO", "")

			iRet, iTecla = graph.ExibeRelatorioTela(tTela.params.sTitulo, str, tTeclaRetorno, tBotoesInferiores, iTimeout)
			
			--mapeamento de teclas - DSP
			if iRet == RET_CANCELADO then
				iRet = HF_BUTTON_FIRST_BUTTON
			end

			if iTecla == RCKEY_CANCEL then
				iTecla = HF_BUTTON_FIRST_BUTTON
			elseif iTecla == RCKEY_ENTER then
				iTecla = HF_BUTTON_SECOND_BUTTON
			end
			-- remover esta linha
			--return iRet, iTecla
			
	else
		--iRet, iTecla = graph.Mensagem(tTela.params)
		iTecla, track1, track2, track3 = graph.Mensagem(tTela.params)
	end
		
		tTela.params.sResp = nil
		tTela.params[1] = iTecla	
		tTela.params.sTrilha1 = track1 
		tTela.params.sTrilha2 = track2
			
		--return iTecla
		return tTela
	
end,

Menu = function(tTela)
	--log.logburst('MENU ' .. tTela.params.sTitulo)  -- DSP - DEBUG
	
	iRet, iValor = graph.Menu(tTela.params) --GCM
	--log.logburst('retorno menu=' .. iRet )
	--if iRet == RET_OK and iValor == RCKEY_CANCEL then
	--	tTela.params = {HF_BUTTON_KEYBOARD_REJECT_BUTTON}
	if iRet == RET_OK then
		--log.logburst('escolha:' .. iValor)
		tTela.params = {iValor-1}
	elseif iRet == RET_CANCELADO then
		tTela.params = {HF_BUTTON_KEYBOARD_REJECT_BUTTON}
	elseif iRet == RET_MENU_VOLTAR then
		tTela.params = {HF_BUTTON_FIRST_BUTTON}
	elseif iRet == RET_MENU_INICIAL then
		tTela.params = {HF_BUTTON_SECOND_BUTTON}
	--timeout
	elseif iRet == -1 then
		tTela.params = {HF_BUTTON_KEYBOARD_REJECT_BUTTON}
	else
		tTela.params = {iRet}
	end
		
	return tTela
end,

--verifica se o n�vel de bateria est� baixo e gerencia as mensagens a serem exibidas na tela
GerenciaBateria = function(tParams)
		
		
		
		-- Armazena o status atual da bateria
		-- status (1 = carregando)
		local iCargaBateria, iStatusBateria = os.batterystatus() -- valor da bateria e status
		
		--se nao tem valor, eh desktop
		if iCargaBateria == nil then
			iCargaBateria = 100
		end
		
		--se nao tem status, eh desktop
		if iStatusBateria == nil then
			iStatusBateria = SYS_BATTERY_CHARGING
		end
		
	
		if(tParamsBateria ~= nil)then
		-- fBateriaTelecarga � setado como true na a��o executar telecarga 
		if(iStatusBateria ~= SYS_BATTERY_CHARGING)then 
				-- verifica se o nivel da bateria esta baixo
				local retorno = ""
				if(fBateriaTelecarga and iCargaBateria <= tParamsBateria.iNivelMinimoBateria)then
					retorno = graph.ExibeMensagemBateria(S_BATERIA_TELECARGA)
					return tParams
				elseif(iCargaBateria <= tParamsBateria.iNivelBaixoBateria and iCargaBateria > tParamsBateria.iNivelCriticoBateria) then
					
					if(fTelaCarregarBateria)then
						-- exibe a tela de bateria fraca apenas uma vez e depois ela fica "false" at�
						-- que o POS fique com a bateria fraca novamente, ap�s uma carga
						retorno = graph.ExibeMensagemBateria(S_CARREGAR_BATERIA)
						fTelaCarregarBateria = false
					end
					-- parametro que indica que a tela de bateria fraca deve ser adicionada
					-- entre as telas do menu princial
					tParams.fImagemBateriaFraca = true
				
				elseif(iCargaBateria <= tParamsBateria.iNivelCriticoBateria) then
					-- bateria no n�vel critico
					retorno = graph.ExibeMensagemBateria(S_BATERIA_ACABANDO)
				else
					return tParams				
				end
						
				-- verifica se a bateria j� foi incializada
				-- true - bateria inicializada 
				-- false - bateria nao inicializada
				-- TODO : implementar utilizacao da funcao os.isbatteryinitialized()
				--local fBateriaInicializada = os.isbatteryinitialized()
				local fBateriaInicializada = true
				if(fBateriaInicializada) then
					tParams.fImagemBateriaInic = false
				else
					-- se a bateria ainda nao foi incializada, este parametro indica que 
					-- a tela de "inicializar a bateria" deve ser adicionada na lista de telas do menu
					tParams.fImagemBateriaInic = true
				end
		elseif(iStatusBateria == tDicBit48)then -- bateria carregando
		-- quando o carregador � conectado, este parametro 
		-- volta a ser true e ser� usado novamente quando a bateria estiver fraca
			fTelaCarregarBateria = true
		end
		end
	return tParams
end,

MensagemInicial = function()
	graph.Mensagem({sTitle = "",sTexto = "VERIFICANDO \nVERSAO DA \nAPLICACAO"})
	graph.Mensagem({sTitle = "",sTexto = "INICIANDO \nAPLICACAO"})
end,

ParametrosVazios = function()
	
	tTela = {}
	tTela.telaID = I_TELA_ID_DIALOG
	tTela.params = {}
	tTela.params.sTitle = ''
	tTela.params.sTexto = 'erro na itera��o com a RN'
	tTela.params.iTempo = 5
	
	return false, nil
end,

VerificaTelas = function(params)
	if (params.fTelaNovidades == true) then
		params.fTelaNovidades = false
		iRet = graph.ExibeNovidades(params.sArquivo)
	elseif (params.fAjusteTela) then
		params.fAjusteTela = false
		iRet = graph.AjustarTela()
	end
end,

fCallbackFab = function(tCampos)

	-- CAMPOS DA TELA DE SENHA
	local sMensagemFinal = tCampos
	local sTitulo = ""
	local sParcelas = nil
	local sValor = ""
	local sMsgServico = ""
	local _, posParcelas = sMensagemFinal:find("P: ")
	local _, posValor = sMensagemFinal:find("V: ")
	local _, posMsgServico = sMensagemFinal:find("SERV: ")
	local sMsgSenha = "digite a senha no\nteclado num�rico:"
	local fValor = true -- tem valor

    if (sMensagemFinal:find("SC:") ~= nil) then sTitulo = "cr�dito\n"
    elseif (sMensagemFinal:find("SD:") ~= nil) then sTitulo = "d�bito\n"
    elseif (sMensagemFinal:find("SV:") ~= nil) then sTitulo = "voucher\n"
    elseif (sMensagemFinal:find("SP:") ~= nil) then sTitulo = "pre-autoriza��o\n"
    elseif (sMensagemFinal:find("SL:") ~= nil) then sTitulo = "private label\n"
    elseif (sMensagemFinal:find("SS:") ~= nil) then sTitulo = "simula��o\n"
    elseif (sMensagemFinal:find("ST:") ~= nil) then sTitulo = "contrata��o\n"
    elseif (sMensagemFinal:find("TS:") ~= nil) then 
    	sTitulo = "troca de senha\n"
    	local _, posMsg = sMensagemFinal:find("TS: ")
    	sMsgSenha = sMensagemFinal:sub(posMsg + 1)
    	fValor = false
    elseif (sMensagemFinal:find("SG:") ~= nil) then sTitulo = "lavagem\n"
    elseif (sMensagemFinal:find("SA:") ~= nil) then sTitulo = "abastecimento\n"
    elseif (sMensagemFinal:find("SR:") ~= nil) then sTitulo = "troca de �leo\n"
    elseif (sMensagemFinal:find("SE:") ~= nil) then sTitulo = "ped�gio\n"
    elseif (sMensagemFinal:find("SO:") ~= nil) then sTitulo = "outros\n"
    end

	if (posParcelas ~= nil) then 
		sParcelas = sMensagemFinal:sub(posParcelas + 1):sub(0, sMensagemFinal:sub(posParcelas + 1):find("\n") - 1) 
	end

	if (posValor ~= nil) then
		sValor = sMensagemFinal:sub(posValor + 1):sub(0, sMensagemFinal:sub(posValor + 1):find("\n") - 1)
	end
	
	if (posMsgServico ~= nil) then
		sMsgServico = sMensagemFinal:sub(posMsgServico + 1):sub(0, sMensagemFinal:sub(posMsgServico + 1):find("\n") - 1)
	end

	local sLayoutMsg = "~U036~I001~U158~F00%s~D000~#FFFFFF240064"
	local sLayoutPin = ""
	local sLayoutTitulo, sLayoutValor, sLayoutServico, sLayoutParcelas, sLayoutMsgSenha, sLayoutInput
	sLayoutTitulo = "~D000~I041~C~U024~F03" .. sTitulo

	if (fValor) then
		sLayoutValor = "~U090~L015~F03" .. "valor: ~L065~F02" .. sValor
	else
		sLayoutValor = ""
	end
	

	if (sParcelas ~= nil) then
		sLayoutParcelas = "~U122~L015~F03" .. "parcelas: ~L095~F02" .. sParcelas
	else
		sLayoutParcelas = ""
	end
	
	-->> RF 25-02-15 Acrescentando novo campo de texto. Vindo de algum servi�o
	if (sMsgServico ~= "") then
		if (sParcelas ~= nil) then
			sLayoutServico = "~U152~L015~F03" .. sMsgServico:sub(1, sMsgServico:find(":")) .. "~L065~F02" .. sMsgServico:sub(sMsgServico:find(":"), #sMsgServico)
		else
			sLayoutServico = "~U122~L015~F03" .. sMsgServico:sub(1, sMsgServico:find(":")) .. "~L065~F02" .. sMsgServico:sub(sMsgServico:find(":"), #sMsgServico)
		end		
	else
		sLayoutServico = ""
	end
	--<<
	
	-->>RF 25-02-15 Campo de servico a mais altera a posi��o dos campos abaixo
	if (sLayoutParcelas ~= "" and sLayoutServico ~= "") then
		sLayoutMsgSenha = "~U185~L015~F02" .. sMsgSenha
		sLayoutInput = "~D045~C~I043{~D009~F08~$3%s}"
	else
		sLayoutMsgSenha = "~U155~L015~F02" .. sMsgSenha
		sLayoutInput = "~D065~C~I043{~D009~F08~$3%s}"
	end
	
	--sLayoutMsgSenha = "~U155~L015~F02" .. sMsgSenha
	--sLayoutInput = "~D065~C~I043{~D009~F08~$3%s}"

	sLayoutPin = sLayoutTitulo .. sLayoutValor .. sLayoutParcelas .. sLayoutServico .. sLayoutMsgSenha .. sLayoutInput

	local sCaractereSenha = "x"
	return {pin = sLayoutPin, pinChar=sCaractereSenha, msg = sLayoutMsg}
end,

fCallbackMensagem = function()
	local sLayoutMsg = "~U036~I001~U158~F00%s~D000~#FFFFFF240064"
	local tRegrasDeMensagem = {
		"processando","n�o retire\n o cart�o",
		"cartao","cart�o"
	}
	return { msg = sLayoutMsg, rules = tRegrasDeMensagem }
end,

fCallbackMenu = function()

	local sLayoutTitulo, tLayout4botoes,tLayout8botoes, sLayoutFooter
	--sLayoutTitulo = "~C~U024~F03%s"
	if sLayoutTitulo then
		tLayout4botoes = {
			"~U044~L015~I007{~L004~F01~$0~W1.%s~K031}",
			"~U100~L015~I007{~L004~F01~$0~W2.%s~K032}",
			"~U156~L015~I007{~L004~F01~$0~W3.%s~K033}",
			"~U212~L015~I007{~L004~F01~$0~W0.%s~K034}"
		}
	else
		tLayout4botoes = {
			"~U034~L015~I007{~L004~F01~$0~W1.%s~K031}",
			"~U090~L015~I007{~L004~F01~$0~W2.%s~K032}",
			"~U146~L015~I007{~L004~F01~$0~W3.%s~K033}",
			"~U202~L015~I007{~L004~F01~$0~W0.%s~K034}"
		}
	end
	tLayout8botoes = {
		"~U034~L015~I009{~L003~F01~$0~W1.%s~K031}",
		"~R015~I009{~L003~F01~$0~W2.%s~K032}",
		"~U090~L015~I009{~L004~F01~$0~W3.%s~K033}",
		"~R015~I009{~L003~F01~$0~W4.%s~K034}",
		"~U146~L015~I009{~L004~F01~$0~W5.%s~K035}",
		"~R015~I009{~L003~F01~$0~W6.%s~K036}",
		"~U202~L015~I009{~L004~F01~$0~W7.%s~K037}",
		"~R015~I009{~L003~F01~$0~W8.%s~K038}"
	}
	sLayoutFooter = "~D009~L015~I004{~F04~$4cancela~K00c}"
	return {tlt = sLayoutTitulo, bt4 = tLayout4botoes, bt8 = tLayout8botoes, ft = sLayoutFooter}
end,

Init = function()
	
	local file
	
	if PLATF_DISPL_GRAFICO then
		file = "igcfg250.dat"
	else
		file = "igcfg.dat"
	end
	
	return graph.init(file)
end


}