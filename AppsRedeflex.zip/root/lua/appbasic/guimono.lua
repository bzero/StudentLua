local xMenu = require("menuct")
local xInput = require("inputui")
local xDialog = require("dialogui")
local xTelaTexto = require("textoui")

require("tnovidad")


IWAIT_EVT_TIMEOUT = 0
IWAIT_EVT_SWIPE = 1
IWAIT_EVT_CHIP = 2
IWAIT_EVT_TOUCH = 4
IWAIT_EVT_KEYBOARD = 8

PLATF_TECLA_MENU      		= 21 --RCKEY_F1
PLATF_TECLA_MENU2     		= RCKEY_NEXT
PLATF_TECLA_MENU3     		= RCKEY_PREV
PLATF_TECLA_FUNC       		= 3003

RCKEY_O1     = 0x100
RCKEY_O2     = 0x101
RCKEY_O3     = 0x102
RCKEY_O4     = 0x103
RCKEY_O5     = 0x104
RCKEY_O6     = 0x105
RCKEY_O7     = 0x106
RCKEY_O8     = 0x107

RCKEY_F1     = 0x200
RCKEY_F2     = 0x201
RCKEY_F3     = 0x202
RCKEY_F4     = 0x203
RCKEY_F5     = 0x204
RCKEY_F6     = 0x205
RCKEY_F7     = 0x206
RCKEY_F8     = 0x207
RCKEY_F9     = 0x208
RCKEY_F10    = 0x209
RCKEY_F11    = 0x20A
RCKEY_F12    = 0x20B
RCKEY_F13    = 0x20C

RCKEY_NOVA_SIMULACAO  = 350 -- DSP
RCKEY_IMPRIMIR_SIMULACAO  = 349 -- DSP
RCKEY_CONTRATAR  = 101 -- DSP

TEMPO_OPERADOR      = 30   	  -- 30 segundos Espec. P0600

local tableAccents = {}
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "a"
    tableAccents["�"] = "c"
    tableAccents["�"] = "e"
    tableAccents["�"] = "e"
    tableAccents["�"] = "e"
    tableAccents["�"] = "e"
    tableAccents["�"] = "i"
    tableAccents["�"] = "i"
    tableAccents["�"] = "i"
    tableAccents["�"] = "i"
    tableAccents["�"] = "n"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "o"
    tableAccents["�"] = "u"
    tableAccents["�"] = "u"
    tableAccents["�"] = "u"
    tableAccents["�"] = "u"
    tableAccents["�"] = "y"
    tableAccents["�"] = "y"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "A"
    tableAccents["�"] = "C"
    tableAccents["�"] = "E"
    tableAccents["�"] = "E"
    tableAccents["�"] = "E"
    tableAccents["�"] = "E"
    tableAccents["�"] = "I"
    tableAccents["�"] = "I"
    tableAccents["�"] = "I"
    tableAccents["�"] = "I"
    tableAccents["�"] = "N"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "O"
    tableAccents["�"] = "U"
    tableAccents["�"] = "U"
    tableAccents["�"] = "U"
    tableAccents["�"] = "U"
    tableAccents["�"] = "Y"
 
-- Strip accents from a string
local function stripAccents( str )
        
    local normalizedString = ""
	
	if str then
 
		--for strChar in string.gfind(str, "([%z\1-\127\194-\244][\128-\191]*)") do
		-- LYF: o � n�o estava sendo encontrado. corresponde ao 250.
		for strChar in string.gfind(str, "([%z\1-\127\194-\250][\128-\191]*)") do
			if tableAccents[strChar] ~= nil then
				normalizedString = normalizedString..tableAccents[strChar]
			else
				normalizedString = normalizedString..strChar
			end
		end
	end
        
  return normalizedString
 
end

S_MENU_PARCELADO_ESTABELECIMENTO 						= "parcelado estabelec"
S_MENU_PARCELADO_EMISSOR 								= "parcelado emissor"
S_MENU_PRE_AUTORIZACAO 									= "pr�%-\nautoriza��o"
S_MENU_CAPTURA_CREDITO 									= "captura cr�dito"
S_MENU_OPCAO_SENHA 										= "resgate de senha"
S_MENU_SALDO 											= "saldo dispon�vel"
S_MENSAGEM_DIGITE_SENHA_RAV 							= "digite a senha do rav \nno teclado num�rico: "
S_DESEJA_REALIZAR_RAV_AVULSO							= "deseja realizar\nrav avulso%?"
S_CPF_RAV												= "cpf do propriet�rio:"
S_CONTRATAR_RAV_AUT										= "\ndeseja contratar rav\nautom�tico%?"
S_DESEJA_IMPRIMIR_COMPROVANTE							= "deseja imprimir\ncomprovante%?"

local tableShorten = {}
    tableShorten["codigo"] 								= "cod."
	tableShorten["c�digo"] 								= "cod."
	tableShorten["numero"] 								= "no"
	tableShorten["nmero"] 								= "no"
	tableShorten["nm "] 								= "no "
	tableShorten["4 �ltimos d�gitos:"]					= "digite 4 ultimos \ndigitos:"	
	tableShorten["4 ultimos d�gitos:"]					= "digite 4 ultimos \ndigitos:"	
	tableShorten[" ltimos"] 							= " ultimos"
	tableShorten[S_MENU_PARCELADO_ESTABELECIMENTO]		= "parc. estabel"
	tableShorten[S_MENU_PARCELADO_EMISSOR] 				= "parc. emissor"
	tableShorten[S_MENU_PRE_AUTORIZACAO]				= "pre-autoriz"
	tableShorten["imprimir via do cliente%?"] 			= "imprimir via do\ncliente?\n1.sim\n2.nao"
	tableShorten["imprimir via\n do cliente%?"] 		= "imprimir via do\ncliente?\n1.sim\n2.nao"
	tableShorten["imprimir via\ndo cliente%?"] 			= "imprimir via do\ncliente?\n1.sim\n2.nao"
	tableShorten[S_MENU_CAPTURA_CREDITO] 				= "capt credito"
	tableShorten["recarga celular"] 					= "recarga cel"
	tableShorten["recarga de celular"] 					= "recarga cel"
	tableShorten["c�digo seguran�a"] 					= "cod. seguran�a"
	tableShorten["private\nlabel"] 						= "private label"
	tableShorten["recarga cel"] 						= "recarga celular"
	tableShorten["deseja estornar �ltima transa��o"] 	= "deseja estornar �ltima\ntransa��o"
	tableShorten["consulta\n� cheque"] 					= "consulta cheque"
	tableShorten["consulta � cheque"] 					= "consulta cheque"
	tableShorten["digite a senha do lojista\r"] 		= "senha lojista"
	tableShorten[S_MENU_OPCAO_SENHA]					= "resgate senha"
	tableShorten[S_MENU_SALDO]							= "saldo disp."
	tableShorten[S_MENSAGEM_DIGITE_SENHA_RAV]			= "digite a senha do rav: "
	tableShorten[S_DESEJA_REALIZAR_RAV_AVULSO]			= "deseja realizar\nrav avulso?\n1.sim\n2.nao"
	tableShorten[S_CPF_RAV]								= "digite o cpf do\nproprietario:"	
	tableShorten[S_DESEJA_IMPRIMIR_COMPROVANTE]			= "deseja imprimir\ncomprovante?\n1.sim\n2.nao"
	tableShorten[S_CONTRATAR_RAV_AUT]					= "\ndeseja contratar\nrav autom�tico?\n1.sim\n2.nao"
	tableShorten["\nno teclado num�rico"]				= ""
	tableShorten["\nno teclado numerico"]				= ""
	tableShorten["\nno teclado num�rico:"]				= ""
	tableShorten["\nno teclado numerico:"]				= ""
	tableShorten["n�mero de parcelas:"]					= "no parcelas:"
	tableShorten["\nno teclado num�rico:"]				= ":"	
	tableShorten["confirmar estorno%?"]					= "confirmar?\n1.sim\n2.nao"
	tableShorten["ddd %+ n%. celular:"]					= "ddd+n.celular:"	
	tableShorten["por favor, refa�a\na transa��o.\nc�digo g4.1"]
														= "tente de novo-to"
	tableShorten["por favor, refa�a\na transa��o%.\ncod%. g4%.3"]
														= "tente de novo-id"
	tableShorten["por favor, ligue para\nrede e informe\nc�digo a%.6%-010"] 
														= "tente de novo�na"
	tableShorten["\n no teclado numerico%:"]			= "%:"
	tableShorten["\n no teclado num�rico%:"]			= "%:"
	tableShorten["opera��o completada"]					= "opera��o\ncompletada"
	tableShorten["apaga desfazimento"]					= "apaga desfzto"
	tableShorten["apagar desfazimento"]					= "apagar desfzto"
	tableShorten["selecione a operadora"]				= "operadora"
	tableShorten["selecione o valor"]					= "valor recarga"
	tableShorten["realizar o download?"]				= "realizar o\ndownload?"
	tableShorten["existe uma atualiza��o para o seu terminal"]	
														= "existe uma\natualiza��o para o\nseu terminal"
	tableShorten["com o rav autom�tico voc� \nreceber� vendas a cr�dito%(� \nvista e parcelado%) sempre no \npr�ximo dia �til ap�s a venda"]
														= "com o rav autom�tico\nvoc� receber� vendas\na cr�dito (� vista e\nparcelado) sempre no\npr�ximo dia util\nap�s a venda"
	tableShorten["o valor dispon�vel pode ser \nsuperior ao valor solicitado,\npois a composi��o do rav varia de \nacordo com as vendas do \nper�odo"]
														= "o valor dispon�vel\npode ser superior ao\nsolicitado, pois a\ncomposi��o de\nvalores do rav\nvariam de acordo com\nas vendas do per�odo"
	tableShorten["teste de comunica��o\ntransa��o\ncompletada"] = " teste comunic.\ntrans.completada"
	tableShorten["N�mero do terminal%:"]				= "no. terminal"
	
local function shortenMessages( str )
-- [[
	if str ~= "" and str ~= nil then
		for iIndex ,tParams in pairs(tableShorten) do
			if (iIndex ~= tParams) then
				str = string.gsub(str, iIndex, tParams)
				--printer.print("str "..tostring(str))			
			end
		end		
	else 
		str = ""
	end
	--]]
	--printer.print("str "..str)
	--printer.print(hutil.hextostr(str))
	return str

end

DesenhaSetasAbaixo = function ()
	--seta para baixo
	local width,height = display.pixels()		
	display.drawline (width - 7, height - 4, width - 1, height - 4)
    display.drawline (width - 7, height - 4, width - 4, height - 1)
    display.drawline (width - 1, height - 4, width - 4, height - 1)
    display.drawline (width - 5, height - 3, width - 3, height - 3)
    display.drawline (width - 4, height - 2, width - 4, height - 2)
		
end

DesenhaSetasAcima = function ()
	--seta para cima
	local width,height = display.pixels()		
	height = 0
	
	display.drawline (width - 7, height + 4, width - 1, height + 4)
	display.drawline (width - 7, height + 4, width - 4, height + 1)
	display.drawline (width - 1, height + 4, width - 4, height + 1)
	display.drawline (width - 5, height + 3, width - 3, height + 3)	
	display.drawline (width - 4, height + 2, width - 4, height + 2)
		
end





tGUI = {

ChecaTitulo = function (sMsg)
	
	local tListaMsgs = {
      ["relat�rio resumido"]      = true,
      ["relat�rio detalhado"]     = true,
      ["relat�rio de estorno"] 	  = true,

   }
   
   if (tListaMsgs[string.lower(hutil.trim(sMsg))]) then
      return true
   end
   
   return false
end,

Input = function(tTela)
	
	tTela.params.sTexto  		= shortenMessages(tTela.params.sTexto)
	tTela.params.sTextoInput  	= shortenMessages(tTela.params.sTextoInput)
	tTela.params.sTitulo 		= shortenMessages(tTela.params.sTitulo)
	
	tTela.params.sTexto  		= stripAccents(tTela.params.sTexto)
	tTela.params.sTextoInput  	= stripAccents(tTela.params.sTextoInput)
	tTela.params.sTitulo 		= stripAccents(tTela.params.sTitulo)
	
	if (tTela.fConfirmacaoPositiva or tTela.fReferida) then
		tTela.params.sTexto  = string.gsub(tTela.params.sTexto, "digite ", "")
		tTela.params.sTexto  = string.gsub(tTela.params.sTexto, "\nno teclado num�rico:", "")
		tTela.fConfirmacaoPositiva = false
		tTela.fReferida = false
	end
	
	local iTecla, iInputValor
	iTecla, iInputValor = xInput.show(tTela.params)
	--tTela.params = {xInput.GetTeclaPressionada(), xInput.getInputValor()}
	tTela.params = {iTecla, iInputValor}
	
	return tTela
end,

-- tTeclas: teclas que podem ser aceitas.
DialogComRolagem = function(tLinhas, iTimeout, sFont, tTeclas)
	
	local iPosicaoInicio = 1
	local iPosicaoFim = 1
	local i = 0
	local iTecla = nil
	
	local iQtdLinhasTela = 4
	local iDeveSair = false

	--validando tabela
	if not tLinhas or #tLinhas == 0 then
		return HF_TIMEOUT_EVENT
	end
	
	--ajustando timeout default
	if not iTimeout then
		iTimeout = 30
	end


	
	--ajustando fonte e qtd maxima das linhas
	if sFont == 'small' then
		iQtdLinhasTela = 6
	elseif sFont == 'normal' then
		iQtdLinhasTela = 4
	elseif sFont == 'large bold' then
		iQtdLinhasTela = 4
	elseif sFont == 'large' then
		iQtdLinhasTela = 4
	--fonte desconhecida. setando large
	else
		sFont = 'large'
		iQtdLinhasTela = 4
	end
	
	
	
	
	--setando fonte
	local fonteCorrente = display.font()
	display.font(sFont)
	
	
	while iPosicaoInicio <= #tLinhas do
	
		i = 0
		display.clear()
		--loop imprimindo as linhas na tela
		while iPosicaoInicio <= #tLinhas and i < iQtdLinhasTela do
			-- Ajuste para n�o imprimir linhas em branco(nil) quando tabela menor que quantidade de linhas que pode ser exibida na tela (iQtdLinhasTela)
			-- so imprime linha na tela quando indice(i) for menor ou igual a quantidade de linhas na tabela enviada.
			if (i+1 <= #tLinhas) then
				display.print(tLinhas[iPosicaoInicio+i], i)
			end
			i = i + 1
		end
		
		iPosicaoFim = iPosicaoInicio + i
				
		--seta para baixo
		if iPosicaoFim <= #tLinhas then
			DesenhaSetasAbaixo()
		end
		
		--seta para cima
		if iPosicaoInicio > 1 then
			DesenhaSetasAcima()
		end
		
		while true do
			--aguarda tecla
			iEvt, iTecla = ui.graphical_wait_events(iTimeout, 0x0008)
			
			
			if iEvt == IWAIT_EVT_KEYBOARD then
				--printer.print('tecla=' .. tostring(iTecla))
				--printer.print('iPosicaoInicio=' .. iPosicaoInicio)
				
				--tecla enter/baixo e nao esta na ultima linha => desce
				if (iTecla == KEY_DOWN or iTecla == KEY_ENTER ) and iPosicaoFim < #tLinhas+1 then
					iPosicaoInicio = iPosicaoInicio + 1
					break
					
				--seta para cima e nao esta na primeira posicao
				elseif iTecla == KEY_UP and iPosicaoInicio > 1 then
					iPosicaoInicio = iPosicaoInicio - 1
					break

				--tecla cancel. sai.
				elseif iTecla == KEY_CANCEL then
					iDeveSair = true
					break				
				
								
				--tecla enter e ja exibiu tudo. sai.
				elseif (iPosicaoFim > #tLinhas) then
					--if (iTecla == KEY_ENTER) then
					--	iDeveSair = true
					--	break
					--end
					if (tTeclas ~= nil) then			
						--hutil.fPrintTable (tTeclas)
						for iIndex ,tecla in pairs(tTeclas) do
							--printer.print ("tecla " .. tecla)
							if (iTecla == tecla) then
								iDeveSair = true
								break
							end
						end
					end
					if (iDeveSair) then break end
				end
			
			else
				iTecla = HF_TIMEOUT_EVENT
				iDeveSair = true
				break
			
			end
		end
		
		--sai do laco principal
		if iDeveSair then
			break
		end	
		
	end
	
	--volta a fonte para antiga
	display.font(fonteCorrente)
	
	--return iTecla
	return iTecla
	
end,


Dialog = function(tTela)
	--printer.print('DIALOG ' )  -- DSP - DEBUG
	if tTela.iTempo ~= nil then
		tTela.params.iTempo = tTela.iTempo
		tTela.iTempo = nil
	end
	
	tTela.params.sTexto  = shortenMessages(tTela.params.sTexto)
	tTela.params.sTitulo = shortenMessages(tTela.params.sTitulo)
	
	tTela.params.sTexto  = stripAccents(tTela.params.sTexto)
	tTela.params.sTitulo = stripAccents(tTela.params.sTitulo)
	
	if (tTela.params.sTitulo:find("relatorio") ~= nil) then
		tTela.params.fRelatorio = true
	end
	
	if (string.find(tTela.params.sTexto, "chave posicao")) then
		tTela.params.sTexto = string.gsub(tTela.params.sTexto, "%-", "%:")
	end
	
	-- Adapta��o para que tela de desligar n�o funcione nos POSs monocrom�ticos
	if (tTela.params.sTexto == "deseja desligar\no terminal?") then
		tTela.params.sTexto = "funcao inativa"
		tTela.params.iTempo = 10
	elseif (tTela.params.sTexto:find("queda de energia") ~= nil) then 

		tTela.params.sTexto = tTela.params.sTexto .. "\n1.sim           2.nao"
	end
	
	-- tela Rav02
	if (tTela.params.fRav02) then
		if (tTela.params.sTitulo == "rav total") then
			tTela.params.sTexto = tTela.params.sTexto .. "\ndeseja realizar\nrav total?\n1.sim\n2.nao"
		elseif (tTela.params.sTitulo == "rav parcial") then
			tTela.params.sTexto = tTela.params.sTexto .. "\ndeseja realizar\nrav total?\n1.sim\n2.nao"
		end
	elseif (tTela.params.fRav03) then
		tTela.params.sTitulo = ""
	end
	
	local tLinhas, iQtdeLinhas 
	
	tLinhas, iQtdeLinhas = hutil.quebraStrLinhas(tTela.params.sTexto)

	-- LYF: display das informa��es do sistema
	if (tTela.params.dialogInformacaoSistema) then
		tTela.params.sTexto = string.gsub(tostring(tTela.params.sTexto), "-", ": ")
	end
	
	-- tela de confirma��o de estorno
	if ((tTela.params.sTexto) and (tTela.params.sTexto ~= "") and (tTela.params.fDialogEstorno)) then
		tTela.params.sTexto = string.gsub(tostring(tTela.params.sTexto), "-", ": ")
  	end
	
	--tela de novidades (apenas impressao)
	if (tTela.params.fTelaNovidades == true) then
		local tLinhasMsg, iNumLinhas = tNovidadesImp.QuebraLinhasMsg(tTela.params.sArquivo)
		tTela.acoes = {{acao = I_ACAO_IMPRIMIR, fImprimeLogo = true, tLinhas = tLinhasMsg }}
		
	-- impress�o de relat�rio
	elseif (tTela.params.fRelatorio == true) then
		iTecla = HF_BUTTON_FIRST_BUTTON
		tTela.params.sResp = nil
		tTela.params[1] = iTecla
		tTela.params.sTrilha1 = track1 
		tTela.params.sTrilha2 = track2
	
	-- Tratamento para Dialog com Rolagem
	elseif (iQtdeLinhas > 4) and (tTela.params.sTitulo ~= "" or tTela.params.sTitulo ~= nil) then
		tTela.params.sTitulo = ""
		tTela.params.sResp = nil
		
		if (tTela.params.fRav02 or tTela.params.fRav04) then
			iTecla = tGUI.DialogComRolagem(tLinhas, 30, "small", {2, 3})
			--REMAPEAMENTO DAS TECLAS DE SIM E N�O
			if iTecla == RCKEY_ENTER or  iTecla == 2 then
				iTecla = HF_BUTTON_KEYBOARD_ENTER
			elseif iTecla == RCKEY_CANCEL or (iTecla == 3) then
				iTecla = HF_BUTTON_KEYBOARD_CANCEL
			end		

		-- Tela de Credi�rio
		elseif (tTela.params.fCrediario) then
			iTecla = tGUI.DialogComRolagem(tLinhas, 30, "small", {KEY_ENTER, 2, 3, 4})
			
			-- REMAPEAMENTO DAS TECLAS "1.imprime simul", "2.nova simul" e "3.contratar"
			if iTecla == 11 or iTecla == 2 then
				iTecla = RCKEY_IMPRIMIR_SIMULACAO -- "1.imprime simul"
			elseif iTecla == 3 then
				iTecla = RCKEY_NOVA_SIMULACAO	  -- "2.nova simul"
			elseif iTecla == 4 then
				iTecla = RCKEY_CONTRATAR		  -- "3.contratar"
			end

		else
			-- Ajuste para aceitar bot�es 1.sim/2.n�o na Pergunta de Estorno, quando queda de energia.
			if (string.find (tTela.params.sTexto, "1.sim\n2.nao") ~= nil) or
			   (string.find (tTela.params.sTexto, "1.sim           2.nao")) then --tratamento de 1.sim 2.nao
				while true do
					iTecla = tGUI.DialogComRolagem(tLinhas, 30, "small", {2, 3})
					--if (iTecla == HF_BUTTON_SECOND_BUTTON or iTecla == HF_BUTTON_FIRST_BUTTON or iTecla == HF_BUTTON_KEYBOARD_CANCEL or iTecla == HF_TIMEOUT_EVENT) then -- deve aceitar APENAS 1 e 2
					if (iTecla == 2 or iTecla == 3 or iTecla == HF_BUTTON_KEYBOARD_CANCEL or iTecla == HF_TIMEOUT_EVENT) then -- deve aceitar APENAS 1 e 2
						if (iTecla == 2) then
							iTecla = HF_BUTTON_SECOND_BUTTON
						else
							iTecla = HF_BUTTON_KEYBOARD_CANCEL
						end
						--printer.print ("saindo")
						break
					end	
				end
			else
				iTecla = tGUI.DialogComRolagem(tLinhas, 30, "small", {KEY_ENTER})
				--iTecla = tGUI.DialogComRolagem(tLinhas, 30, "small", {2, 3})
			end

		end

		tTela.params[1] = iTecla
	-- Adapta��o para que tela de desligar n�o funcione nos POSs monocrom�ticos
	elseif (tTela.params.sTexto == "deseja desligar\no terminal?") then
		tTela.params.sTexto = "funcao inativa"
		iTecla = HF_BUTTON_KEYBOARD_CANCEL
	--tela inicial e telas padrao de dialog	
	else
		-- Tratamento para tela com 4 linhas utilizar o titulo
		if ((iQtdeLinhas == 4) and (tTela.params.sTitulo == "" or tTela.params.sTitulo == nil)) then 
			tTela.params.sTitulo = tLinhas[1]
			tTela.params.sTexto = tLinhas[2].."\n"..tLinhas[3].."\n"..tLinhas[4]
		end
		
		local iTecla=nil
		local track1=nil
		local track2=nil
		if (string.find (tTela.params.sTexto, "1.sim\n2.nao") ~= nil) or
		   (string.find (tTela.params.sTexto, "1.sim           2.nao")) then --tratamento de 1.sim 2.nao
			while true do
				iTecla, track1, track2 = tDialogUI.Mostrar(tTela.params, true)
				--printer.print ("iTecla ".. iTecla)
				if (iTecla == HF_BUTTON_SECOND_BUTTON or iTecla == HF_BUTTON_FIRST_BUTTON or iTecla == HF_BUTTON_KEYBOARD_CANCEL) then -- deve aceitar APENAS 1 e 2
					--printer.print ("saindo ")
					break
				end	
			end
				
		else
			 iTecla, track1, track2 = tDialogUI.Mostrar(tTela.params, true)
		
		end
		
		if iTecla == KEY_F4 then
			tTela.acoes = {{acao = I_ACAO_AVANCAR_PAPEL, iLinhas = 1 }}
			iTecla = HF_TIMEOUT_EVENT
		end
		
		tTela.params.sResp = nil
		tTela.params[1] = iTecla	
		tTela.params.sTrilha1 = track1 
		tTela.params.sTrilha2 = track2
	end
	
	--return iTecla
	return tTela
	
end,

Menu = function(tTela)

	tTela.params.sTitulo 		= shortenMessages(tTela.params.sTitulo)
	
	tTela.params.sTitulo 		= stripAccents(tTela.params.sTitulo)
	
	--Tratamento para chamar tela de contratacao de "credi�rio"
	if tTela.params.tBotoesRodape ~= nil and tTela.params.tBotoesRodape[2] == "contratar" then
		
		-- Recebendo dados da Simula��o
		local iIdPgto = tTela.params.iIdPgto
		local sValor = tTela.params.tTabCondicoesPgto.sValorTransacao
		local sValorParcela = tTela.params.tTabCondicoesPgto[iIdPgto].sValorParcela
		local sValorTotal = tTela.params.tTabCondicoesPgto[iIdPgto].sValorTotal
		local sParc = tTela.params.tTabCondicoesPgto[iIdPgto].sQtdeParcelas
		local sJuros = tTela.params.tTabCondicoesPgto[iIdPgto].sJuros
		local sCET = tTela.params.tTabCondicoesPgto[iIdPgto].sCET

		-- Formatando Valor
		sValor = tonumber(sValor)
		sValor = hutil.FormataValor(sValor)
		if (sValor:len() > 11) then
			sValor = string.format("V:%18.18s", sValor) -- Pior hip�tese, valor com 11 ou 12 digitos
		else
			sValor = string.format("VLR:%16.16s", sValor)
		end
		
		-- Formatando Quantidade de Parcelas
		sParc = string.format("PARC.:%14.14s", sParc) 
		
		-- Formatando Valor da Parcela
		sValorParcela = tonumber(sValorParcela)
		sValorParcela = hutil.FormataValor(sValorParcela)
		sValorParcela = string.format("  %18.18s", sValorParcela)

		-- Formatando Juros
		sJuros = hutil.FormataJuros(sJuros)
		sJuros = string.format("ENC MES:%11.11s%%", sJuros) 
		
		-- Formatando CET
		sCET = hutil.FormataJuros(sCET)
		sCET = string.format("CET ANO:%11.11s%%", sCET) 

		-- Formatando Valor Total
		sValorTotal = tonumber(sValorTotal)
		sValorTotal = hutil.FormataValor(sValorTotal)
		if (sValorTotal:len() > 11) then
			sValorTotal = string.format("T:%18.18s", sValorTotal) -- Pior hip�tese, valor com 11 ou 12 digitos
		else
			sValorTotal = string.format("TOT:%16.16s", sValorTotal)
		end
		
		-- Formatando Mensagem a ser exibida
		local str = sValor 			  .. "\n" ..
		            sParc  			  .. "\n" ..
					sValorParcela	  .. "\n" ..
					sJuros 			  .. "\n" ..
					sCET			  .. "\n" ..
					sValorTotal		  .. "\n" ..
					"1.imprime simul" .. "\n" ..
					"2.nova simul" 	  .. "\n" ..
					"3.contratar"
					
		tTela.params.fCrediario = true
		
		tTela.params.sTexto = str
		
		tTela = tGUI.Dialog(tTela)
	else
		local i = 1
		while tTela.params.tItens[i] ~= nil do
			tTela.params.tItens[i] = shortenMessages(tTela.params.tItens[i])
			tTela.params.tItens[i] = string.sub(stripAccents(tTela.params.tItens[i]),1,13)
			i = i + 1
		end
		
		if (tTela.params.tItens[1] == "nao possui" and tTela.params.tItens[2] == "ilegivel") then
			tTela.params.sTitulo = "cod. seguranca:"
		end
		
		--local xMenuUI = require("menuui")
		
		--Tratamento para incluir item "nova simul" nova tela do crediario	
		if tTela.params.tBotoesRodape ~= nil and tTela.params.tBotoesRodape[2] == "nova simulacao"  then
		   --and tTela.params.sTitulo == "simulacao" then
			table.insert( tTela.params.tItens, "nova simul" )
			tTela.params.sTitulo = ""
		end

		local iTempo = tTela.params.iTempo
		if (iTempo == 0 or iTempo == nil) then  
			iTempo = TEMPO_OPERADOR
		end
		
		--se a ultima opcao nao for 'administra', menu default
		if tTela.params.tItens[#tTela.params.tItens] ~= 'administra' then
			
			local menuH = ui.menu(tTela.params.sTitulo,tTela.params.tItens, true, true)
			menuH:aligntitle("center") -- titulo
			
			aceitou = menuH:show(iTempo)
				
			if aceitou then
				tTela.params[1] = menuH:accepted() - 1
			else
				tTela.params[1] = HF_BUTTON_KEYBOARD_REJECT_BUTTON
			end
		else

			local xMenuUI = require("menuui")
			tTela.params[1] = xMenuUI.menuComFunc(tTela.params.tItens, true, iTempo)
			
		end
	end

	return tTela
end,

--verifica se o n�vel de bateria est� baixo e gerencia as mensagens a serem exibidas na tela
GerenciaBateria = function(tParams)

	--TODO GCM: checar se precisa!
	return tParams
end,

MensagemInicial = function()
	display.clear()
	display.print('VERIFICANDO\nVERSAO DA\nAPLICACAO',0,"center")
end,

ParametrosVazios = function()
	
	tTela = {}
	tTela.telaID = I_TELA_ID_DIALOG
	tTela.params = {}
	tTela.params.sTitle = ''
	tTela.params.sTexto = 'erro na itera��o com a RN'
	tTela.params.iTempo = 5
	
	return false, nil
end,

VerificaTelas = function(params)
	--TODO GCM: implementar 
end,


fCallbackFab = function(tCampos)

	-- CAMPOS DA TELA DE SENHA
	local sMensagemFinal = tCampos
	local sTitulo = ""
	local sParcelas = nil
	local sValor = ""
	local sMsgServico = ""
	local _, posParcelas = sMensagemFinal:find("P: ")
	local _, posValor = sMensagemFinal:find("V: ")
	local _, posMsgServico = sMensagemFinal:find("SERV: ")
	local sMsgSenha = "senha:"
	local fValor = true -- tem valor

    if (sMensagemFinal:find("SC:") ~= nil) then sMsgSenha = "senha cred:" --sTitulo = "    cr�dito\n"
    elseif (sMensagemFinal:find("SD:") ~= nil) then sMsgSenha = "senha deb:" --sTitulo = "     d�bito\n"
    --elseif (sMensagemFinal:find("SV:") ~= nil) then sTitulo = "    voucher\n"
    elseif (sMensagemFinal:find("SP:") ~= nil) then sMsgSenha = "senha cred:" --sTitulo = "pre-autoriza��o\n"
    --elseif (sMensagemFinal:find("SL:") ~= nil) then sTitulo = " private label\n"
    elseif (sMensagemFinal:find("SS:") ~= nil) then sMsgSenha = "senha cred:" --sTitulo = "   simula��o\n"
    elseif (sMensagemFinal:find("ST:") ~= nil) then sMsgSenha = "senha cred:" --sTitulo = "   contrata��o\n"
    elseif (sMensagemFinal:find("TS:") ~= nil) then 
    	sTitulo = " troca de senha\n"
    	local _, posMsg = sMensagemFinal:find("TS: ")
    	sMsgSenha = sMensagemFinal:sub(posMsg + 1)
    	fValor = false
    --elseif (sMensagemFinal:find("SG:") ~= nil) then sTitulo = "    lavagem\n"
    --elseif (sMensagemFinal:find("SA:") ~= nil) then sTitulo = "abastecimento\n"
    end

	sTitulo = shortenMessages(sTitulo)
	sTitulo	= stripAccents(sTitulo)
	sMsgSenha = shortenMessages(sMsgSenha)
	
	if (posParcelas ~= nil and tonumber(posParcelas) ~= 0) then 
		sParcelas = sMensagemFinal:sub(posParcelas + 1):sub(0, sMensagemFinal:sub(posParcelas + 1):find("\n") - 1) 
	end
	
	if (posValor ~= nil) then
		sValor = sMensagemFinal:sub(posValor + 1):sub(0, sMensagemFinal:sub(posValor + 1):find("\n") - 1)
		sValor = hutil.completarTexto(sValor, " ", 12 , true)
		sValor = "vlr:" .. sValor .. "\n"
	end
	
	if (posMsgServico ~= nil) then
		sMsgServico = sMensagemFinal:sub(posMsgServico + 1):sub(0, sMensagemFinal:sub(posMsgServico + 1):find("\n") - 1)
	end
	
	local sLayoutMsg = ""
	local sLayoutPin = ""
	local sLayoutTitulo, sLayoutValor, sLayoutServico, sLayoutParcelas, sLayoutMsgSenha, sLayoutInput
	sLayoutTitulo =  sTitulo
	sLayoutValor =  sValor
	if (sParcelas ~= nil and tonumber(sParcelas) ~= 0) then
		sLayoutParcelas = hutil.completarTexto(sParcelas, " ", 7 , true)
		sLayoutParcelas = "parcelas:" .. sLayoutParcelas .. "\n"
	else
		sLayoutParcelas = ""
	end
	
	-->> RF 25-02-15 Acrescentando novo campo de texto. Vindo de algum servi�o
	if (sMsgServico ~= "") then
		if (sParcelas ~= nil) then
			sLayoutServico = sMsgServico:sub(1, sMsgServico:find(":")) .. sMsgServico:sub(sMsgServico:find(":"), #sMsgServico)
		else
			sLayoutServico = sMsgServico:sub(1, sMsgServico:find(":")) .. sMsgServico:sub(sMsgServico:find(":"), #sMsgServico)
		end		
	else
		sLayoutServico = ""
	end
	--<<
	
	sLayoutMsgSenha = sMsgSenha
	sLayoutInput = "\n%s"

	sLayoutPin = sLayoutTitulo .. sLayoutValor .. sLayoutParcelas .. sLayoutServico.. sLayoutMsgSenha .. sLayoutInput

	local sCaractereSenha = "*"
	return {pin = sLayoutPin, pinChar=sCaractereSenha, msg = sLayoutMsg}
end,

fCallbackMensagem = function()
	local sLayoutMsg = "%s"
	local tRegrasDeMensagem = {
		"processando","nao retire\n o cartao",
		"cartao","cartao","retire o cartao"
	}
	return { msg = sLayoutMsg, rules = tRegrasDeMensagem }
end,

fCallbackMenu = function()

	local sLayoutTitulo, tLayout4botoes,tLayout8botoes, sLayoutFooter
	--sLayoutTitulo = "~C~U024~F03%s"
	if sLayoutTitulo then
		tLayout4botoes = {
			"~U044~L015~I007{~L004~F01~$0~W1.%s~K031}",
			"~U100~L015~I007{~L004~F01~$0~W2.%s~K032}",
			"~U156~L015~I007{~L004~F01~$0~W3.%s~K033}",
			"~U212~L015~I007{~L004~F01~$0~W0.%s~K034}"
		}
	else
		tLayout4botoes = {
			"~U034~L015~I007{~L004~F01~$0~W1.%s~K031}",
			"~U090~L015~I007{~L004~F01~$0~W2.%s~K032}",
			"~U146~L015~I007{~L004~F01~$0~W3.%s~K033}",
			"~U202~L015~I007{~L004~F01~$0~W0.%s~K034}"
		}
	end
	tLayout8botoes = {
		"~U034~L015~I009{~L003~F01~$0~W1.%s~K031}",
		"~R015~I009{~L003~F01~$0~W2.%s~K032}",
		"~U090~L015~I009{~L004~F01~$0~W3.%s~K033}",
		"~R015~I009{~L003~F01~$0~W4.%s~K034}",
		"~U146~L015~I009{~L004~F01~$0~W5.%s~K035}",
		"~R015~I009{~L003~F01~$0~W6.%s~K036}",
		"~U202~L015~I009{~L004~F01~$0~W7.%s~K037}",
		"~R015~I009{~L003~F01~$0~W8.%s~K038}"
	}
	sLayoutFooter = "~D009~L015~I004{~F04~$4cancela~K00c}"
	return {tlt = sLayoutTitulo, bt4 = tLayout4botoes, bt8 = tLayout8botoes, ft = sLayoutFooter}
end,


Init = function()
	return 0
end


}